//
//  LoginHelper.m
//  SnackCaddy Golfer
//
//  Created by BHARATH L.N on 21/07/15.
//  Copyright (c) 2015 Mowares. All rights reserved.
//

#import "LoginHelper.h"
#import "Lockbox.h"

@interface LoginHelper()

@end


@implementation LoginHelper




- (void)login:(NSString *)username password:(NSString *)password
             success:(void (^)(id responseObject))success
             failure:(void (^)(NSError *error))failure
{
 
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSDictionary *params = @{@"email": username,
                             @"password": password,
                             @"device_token": @"asdasdasdasd",
                             @"device_type": @"ios",
                             @"login_by": @"manual"};
    
    NSString *loginurl = [NSString stringWithFormat:@"%@login", SERVER_URL];
    [manager POST:loginurl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         //Logging Response
         NSLog(@"JSON: %@", responseObject);
         
         //Passing response object back
         if([responseObject objectForKey:@"error"])
         {
           failure(responseObject);
         }
         else
         {
             
             success(responseObject);
             [Lockbox setString:[responseObject valueForKey:@"id"] forKey:@"id"];
             [Lockbox setString:[responseObject valueForKey:@"token"] forKey:@"token"];
             NSLog(@"%@", [Lockbox stringForKey:@"token"]);
             NSLog(@"%@", [Lockbox stringForKey:@"id"]);
             
        }
         
             
    }
     
    failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         NSLog(@"Error: %@", error);
         //Passing failure object back
         failure(error);
     }];
}




@end
