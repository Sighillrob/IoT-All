//
//  GaugesVC.h
//  WaitForIt
//
//  Created by Dev on 28/07/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GaugesVC : UIViewController <UIAlertViewDelegate>

@end
