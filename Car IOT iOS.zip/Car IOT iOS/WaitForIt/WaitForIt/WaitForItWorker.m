//
//  WaitForItWorker.m
//  WaitForIt
//
//  Created by Michael Conrad Tadpol Tilstra on 12/11/14.
//  Copyright (c) 2013-2014 Exosite. All rights reserved.
//

#import "WaitForItWorker.h"
#import <AFNetworking.h>
#import <EXORpc.h>

@interface WaitForItWorker ()
@property (strong,nonatomic) NSString *CIK;
@property (strong,nonatomic) EXORpc *onep;

@end

#define LoggerNetwork(x, fmt, args...) NSLog(fmt, ##args)

@implementation WaitForItWorker

- (BOOL)isSetup {
    return self.CIK != nil;
}

- (void)drinkFromCikFountian {
    
    NSURL *url = [NSURL URLWithString:@"http://cik.herokuapp.com/"];
    NSError *error = nil;
    NSUserDefaults *defaults =[NSUserDefaults standardUserDefaults];
    NSString *cikString = [defaults valueForKey:@"cik"];
   //r self.CIK = @"a93cdc337bc4a3e7621cb39769a5fdd77c4c24bf";
    self.CIK=cikString;
 
    
    if (self.CIK == nil) {
        LoggerNetwork(0, @"Failed to drink! %@", error);
    }
    LoggerNetwork(2, @"temporary CIK: %@", self.CIK);
}

- (EXORpcRequest*)makeSureAliasExists:(NSString*)alias name:(NSString*)name
{
    EXORpcAuthKey * auth = [EXORpcAuthKey authWithCIK:self.CIK];

    EXORpcLookupRequest *lkp = [EXORpcLookupRequest lookupWithType:EXORpcLookupTypeAlias item:alias complete:^(NSString* found, NSError *err){
        if (err) {
            /* Not there, so create, then map */
            EXORpcDataportResource *res = [EXORpcDataportResource dataportWithName:name format:EXORpcDataportFormatFloat];
            EXORpcCreateRequest *cdp = [EXORpcCreateRequest createWithResource:res complete:^(EXORpcResourceID *RID, NSError *error){
                if (error) {
                    LoggerNetwork(0, @"!!!Error Dataport create for %@ failed %@", alias, error);
                } else {
                    EXORpcMapRequest *map = [EXORpcMapRequest mapWithRID:RID to:alias complete:^(NSError* err){
                        if (err) {
                            LoggerNetwork(0, @"!!!Error Mapping request for %@ to %@ failed %@", alias, RID, err);
                        } else {
                            LoggerNetwork(2, @" Mapped %@ to %@ !", alias, RID);
                        }
                    }];
                    [self.onep doRPCwithAuth:auth requests:@[map] complete:^(NSError *err) {
                        if (err) {
                            LoggerNetwork(0, @"!!!Error on mapping %@ to %@. %@", alias, RID, err);
                        }
                    }];
                }
            }];
            [self.onep doRPCwithAuth:auth requests:@[cdp] complete:^(NSError *err) {
                if (err) {
                    LoggerNetwork(0, @"!!!Error on dataport create for %@. %@", alias, err);
                }
            }];
        } else {
            LoggerNetwork(2, @" Alias %@ is mapped to %@", alias, found);
        }
    }];

    return lkp;
}

- (EXORpcRequest*)uploadScript:(NSString*)alias
{
    EXORpcAuthKey * auth = [EXORpcAuthKey authWithCIK:self.CIK];

    NSURL *url = [[NSBundle mainBundle] URLForResource:alias withExtension:@"lua"];
    NSStringEncoding encoding;
    NSError *error=nil;
    NSString *script = [NSString stringWithContentsOfURL:url usedEncoding:&encoding error:&error];
    if (!script || error) {
        return nil;
    }

    EXORpcLookupRequest *lkp = [EXORpcLookupRequest lookupWithType:EXORpcLookupTypeAlias item:alias complete:^(NSString* found, NSError *err){
        if (err) {
            EXORpcDataruleResource *datarule = [EXORpcDataruleResource dataruleWithName:alias script:script];
            EXORpcCreateRequest *cdp = [EXORpcCreateRequest createWithResource:datarule complete:^(EXORpcResourceID *RID, NSError *error){
                if (error) {
                    LoggerNetwork(0, @"!!!Error Dispatch create for %@ failed %@", alias, error);
                } else {
                    EXORpcMapRequest *map = [EXORpcMapRequest mapWithRID:RID to:alias complete:^(NSError* err){
                        if (err) {
                            LoggerNetwork(0, @"!!!Error Mapping request for %@ to %@ failed %@", alias, RID, err);
                        } else {
          
                            LoggerNetwork(2, @" Mapped %@ to %@ !", alias, RID);
                        }
                    }];
                    [self.onep doRPCwithAuth:auth requests:@[map] complete:^(NSError *err) {
                        if (err) {
                            LoggerNetwork(0, @"!!!Error on mapping %@ to %@. %@", alias, RID, err);
                        }
                    }];
                }
            }];
            [self.onep doRPCwithAuth:auth requests:@[cdp] complete:^(NSError *err) {
                if (err) {
                    LoggerNetwork(0, @"!!!Error on Datarule create for %@. %@", alias, err);
                }
            }];

        } else {
            LoggerNetwork(2, @"Script has Alias %@ mapped to %@", alias, found);
        }
    }];
    return lkp;
}


- (void)createPortsAndScripts
{
    [self drinkFromCikFountian];

    LoggerNetwork(2, @"Going to create things.");
    self.onep = [EXORpc rpc];
    self.onep.queue = [NSOperationQueue new];

    NSMutableArray *reqs = [NSMutableArray new];
    [reqs addObject:[self makeSureAliasExists:@"speed" name:@"Speed"]];
    [reqs addObject:[self makeSureAliasExists:@"rpm" name:@"RPM"]];
    [reqs addObject:[self makeSureAliasExists:@"dis" name:@"Distance"]];
    [reqs addObject:[self makeSureAliasExists:@"load" name:@"Load"]];
    [reqs addObject:[self makeSureAliasExists:@"crash" name:@"Crash"]];
    [reqs addObject:[self makeSureAliasExists:@"service" name:@"Service"]];
    [reqs addObject:[self makeSureAliasExists:@"critical" name:@"Critical"]];
    [reqs addObject:[self makeSureAliasExists:@"location" name:@"Location"]];
    
    
    [reqs addObject:[self uploadScript:@"pinging"]];

    EXORpcAuthKey * auth = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth requests:[reqs copy] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on createPortsAndScripts %@", err);
        }
    }];
}

- (void)setWaitRate:(NSUInteger)seconds
{
    NSLog(@"WRITING SPEED DATA EXOSITE");
    EXORpcWriteRequest *wr = [EXORpcWriteRequest writeWithRID:[EXORpcResourceID resourceIDByAlias:@"speed"] number:@(seconds) complete:^(NSError *error) {
        if (error) {
            LoggerNetwork(0, @"Error writing initial rate (Speed)! : %@", error);
        } else {
            LoggerNetwork(2, @"Wrote new SPEED rate of %lu", (unsigned long)seconds);
        }
    }];
    EXORpcAuthKey * auth = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth requests:@[wr] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on set wait rate (Speed) %@", err);
        }
    }];

}
- (void)cancelAllOperations
{
    NSLog(@"Clearing operations");
   
    [self.onep.queue cancelAllOperations];
}

- (void)setWaitRate2:(NSUInteger)seconds
{
     NSLog(@"WRITING RPM DATA EXOSITE");
    EXORpcWriteRequest *wr2 = [EXORpcWriteRequest writeWithRID:[EXORpcResourceID resourceIDByAlias:@"rpm"] number:@(seconds) complete:^(NSError *error) {
        if (error) {
            LoggerNetwork(0, @"Error writing initial rate (rpm)! : %@", error);
        } else {
            LoggerNetwork(2, @"Wrote new RPM rate of %lu", (unsigned long)seconds);
        }
    }];
    EXORpcAuthKey * auth2 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth2 requests:@[wr2] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on set wait rate (rpm) %@", err);
        }
    }];
    
}
- (void)setWaitRate3:(NSUInteger)seconds
{
    
    EXORpcWriteRequest *wr3 = [EXORpcWriteRequest writeWithRID:[EXORpcResourceID resourceIDByAlias:@"dis"] number:@(seconds) complete:^(NSError *error) {
        if (error) {
            LoggerNetwork(0, @"Error writing initial rate (distance)! : %@", error);
        } else {
            LoggerNetwork(2, @"Wrote new rate of %lu", (unsigned long)seconds);
        }
    }];
    
    EXORpcAuthKey * auth3 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth3 requests:@[wr3] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on set wait rate (distance) %@", err);
        }
    }];
    
}
- (void)setWaitRate4:(NSUInteger)seconds
{
    
    EXORpcWriteRequest *wr4 = [EXORpcWriteRequest writeWithRID:[EXORpcResourceID resourceIDByAlias:@"coolant"] number:@(seconds) complete:^(NSError *error) {
        if (error) {
            LoggerNetwork(0, @"Error writing initial rate (coolant)! : %@", error);
        } else {
            LoggerNetwork(2, @"Wrote new rate of %lu", (unsigned long)seconds);
        }
    }];
    EXORpcAuthKey * auth4 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth4 requests:@[wr4] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on set wait rate (coolant) %@", err);
        }
    }];
    
}

- (void)setWaitRate5:(NSUInteger)seconds
{
    
    EXORpcWriteRequest *wr5 = [EXORpcWriteRequest writeWithRID:[EXORpcResourceID resourceIDByAlias:@"airintake"] number:@(seconds) complete:^(NSError *error) {
        if (error) {
            LoggerNetwork(0, @"Error writing initial rate (air intake)! : %@", error);
        } else {
            LoggerNetwork(2, @"Wrote new rate of %lu", (unsigned long)seconds);
        }
    }];
    
    EXORpcAuthKey * auth5 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth5 requests:@[wr5] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on set wait rate (air intake) %@", err);
        }
    }];
    
}

- (void)setWaitRate6:(NSUInteger)seconds
{
    
    EXORpcWriteRequest *wr6 = [EXORpcWriteRequest writeWithRID:[EXORpcResourceID resourceIDByAlias:@"engrunningtime"] number:@(seconds) complete:^(NSError *error) {
        if (error) {
            LoggerNetwork(0, @"Error writing initial rate (eng running)! : %@", error);
        } else {
            LoggerNetwork(2, @"Wrote new rate of %lu", (unsigned long)seconds);
        }
    }];
    EXORpcAuthKey * auth6 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth6 requests:@[wr6] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on set wait rate (eng running) %@", err);
        }
    }];
    
}

- (void)setWaitRate7:(NSString*)seconds
{
    
    EXORpcWriteRequest *wr7 = [EXORpcWriteRequest writeWithRID:[EXORpcResourceID resourceIDByAlias:@"critical"] string:seconds complete:^(NSError *error) {
        if (error) {
            LoggerNetwork(0, @"Error writing initial rate (critical)! : %@", error);
        } else {
            LoggerNetwork(2, @"Wrote new rate of %lu", (unsigned long)seconds);
        }
    }];
    EXORpcAuthKey * auth7 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth7 requests:@[wr7] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on set wait rate (critical) %@", err);
        }
    }];
    
}

- (void)setWaitRate8:(NSString*)seconds
{
    
    EXORpcWriteRequest *wr8 = [EXORpcWriteRequest writeWithRID:[EXORpcResourceID resourceIDByAlias:@"location"] string:seconds complete:^(NSError *error) {
        if (error) {
            LoggerNetwork(0, @"Error writing initial rate (location)! : %@", error);
        } else {
            LoggerNetwork(2, @"Wrote new rate of %@", seconds);
        }
    }];
    EXORpcAuthKey * auth8 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth8 requests:@[wr8] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on set wait rate (location) %@", err);
        }
    }];
    
}

//- (void)setWaitRateCritical:(NSString*)seconds
//{
//    
//    EXORpcWriteRequest *wr8 = [EXORpcWriteRequest writeWithRID:[EXORpcResourceID resourceIDByAlias:@"critical"] string:seconds complete:^(NSError *error) {
//        if (error) {
//            LoggerNetwork(0, @"Error writing initial rate! : %@", error);
//        } else {
//            LoggerNetwork(2, @"Wrote new rate of %@", seconds);
//        }
//    }];
//    EXORpcAuthKey * auth8 = [EXORpcAuthKey authWithCIK:self.CIK];
//    [self.onep doRPCwithAuth:auth8 requests:@[wr8] complete:^(NSError *err) {
//        if (err) {
//            LoggerNetwork(0, @"!!!Error on set wait rate %@", err);
//        }
//    }];
//    
//}






- (void)waitForIt:(WaitedForThis)complete
{
    WaitedForThis lcomplete = [complete copy];
    EXORpcResourceID *rid = [EXORpcResourceID resourceIDByAlias:@"speed"];
    EXORpcWaitRequest *wr = [EXORpcWaitRequest waitRequestWithRIDs:@[rid]  timeoutAfter:@(300) complete:^(NSDictionary *results, NSError *error) {
        EXORpcValue *val = nil;
        if (error) {
            LoggerNetwork(0, @"Error waiting for new data : %@", error);
        } else {
            val = results[rid];
            LoggerNetwork(2, @"Got %@", val);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (lcomplete) {
                lcomplete(val.numberValue, error);
            }
        });
    }];
    EXORpcAuthKey * auth = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth requests:@[wr] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on waitforit %@", err);
        }
    }];
    
}

- (void)waitForIt2:(WaitedForThis)complete
{

     WaitedForThis lcomplete = [complete copy];
    EXORpcResourceID *rid2 = [EXORpcResourceID resourceIDByAlias:@"rpm"];
    EXORpcWaitRequest *wr2 = [EXORpcWaitRequest waitRequestWithRIDs:@[rid2]  timeoutAfter:@(300) complete:^(NSDictionary *results2, NSError *error) {
        EXORpcValue *val2 = nil;
        if (error) {
            LoggerNetwork(0, @"Error waiting for new data : %@", error);
        } else {
            val2 = results2[rid2];
            LoggerNetwork(2, @"Got %@", val2);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (lcomplete) {
                lcomplete(val2.numberValue, error);
            }
        });
    }];
    EXORpcAuthKey * auth2 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth2 requests:@[wr2] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on waitforit %@", err);
        }
    }];
}


- (void)waitForIt3:(WaitedForThis)complete
{
    
    WaitedForThis lcomplete = [complete copy];
    EXORpcResourceID *rid3 = [EXORpcResourceID resourceIDByAlias:@"dis"];
    EXORpcWaitRequest *wr3 = [EXORpcWaitRequest waitRequestWithRIDs:@[rid3]  timeoutAfter:@(300) complete:^(NSDictionary *results3, NSError *error) {
        EXORpcValue *val3 = nil;
        if (error) {
            LoggerNetwork(0, @"Error waiting for new data : %@", error);
        } else {
            val3 = results3[rid3];
            LoggerNetwork(2, @"Got %@", val3);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (lcomplete) {
                lcomplete(val3.numberValue, error);
            }
        });
    }];
    EXORpcAuthKey * auth3 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth3 requests:@[wr3] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on waitforit %@", err);
        }
    }];
}

- (void)waitForIt4:(WaitedForThis)complete
{
    
    WaitedForThis lcomplete = [complete copy];
    EXORpcResourceID *rid4 = [EXORpcResourceID resourceIDByAlias:@"load"];
    EXORpcWaitRequest *wr4 = [EXORpcWaitRequest waitRequestWithRIDs:@[rid4]  timeoutAfter:@(300) complete:^(NSDictionary *results4, NSError *error) {
        EXORpcValue *val4 = nil;
        if (error) {
            LoggerNetwork(0, @"Error waiting for new data : %@", error);
        } else {
            val4 = results4[rid4];
            LoggerNetwork(2, @"Got %@", val4);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (lcomplete) {
                lcomplete(val4.numberValue, error);
            }
        });
    }];
    EXORpcAuthKey * auth4 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth4 requests:@[wr4] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on waitforit %@", err);
        }
    }];
}

- (void)waitForIt5:(WaitedForThis)complete
{
    
    WaitedForThis lcomplete = [complete copy];
    EXORpcResourceID *rid5 = [EXORpcResourceID resourceIDByAlias:@"crash"];
    EXORpcWaitRequest *wr5 = [EXORpcWaitRequest waitRequestWithRIDs:@[rid5]  timeoutAfter:@(300) complete:^(NSDictionary *results5, NSError *error) {
        EXORpcValue *val5 = nil;
        if (error) {
            LoggerNetwork(0, @"Error waiting for new data : %@", error);
        } else {
            val5 = results5[rid5];
            LoggerNetwork(2, @"Got %@", val5);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (lcomplete) {
                lcomplete(val5.numberValue, error);
            }
        });
    }];
    EXORpcAuthKey * auth5 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth5 requests:@[wr5] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on waitforit %@", err);
        }
    }];
}

- (void)waitForIt6:(WaitedForThis)complete
{
    
    WaitedForThis lcomplete = [complete copy];
    EXORpcResourceID *rid6 = [EXORpcResourceID resourceIDByAlias:@"service"];
    EXORpcWaitRequest *wr6 = [EXORpcWaitRequest waitRequestWithRIDs:@[rid6]  timeoutAfter:@(300) complete:^(NSDictionary *results6, NSError *error) {
        EXORpcValue *val6 = nil;
        if (error) {
            LoggerNetwork(0, @"Error waiting for new data : %@", error);
        } else {
            val6 = results6[rid6];
            LoggerNetwork(2, @"Got %@", val6);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (lcomplete) {
                lcomplete(val6.numberValue, error);
            }
        });
    }];
    EXORpcAuthKey * auth6 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth6 requests:@[wr6] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on waitforit %@", err);
        }
    }];
}

- (void)waitForIt7:(WaitedForThis)complete
{
    
    WaitedForThis lcomplete = [complete copy];
    EXORpcResourceID *rid7 = [EXORpcResourceID resourceIDByAlias:@"crash"];
    EXORpcWaitRequest *wr7 = [EXORpcWaitRequest waitRequestWithRIDs:@[rid7]  timeoutAfter:@(300) complete:^(NSDictionary *results7, NSError *error) {
        EXORpcValue *val7 = nil;
        if (error) {
            LoggerNetwork(0, @"Error waiting for new data : %@", error);
        } else {
            val7 = results7[rid7];
            LoggerNetwork(2, @"Got %@", val7);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (lcomplete) {
                lcomplete(val7.numberValue, error);
            }
        });
    }];
    EXORpcAuthKey * auth5 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth5 requests:@[wr7] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on waitforit %@", err);
        }
    }];
}

- (void)waitForIt8:(WaitedForThis)complete
{
    
    WaitedForThis lcomplete = [complete copy];
    EXORpcResourceID *rid7 = [EXORpcResourceID resourceIDByAlias:@"location"];
    EXORpcWaitRequest *wr7 = [EXORpcWaitRequest waitRequestWithRIDs:@[rid7]  timeoutAfter:@(300) complete:^(NSDictionary *results7, NSError *error) {
        EXORpcValue *val7 = nil;
        if (error) {
            LoggerNetwork(0, @"Error waiting for new data : %@", error);
        } else {
            val7 = results7[rid7];
            LoggerNetwork(2, @"Got %@", val7);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (lcomplete) {
                lcomplete(val7.numberValue, error);
            }
        });
    }];
    EXORpcAuthKey * auth5 = [EXORpcAuthKey authWithCIK:self.CIK];
    [self.onep doRPCwithAuth:auth5 requests:@[wr7] complete:^(NSError *err) {
        if (err) {
            LoggerNetwork(0, @"!!!Error on waitforit %@", err);
        }
    }];
}



@end
