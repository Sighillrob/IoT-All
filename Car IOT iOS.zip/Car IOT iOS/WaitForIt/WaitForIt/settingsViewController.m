//
//  settingsViewController.m
//  WaitForIt
//
//  Created by naveen on 8/20/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import "settingsViewController.h"
#import "Constants.h"
#import "AFNetworking.h"
#import "MBProgressHUD.h"
#import "Lockbox.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "JFMinimalNotification.h"
#import "AppDelegate.h"
#import "DevicesListVC.h"

@interface settingsViewController ()<UITextFieldDelegate>

@end

@implementation settingsViewController
{
    DevicesListVC *devObj;
    NSString *dashLinkStr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    devObj= [[DevicesListVC alloc]init];
     [self addTxtDelegates];
     [self getGeneralSettings];
     [self getCarSettings];
     [self getAccountSettings];
    
     self.datePicker.datePickerMode = UIDatePickerModeDate;
    self.shoeDashBtn.hidden=YES;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if([defaults valueForKey:@"dashboard_link"]!= nil)
    {
        dashLinkStr =[defaults valueForKey:@"dashboard_link"];
            self.shoeDashBtn.hidden=NO;
    }
    
     self.btn_saveAccount.layer.cornerRadius = 12.0;
     self.btn_SaveCar.layer.cornerRadius = 12.0;
     self.btn_saveGeneral.layer.cornerRadius = 12.0;
    self.shoeDashBtn.layer.cornerRadius=12.0;
}




-(void)addTxtDelegates
{
    
    self.txt_GeneralFName.delegate = self;
    self.txt_GeneralAddress.delegate = self;
    self.txt_GeneralLName.delegate = self;
    self.txt_GeneralAge.delegate = self;
    self.txt_GeneralCountry.delegate = self;
    self.txt_CarEngineNo.delegate = self;
    self.txt_carMake.delegate = self;
    self.txt_carYear.delegate = self;
    self.txt_CarEngineNo.delegate = self;
    self.txt_carModel.delegate = self;
    self.txt_accountEmail.delegate = self;
    self.txt_accountPassword.delegate = self;
    self.txt_accountRetypePassword.delegate = self;
    self.txt_accountPhone.delegate = self;

}



-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
   
    
    
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField ==  self.txt_CarEngineNo || textField ==  self.txt_accountRetypePassword )
    {
        [self animateTextField: textField up: YES];
    }
    
    
    
}


-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    if (textField ==  self.txt_CarEngineNo || textField ==  self.txt_accountRetypePassword )
    {
        [self animateTextField: textField up: NO];
    }
   // [self animateTextField: textField up: NO];
    
}

- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    const int movementDistance = 80; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}

-(void)getGeneralSettings
{
    
    
    
       
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSString *settingsUrl = [NSString stringWithFormat:@"%@get_personal_setting", SERVER_URL];
        NSDictionary *params = @{@"user_id": [Lockbox stringForKey:@"id"]
                                
                                 };
    
        [manager POST:settingsUrl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [MBProgressHUD hideHUDForView:self.view animated:YES];
    
            NSLog(@"response: %@", responseObject);
            
          self.txt_GeneralAddress.text =  [responseObject valueForKey:@"address"];
            self.txt_GeneralCountry.text =  [responseObject valueForKey:@"country"];

            self.txt_GeneralAge.text =  [responseObject valueForKey:@"dob"];

           NSString *gender =  [responseObject valueForKey:@"gender"];
            
            
            if([gender  isEqual: @"male"])
            {
                self.segmeneAge.selectedSegmentIndex = 0;
            }
            else
            {
                self.segmeneAge.selectedSegmentIndex = 1;

            }
     

            self.txt_GeneralFName.text =  [responseObject valueForKey:@"first_name"];
            self.txt_GeneralLName.text =  [responseObject valueForKey:@"last_name"];
            
            
            self.lbl_GeneralAddress.text =  [responseObject valueForKey:@"address"];
            self.lbl_GeneralCountry.text =  [responseObject valueForKey:@"country"];
            
            self.lbl_GeneralBirthDate.text =  [responseObject valueForKey:@"dob"];
            
            self.lbl_GeneralFirstName.text =  [responseObject valueForKey:@"first_name"];
            self.label_GeneralLastName.text =  [responseObject valueForKey:@"last_name"];

            
            
            
            
            
            
            
         
    
    
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
    
            NSLog(@"Error: %@", error);
            
            
            
        }];
        
        
}

-(void)getCarSettings
{
    
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *settingsUrl = [NSString stringWithFormat:@"%@get_car_details", SERVER_URL];
    NSDictionary *params = @{@"user_id": [Lockbox stringForKey:@"id"]
                             
                             };
    
    [manager POST:settingsUrl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"response: %@", responseObject);
        
        
        
        self.txt_CarEngineNo.text =  [responseObject valueForKey:@"car_engine_no"];
        self.txt_carMake.text =  [responseObject valueForKey:@"car_make"];
        self.txt_carModel.text =  [responseObject valueForKey:@"car_model"];
        self.txt_carYear.text =  [responseObject valueForKey:@"car_year"];
        
        
        
        
        self.lbl_CarEngineNo.text =  [responseObject valueForKey:@"car_engine_no"];
        self.lbl_CarMake.text =  [responseObject valueForKey:@"car_make"];
        self.lbl_CarModel.text =  [responseObject valueForKey:@"car_model"];
        self.lbl_CarYear.text =  [responseObject valueForKey:@"car_year"];

        

        
        
        
     
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"Error: %@", error);
        
        
        
    }];
    
    
}


-(void)getAccountSettings
{
    
    
    
    //[Lockbox setString:[responseObject valueForKey:@"id"] forKey:@"id"];
    
    //[Lockbox stringForKey:@"id"];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *settingsUrl = [NSString stringWithFormat:@"%@get_security_setting", SERVER_URL];
    NSDictionary *params = @{@"user_id": [Lockbox stringForKey:@"id"]
                             
                             };
    
    [manager POST:settingsUrl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"response: %@", responseObject);
        
        self.txt_accountEmail.text =  [responseObject valueForKey:@"email"];
       
        
        self.txt_accountPhone.text =  [responseObject valueForKey:@"phone"];
        
        
        self.lbl_AccountEmail.text =  [responseObject valueForKey:@"email"];
        
        
        self.lbl_AccountPhone.text =  [responseObject valueForKey:@"phone"];
     
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"Error: %@", error);
        
        
        
    }];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)valuechanged:(id)sender {
    
    UISegmentedControl *segmentedControl = (UISegmentedControl *) sender;
    NSInteger selectedSegment = segmentedControl.selectedSegmentIndex;
    
    if (selectedSegment == 0)
    {
    
        [_generalView setHidden:NO];
        [_carView setHidden:YES];
        [_accountView setHidden:YES];
        
    
    }
    else if (selectedSegment == 1)
    {
        
        [_generalView setHidden:YES];
        [_carView setHidden:NO];
        [_accountView setHidden:YES];

    }
    if (selectedSegment == 2)
    {
       
        [_generalView setHidden:YES];
        [_carView setHidden:YES];
        [_accountView setHidden:NO];
    }

    
}
- (IBAction)ageChanged:(UISegmentedControl *)sender
{
}
- (IBAction)btn_Calendar:(id)sender
{
    NSLog(@"hi");
    
    
    self.accountView.hidden = YES;
    self.generalView.hidden = YES;
    self.carView.hidden = YES;
    self.segmentedcontrol.hidden = YES;
    
    
    self.datePickerView.hidden = NO;
    
    
}
- (IBAction)btn_ClickSaveCar:(id)sender
{
    BOOL tempBool= [[NSUserDefaults standardUserDefaults] boolForKey:@"isCarDetailsAdded"];
    
    
    if(!tempBool)
    {
        [self addCarDetails];
    }
    else
    {
        [self editCarDetails];
    }
    
}

-(void)addCarDetails
{
    
    
    if([self.btn_SaveCar.currentTitle  isEqual: @"Edit"])
    {
        
        
        [self showCarTextFeilds];
        
        [_btn_SaveCar setTitle: @"Save" forState: UIControlStateNormal];
        
    }
    
    else if ([self.btn_SaveCar.currentTitle  isEqual: @"Save"])
        
    {

        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
     
        
        
        NSString *settingsUrl = [NSString stringWithFormat:@"%@add_car_details", SERVER_URL];
        NSDictionary *params = @{ @"user_id": [Lockbox stringForKey:@"id"],
                                  @"car_make":self.txt_carMake.text,
                                  @"car_model":self.txt_carModel.text,
                                  @"car_year":self.txt_carYear.text,
                                  @"engine_no":self.txt_CarEngineNo.text,
                                  
                                  };
        [manager POST:settingsUrl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             
             NSLog(@"response: %@", responseObject);
             
             
             
             if([[[responseObject valueForKey:@"success"] stringValue]  isEqual: @"1"])
             {
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success"
                                                                 message:@"Your values have been updated"
                                                                delegate:self
                                                       cancelButtonTitle:@"OK"
                                                       otherButtonTitles:nil];
                 [alert show];
                 
                 [self getCarSettings];
                 [_btn_SaveCar setTitle: @"Edit" forState: UIControlStateNormal];
                 
                 
                 
                 
                 
                 [self hideCarTextFeilds];
                 
                 
                 
                 [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isCarDetailsAdded"];
                 
                 
             }
             else
             {
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ooops"
                                                                 message:@"Something Went wrong"
                                                                delegate:self
                                                       cancelButtonTitle:@"OK"
                                                       otherButtonTitles:nil];
                 [alert show];
                 
                 
             }
             
             
             
             
             
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             [MBProgressHUD hideHUDForView:self.view animated:YES];
             
             NSLog(@"Error: %@", error);
             
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ooops"
                                                             message:error.localizedDescription
                                                            delegate:self
                                                   cancelButtonTitle:@"OK"
                                                   otherButtonTitles:nil];
             [alert show];
             
             
         }];
    }
    

}
-(void) editCarDetails
{
    
    
    if([self.btn_SaveCar.currentTitle  isEqual: @"Edit"])
    {
        
        
        [self showCarTextFeilds];
        
        [_btn_SaveCar setTitle: @"Save" forState: UIControlStateNormal];
        
    }
    
    else if ([self.btn_SaveCar.currentTitle  isEqual: @"Save"])
        
    {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSString *settingsUrl = [NSString stringWithFormat:@"%@edit_car_details", SERVER_URL];
        NSDictionary *params = @{ @"user_id": [Lockbox stringForKey:@"id"],
                                  @"car_make":self.txt_carMake.text,
                                  @"car_model":self.txt_carModel.text,
                                  @"car_year":self.txt_carYear.text,
                                  @"engine_no":self.txt_CarEngineNo.text,
                                  
                                  };
        
        [manager POST:settingsUrl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             
             NSLog(@"response: %@", responseObject);
             
             
             
             if([[[responseObject valueForKey:@"success"] stringValue]  isEqual: @"1"])
             {
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success"
                                                                 message:@"Your values have been updated"
                                                                delegate:self
                                                       cancelButtonTitle:@"OK"
                                                       otherButtonTitles:nil];
                 [alert show];
                 
                 [self getCarSettings];
                 [_btn_SaveCar setTitle: @"Edit" forState: UIControlStateNormal];
                 
                 
                 
                 
                 
                 [self hideCarTextFeilds];
                 
                 
                 
                 
                 
                 
                 
             }
             else
             {
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ooops"
                                                                 message:@"Something Went wrong"
                                                                delegate:self
                                                       cancelButtonTitle:@"OK"
                                                       otherButtonTitles:nil];
                 [alert show];
                 
                 
             }
             
             
             
             
             
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             [MBProgressHUD hideHUDForView:self.view animated:YES];
             
             NSLog(@"Error: %@", error);
             
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ooops"
                                                             message:error.localizedDescription
                                                            delegate:self
                                                   cancelButtonTitle:@"OK"
                                                   otherButtonTitles:nil];
             [alert show];
             
             
         }];
    }
    

}

- (IBAction)setDate:(id)sender {
    
    self.datePickerView.hidden = YES;
    
    
    self.accountView.hidden = NO;
    self.generalView.hidden = NO;
    self.carView.hidden = NO;
     self.segmentedcontrol.hidden = NO;

    
}
- (IBAction)btn_ClickSaveAccount:(id)sender
{
    
    
    
    if([self.btn_saveAccount.currentTitle  isEqual: @"Edit"])
    {
        
        
        [self showAccountTextFeilds];
        
        [_btn_saveAccount setTitle: @"Save" forState: UIControlStateNormal];
        
    }
    
    else if ([self.btn_saveAccount.currentTitle  isEqual: @"Save"])
        
    {
        

    
    
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *settingsUrl = [NSString stringWithFormat:@"%@security_setting", SERVER_URL];
    
    
    
    
    NSDictionary *params = @{
                              @"user_id": [Lockbox stringForKey:@"id"],
                              @"phone": self.txt_accountPhone.text,
                              @"email":self.txt_accountEmail.text,
                              @"retype_password":self.txt_accountRetypePassword.text,
                              @"password":self.txt_accountPassword.text,
                              
                              };
    [manager POST:settingsUrl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"response: %@", responseObject);
        if([[[responseObject valueForKey:@"success"] stringValue]  isEqual: @"1"])
        {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success"
                                                        message:@"Your values have been updated"
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
            
        [alert show];
        [self getAccountSettings];
        [_btn_saveAccount setTitle: @"Edit" forState: UIControlStateNormal];
        [self hideAccountTextFeilds];
            
        
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ooops"
                                                            message:[responseObject valueForKey:@"error"]
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
            

        }
        
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"Error: %@", error);
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ooops"
                                                        message:error.localizedDescription
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];

        
        
        
    }];
    }

}

-(void)showgeneralTextFeilds
{
  
    
    self.txt_GeneralAge.hidden = NO;
    self.txt_GeneralCountry.hidden = NO;
    self.txt_GeneralFName.hidden = NO;
    self.txt_GeneralLName.hidden = NO;
    self.txt_GeneralAddress.hidden = NO;
    self.txt_GeneralAge.hidden = NO;
    self.dateImageBackground.hidden = NO;
    self.dateImageButton.hidden = NO;
    
    
    self.lbl_GeneralFirstName.hidden = YES;
    
    self.label_GeneralLastName.hidden = YES;
    
    self.lbl_GeneralCountry.hidden = YES;

    self.lbl_GeneralBirthDate.hidden = YES;

    self.lbl_GeneralAddress.hidden = YES;
    
    
   

   
}



-(void)hideGeneralTextFeilds
{
    
    
    self.txt_GeneralAge.hidden = YES;
    self.txt_GeneralCountry.hidden = YES;
    self.txt_GeneralFName.hidden = YES;
    self.txt_GeneralLName.hidden = YES;
    self.txt_GeneralAddress.hidden = YES;
    self.txt_GeneralAge.hidden = YES;
    self.dateImageBackground.hidden = YES;
    self.dateImageButton.hidden = YES;
    
    
    
    
    
    self.lbl_GeneralFirstName.hidden = NO;
    
    self.label_GeneralLastName.hidden = NO;
    
    self.lbl_GeneralCountry.hidden = NO;
    
    self.lbl_GeneralBirthDate.hidden = NO;
    
    self.lbl_GeneralAddress.hidden = NO;
    
}

-(void)showCarTextFeilds
{
  
    self.txt_carMake.hidden = NO;
    self.txt_carModel.hidden = NO;
    self.txt_carYear.hidden = NO;
    self.txt_CarEngineNo.hidden = NO;
   
     self.lbl_CarEngineNo.hidden = YES;
     self.lbl_CarMake.hidden = YES;
     self.lbl_CarModel.hidden = YES;
     self.lbl_CarYear.hidden = YES;
    
    
    
    
}



-(void)hideCarTextFeilds
{
    
   
    self.txt_carMake.hidden = YES;
    self.txt_carModel.hidden = YES;
    self.txt_carYear.hidden = YES;
    self.txt_CarEngineNo.hidden = YES;
    
    
    
    self.lbl_CarEngineNo.hidden = NO;
    self.lbl_CarMake.hidden = NO;
    self.lbl_CarModel.hidden = NO;
    self.lbl_CarYear.hidden = NO;
    
}



-(void)showAccountTextFeilds
{
    
    
     self.txt_accountEmail.hidden = NO;
     self.txt_accountPassword.hidden = NO;
     self.txt_accountRetypePassword.hidden = NO;
     self.txt_accountPhone.hidden = NO;
    
    
      self.lbl_AccountPhone.hidden = YES;
      self.lbl_AccountReTypePassword.hidden = YES;
      self.lbl_AccountEmail.hidden = YES;
      self.lblAccountPassword.hidden = YES;
    
}



-(void)hideAccountTextFeilds
{
    
    
  
    self.txt_accountEmail.hidden = YES;
    self.txt_accountPassword.hidden = YES;
    self.txt_accountRetypePassword.hidden = YES;
    self.txt_accountPhone.hidden = YES;
    
    
    self.lbl_AccountPhone.hidden = NO;
    self.lbl_AccountReTypePassword.hidden = NO;
    self.lbl_AccountEmail.hidden = NO;
    self.lblAccountPassword.hidden = NO;

   
    
}





- (IBAction)btn_ClickSaveGeneral:(id)sender
{
    
    
    if([self.btn_saveGeneral.currentTitle  isEqual: @"Edit"])
    {
        
        
        [self showgeneralTextFeilds];
        
    [_btn_saveGeneral setTitle: @"Save" forState: UIControlStateNormal];
        
    }
    
    else if ([self.btn_saveGeneral.currentTitle  isEqual: @"Save"])
    
    {
    
    
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *settingsUrl = [NSString stringWithFormat:@"%@personal_setting", SERVER_URL];
    
    NSString *tempGender;
    if(self.segmeneAge.selectedSegmentIndex == 0)
    {
        tempGender = @"Male";
    }
    else
    {
        tempGender = @"Female";
    }
    
    
    NSDictionary *params = @{
                             @"user_id": [Lockbox stringForKey:@"id"],
                             @"first_name": self.txt_GeneralFName.text,
                             @"last_name": self.txt_GeneralLName.text,
                             @"country":self.txt_GeneralCountry.text,
                             @"address":self.txt_GeneralAddress.text,
                             @"gender":tempGender,
                             @"dob":self.txt_GeneralAge.text,
                             
                             };
    [manager POST:settingsUrl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"response: %@", responseObject);
        
        if([[[responseObject valueForKey:@"success"] stringValue]  isEqual: @"1"])
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success"
                                                            message:@"Your values have been updated"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
            [self getGeneralSettings];
            [_btn_saveGeneral setTitle: @"Edit" forState: UIControlStateNormal];
            [self hideGeneralTextFeilds];
            
            
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ooops"
                                                            message:@"Something Went wrong"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
            
            
        }
        
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"Error: %@", error);
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ooops"
                                                        message:error.localizedDescription
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        
        
        
        
    }];
    }
    
}
- (IBAction)pickerAction:(id)sender {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"dd-MM-yyyy"];
    
    NSString *formatedDate = [dateFormatter stringFromDate:self.datePicker.date];
    
    self.txt_GeneralAge.text =formatedDate;
}
- (IBAction)btn_ClickLogout:(id)sender
{
    
    
    UIAlertView *alertLogout = [[UIAlertView alloc] initWithTitle:@"Logout?"
                                                    message:@"Are you sure you want to logout?"
                                                   delegate:self
                                          cancelButtonTitle:@"NO"
                                          otherButtonTitles:@"YES",nil];
    [alertLogout show];
    
    


    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if([alertView.title isEqualToString:@"Logout?"] && buttonIndex!=nil)
    {
        
        [devObj disconnectConnection];
        
        
        NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
        
        [defaults setValue:false forKey:@"logged_in"];
        
        //    NSString * storyboardName = @"Main";
        //    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        //    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"login"];
        //    [self presentViewController:vc animated:YES completion:nil];
        //
        
        UIViewController* rootController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"login"];
        UINavigationController* navigation = [[UINavigationController alloc] initWithRootViewController:rootController];
        AppDelegate *apps= (AppDelegate *)[[UIApplication sharedApplication] delegate];
        apps.window.rootViewController = navigation;
    }
}
- (IBAction)ShowDashBoardBtnAction:(id)sender
{
    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:dashLinkStr]]) {

        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:dashLinkStr]];
    }
}
- (IBAction)backaction:(id)sender {
    
   // [self dismissViewControllerAnimated:YES completion:nil];
    [self.navigationController popViewControllerAnimated:YES];
    
}
@end
