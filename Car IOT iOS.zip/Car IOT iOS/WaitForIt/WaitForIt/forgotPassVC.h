//
//  forgotPassVC.h
//  WaitForIt
//
//  Created by Dev on 12/10/15.
//  Copyright © 2015 Exosite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginHelper.h"
#import "Reachability.h"

@interface forgotPassVC : UIViewController


@property (weak, nonatomic) IBOutlet UITextField *txtEmail;

- (IBAction)resetBtnAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *resetBtn;





- (IBAction)backEvent:(id)sender;

@end
