//
//  AppDelegate.h
//  WaitForIt
//
//  Created by Michael Conrad Tadpol Tilstra on 12/11/14.
//  Copyright (c) 2014 Exosite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Reachability.h"
#import "BLEManager.h"
#import "Queue.h"
#import <GoogleMaps/GoogleMaps.h>



@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) BLEManager * bleManager;
@property (nonatomic, strong) Queue *queueManager;
@property (nonatomic, strong) NSString *CIK;
@property (nonatomic, strong) CBPeripheral *currentConnectedPeripheral;

+(AppDelegate *)sharedAppDelegate;
-(void)showToastMessage:(NSString *)message;
-(BOOL)connected;
-(BOOL)isValidEmailAddress:(NSString *)email;

@end

