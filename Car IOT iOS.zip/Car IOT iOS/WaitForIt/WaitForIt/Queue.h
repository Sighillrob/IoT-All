//
//  Queue.h
//  obd2
//
//  Created by Madhu V Swamy on 12/08/15.
//  Copyright (c) 2015 Cumulations Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Queue : NSObject{
//    NSMutableArray* objects;
}
@property (nonatomic, retain) NSMutableArray *objects;
- (void)addObject:(id)object;
- (id)takeObject;
- (void)clear;
@end
