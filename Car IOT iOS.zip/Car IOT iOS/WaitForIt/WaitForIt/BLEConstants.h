//
//  BLEConstants.h
//  obd2
//
//  Created by Madhu V Swamy on 10/08/15.
//  Copyright (c) 2015 Cumulations Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BLEConstants : NSObject

//Notifications
extern NSString * const kNotificationDiscoveredDevice;
extern NSString * const kBLEPeripheral;
extern NSString * const kBLEPeripheralName;
extern NSString * const kNotificationDeviceDisconnected;
extern NSString * const kNotificationDeviceFailedToConnect;
extern NSString * const kNotificationCodeResult;
extern NSString * const kCode;
extern NSString * const kCodeName;
extern NSString * const kCodeUnits;
extern NSString * const kCodeResult;
extern NSString * const kErrorType;
extern NSString * const kBLEPeripheralConnected;
extern NSString * const kNotificationErrorInRecieving;
extern NSString * const kErrorMessage;

//UUIDS
extern NSString * const kUUIDSTR_ISSC_PROPRIETARY_SERVICE;
extern NSString * const kUUIDSTR_CONNECTION_PARAMETER_CHAR;
extern NSString * const kUUIDSTR_ISSC_TRANS_TX;
extern NSString * const kUUIDSTR_ISSC_TRANS_RX;
extern NSString * const kUUIDSTR_ISSC_MP;

@end
