 //
//  DevicesListVC.m
//  WaitForIt
//
//  Created by AC on 13/08/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import "DevicesListVC.h"
#import "MBProgressHUD.h"
#import "AppDelegate.h"
#import "settingsViewController.h"

@interface DevicesListVC (){
    
    NSTimer *timerForConnectDevice;
    int isDisconnectFromLogout,isConnected;
   
}

@end

@implementation DevicesListVC
@synthesize devices,deviceUUIDs,HUD;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    isDisconnectFromLogout=0;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [self setNeedsStatusBarAppearanceUpdate];
    self.moveNextButton.userInteractionEnabled=NO;
 
    
    
    deviceUUIDs = [[NSMutableArray alloc]init];
    devices = [[NSMutableArray alloc]init];
    self.devicesTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
   // NSString *asdf=[devices objectAtIndex:100];

}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    isConnected=0;

    
    [[AppDelegate sharedAppDelegate].bleManager scanBLEDevices];
    
    
    /*
     Adding observers for notifications for 
     1. New device discovered
     2. Device Connected
     3. Device disconnected
     4. device failed to connect
     */
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(deviceDiscovered:) name:kNotificationDiscoveredDevice
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceConnected:) name:kBLEPeripheralConnected object:nil];
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceDisConnected:) name:kNotificationDeviceDisconnected object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceFailedToConnect:) name:kNotificationDeviceFailedToConnect object:nil];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


//Checks whether the device Bluetooth is ON

- (void)detectBluetooth
{
    if(!self.bluetoothManager)
    {
        // Put on main queue so we can call UIAlertView from delegate callbacks.
        self.bluetoothManager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_main_queue()];
    }
 }

- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    NSString *stateString = nil;
    switch(self.bluetoothManager.state)
    {
        case CBCentralManagerStateResetting: stateString = @"The connection with the system service was momentarily lost, update imminent."; break;
        case CBCentralManagerStateUnsupported: stateString = @"The platform doesn't support Bluetooth Low Energy."; break;
        case CBCentralManagerStateUnauthorized: stateString = @"The app is not authorized to use Bluetooth Low Energy."; break;
        case CBCentralManagerStatePoweredOff: stateString = @"Bluetooth is currently powered off. Please turn it on."; break;
      
        default: stateString = @"State unknown, update imminent."; break;
    }

    if(![stateString isEqualToString:@"State unknown, update imminent."])
    {
    UIAlertView *alertBluetooth = [[UIAlertView alloc] initWithTitle:@"Bluetooth state"
                                                    message:stateString
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alertBluetooth show];
    }
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{

    
    if([alertView.title isEqualToString:@"Unable to connect"])
    {
      //  if([alertView buttonTitleAtIndex:buttonIndex] isEqualToString:<#(nonnull NSString *)#>)
       // [self.navigationController popToRootViewControllerAnimated:YES];
       // [self refreshButtonAction:nil];
        [self disconnectConnection];
    }
}

// method called when device failed to connect notification arrives
-(void )deviceFailedToConnect:(NSNotification *)notification
{
    [timerForConnectDevice invalidate];
       [HUD hide:YES];
    UIAlertView *alertFailed = [[UIAlertView alloc] initWithTitle:@"Failed to Connect"
                                                    message:@"Unable to connect to device. Try replugging in the device to the OBD port or restart Bluetooth on your phone"
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alertFailed show];
}

// method called when device disconnected notification arrives
-(void )deviceDisConnected:(NSNotification *)notification
{
    [timerForConnectDevice invalidate];

    [HUD hide:YES];
    // checking to avoid alert if disconnect after logout by user
    if(isDisconnectFromLogout==1) {
    UIAlertView *alertFailed = [[UIAlertView alloc] initWithTitle:@"Device Disconnected"
                                                          message:@"Unable to connect to device. Try replugging in the device to the OBD port or restart Bluetooth on your phone"
                                                         delegate:self
                                                cancelButtonTitle:@"Okay"
                                                otherButtonTitles:nil];
    [alertFailed show];
    }
    isDisconnectFromLogout=0;
}


// method called when new device discoverd notification arrives
-(void)deviceDiscovered:(NSNotification *)notification
{
    [timerForConnectDevice invalidate];
    NSLog(@"Discovered:%@",[[notification userInfo] objectForKey:kBLEPeripheralName]);
    
    CBPeripheral *periferalDetected = [[notification userInfo] objectForKey:kBLEPeripheral];
    NSString *uuid = [[periferalDetected identifier] UUIDString];
    NSLog(@"Detected %@ %@",[periferalDetected name],uuid);
    
    if([deviceUUIDs count]==0){
        [deviceUUIDs addObject:uuid];
        [devices addObject:periferalDetected];
    }else if(![deviceUUIDs containsObject:uuid]){
        [deviceUUIDs addObject:uuid];
        [devices addObject:periferalDetected];
    }
    [self.devicesTableView reloadData];
    
  
}


 // method called when device connected notification

- (void)deviceConnected:(NSNotification *)notification
{
   
    [timerForConnectDevice invalidate];
    self.moveNextButton.userInteractionEnabled=YES;
    CBPeripheral *periferalDetected = [[notification userInfo] objectForKey:kBLEPeripheral];
    
    // keeping a copy of currently connected peripheral
    AppDelegate *appD=(AppDelegate *) [[UIApplication sharedApplication]delegate];
    appD.currentConnectedPeripheral=periferalDetected;
    if (periferalDetected!=nil && periferalDetected.state==CBPeripheralStateConnected) {
       // AppDelegate *apps = (AppDelegate *)[[UIApplication sharedApplication] delegate];
   
        [HUD hide:YES];
        [devices removeAllObjects];
      
        // removing notification observers in this view
        [[NSNotificationCenter defaultCenter] removeObserver:self name:kNotificationDeviceDisconnected object:nil];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:kNotificationDeviceFailedToConnect object:nil];
        if(isConnected==0) {
            [self performSegueWithIdentifier:@"showAllStats" sender:self];
            isConnected=1;
        }
        
          [deviceUUIDs removeAllObjects];
        [self.devicesTableView reloadData];
        NSLog(@"Connected to device");
        
    }
    else
    {

        [[AppDelegate sharedAppDelegate].bleManager connectToDevice:periferalDetected];
    }
}


-(void) cantConnectionVehicleMethod
{
    [HUD hide:YES];
    UIAlertView *alertCantConnect = [[UIAlertView alloc] initWithTitle:@"Unable to connect"
                                                             message:@"Unable to connect to your car. Try turning on your engine and reconnecting with the device."
                                                            delegate:self
                                                   cancelButtonTitle:nil
                                                   otherButtonTitles:@"RETRY",@"CANCEL",nil];
    [alertCantConnect show];
}

#pragma mark - Tableview Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return devices.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CellIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"CellIdentifier"];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor clearColor];
    
    CBPeripheral *periferalDetected = [devices objectAtIndex:indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[periferalDetected name]];
    cell.textLabel.textColor = [UIColor whiteColor];
    
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@",[[periferalDetected identifier] UUIDString]];
    cell.detailTextLabel.textColor = [UIColor whiteColor];

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    CBPeripheral *periferalDetected = [devices objectAtIndex:indexPath.row];
   
    
    
    // connecting to the selected device
    
    [[AppDelegate sharedAppDelegate].bleManager connectToDevice:periferalDetected];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.labelText = @"Pairing Device";
    HUD.detailsLabelText = @"Please Wait";
    [self.view addSubview:HUD];
      HUD.mode = MBProgressHUDModeIndeterminate;
    [HUD show:YES];
    
    // timer to check whether the connection attempt goes more than 30 sec.
    timerForConnectDevice= [NSTimer scheduledTimerWithTimeInterval:30.0
                                                            target:self
                                                          selector:@selector(cancelConnection)
                                                          userInfo:nil
                                                           repeats:NO];


}


// cancelling connection if couldnt proceed with the connection (timer method)

-(void)cancelConnection
{
    [timerForConnectDevice invalidate];
    AppDelegate *appD=(AppDelegate *) [[UIApplication sharedApplication]delegate];
     [[AppDelegate sharedAppDelegate].bleManager cancelConnectionWithDevice:appD.currentConnectedPeripheral];
    HUD.mode = MBProgressHUDModeText;
    HUD.labelText=@"Couldn't Connect";
    HUD.detailsLabelText=@"";
    [HUD hide:YES afterDelay:1.0f];
    
    
}

// Method to manually  disconnect connection with the connected device

-(void) disconnectConnection
{
    NSLog(@"Disconnecting From DevicesListVC");
    AppDelegate *appD=(AppDelegate *) [[UIApplication sharedApplication]delegate];
    isDisconnectFromLogout=1;
    [[AppDelegate sharedAppDelegate].bleManager cancelConnectionWithDevice:appD.currentConnectedPeripheral];

}

// method for arrow button

- (IBAction)moveNext:(id)sender {
    [self performSegueWithIdentifier:@"showAllStats" sender:self];
}

-(void) hideHUD
{
    [HUD hide:YES];
}

// Method to refresh the list of details

- (IBAction)refreshButtonAction:(id)sender
{
    [devices removeAllObjects];
    [deviceUUIDs removeAllObjects];
    [self.devicesTableView reloadData];
    
    
    [self detectBluetooth];
    [timerForConnectDevice invalidate];
      [[AppDelegate sharedAppDelegate].bleManager scanBLEDevices];

}

- (IBAction)goToSettingsAction:(id)sender
{
    settingsViewController *vc = [[settingsViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}
@end
