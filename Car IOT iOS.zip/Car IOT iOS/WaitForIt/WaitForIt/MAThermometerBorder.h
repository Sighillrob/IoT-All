//
//  MAThermometerBorder.h
//  MAThermometer-Demo
//
//  Created by Michael Azevedo on 17/06/2014.
//

#import <UIKit/UIKit.h>

@interface MAThermometerBorder : UIView

@property (nonatomic, assign) BOOL darkTheme;
@property (nonatomic, assign) BOOL glassEffect;

@end
