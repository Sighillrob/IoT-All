//
//  ViewController.m
//  WaitForIt
//
//  Created by Michael Conrad Tadpol Tilstra on 12/11/14.
//  Copyright (c) 2014 Exosite. All rights reserved.
//

#import "ViewController.h"
#import "KAProgressLabel.h"
#import "WaitForItWorker.h"

@interface ViewController ()
@property (weak,nonatomic) IBOutlet UIButton *setupButton;

@property (weak,nonatomic) IBOutlet UILabel *waitedLabel;
@property (weak,nonatomic) IBOutlet UILabel *faderLabel;

@property (weak,nonatomic) IBOutlet UILabel *actualLabel;
@property (weak,nonatomic) IBOutlet UILabel *rateLabel;
@property (weak,nonatomic) IBOutlet UISlider *rateSlider;

@property (weak, nonatomic) IBOutlet UILabel *actualLabel2;
@property (weak, nonatomic) IBOutlet UILabel *rateLabel2;
@property (weak, nonatomic) IBOutlet UISlider *rateSlider2;

@property (weak, nonatomic) IBOutlet UILabel *actualLabel3;
@property (weak, nonatomic) IBOutlet UILabel *rateLabel3;
@property (weak, nonatomic) IBOutlet UISlider *rateSlider3;


@property (weak, nonatomic) IBOutlet UILabel *actualLabel4;
@property (weak, nonatomic) IBOutlet UILabel *rateLabel4;
@property (weak, nonatomic) IBOutlet UISlider *rateSlider4;

@property (weak, nonatomic) IBOutlet UIButton *crash;

@property (weak, nonatomic) IBOutlet UIButton *service;
@property (weak, nonatomic) IBOutlet UIButton *critical;


@property (strong,nonatomic) WaitForItWorker *waiter, *waiter2, *waiter3, *waiter4, *waiter5, *waiter6, *waiter7;
@property (strong,nonatomic) NSDate *last;
@property (assign,nonatomic) NSUInteger lastDelay;

@property(nonatomic, strong) NSTimer *incrementTimer;
@property (weak,nonatomic) IBOutlet KAProgressLabel * myProgressLabel;


@end

int flag=0, button_value=0, service_btn_value=0, critical_btn_value=0, increment_val=0;

@implementation ViewController
@synthesize myProgressLabel;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.waiter = [WaitForItWorker new];
    self.waiter2 = [WaitForItWorker new];
    self.waiter3 = [WaitForItWorker new];
    self.waiter4 = [WaitForItWorker new];
    self.waiter5 = [WaitForItWorker new];
    self.waiter6 = [WaitForItWorker new];
    self.waiter7 = [WaitForItWorker new];


    [self createRoundProgessView];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    self.setupButton.enabled = !self.waiter.isSetup;
    self.setupButton.enabled = !self.waiter2.isSetup;
    self.setupButton.enabled = !self.waiter3.isSetup;
    self.setupButton.enabled = !self.waiter4.isSetup;
    self.setupButton.enabled = !self.waiter5.isSetup;
    self.setupButton.enabled = !self.waiter6.isSetup;
    self.setupButton.enabled = !self.waiter7.isSetup;
    
    
    self.waitedLabel.text = @"";
    self.rateLabel.text = [NSString stringWithFormat:@"%u", (unsigned int)self.rateSlider.value];
    self.rateLabel2.text = [NSString stringWithFormat:@"%u", (unsigned int)self.rateSlider2.value];
    self.rateLabel3.text = [NSString stringWithFormat:@"%u", (unsigned int)self.rateSlider3.value];
    self.rateLabel4.text = [NSString stringWithFormat:@"%u", (unsigned int)self.rateSlider4.value];
    
   
}

- (void)letsWait {
    if ([[UIApplication sharedApplication] applicationState] != UIApplicationStateActive) {
        return;
    }

    [self.waiter waitForIt:^(NSNumber *number, NSError *error) {
        if (number) {
            self.waitedLabel.text = [NSString stringWithFormat:@"%u", number.intValue];
        } else if (error) {
            self.waitedLabel.text = [error description];
        }
        self.faderLabel.text = self.waitedLabel.text;
        self.faderLabel.alpha = 1.0;
        [UIView animateWithDuration:1.0 animations:^{
            self.faderLabel.alpha = 0;
        }];

        NSDate *now = [NSDate date];
        self.lastDelay = [now timeIntervalSince1970] - [self.last timeIntervalSince1970];
        self.last = now;
        self.actualLabel.text = [NSString stringWithFormat:@"%lu", (unsigned long)self.lastDelay];

        [self letsWait];
    }];
}

- (void)letsWait2 {

    [self.waiter2 waitForIt2:^(NSNumber *number, NSError *error) {
        if (number) {
            self.waitedLabel.text = [NSString stringWithFormat:@"%u", number.intValue];
        } else if (error) {
            self.waitedLabel.text = [error description];
        }
        self.faderLabel.text = self.waitedLabel.text;
        self.faderLabel.alpha = 1.0;
        [UIView animateWithDuration:1.0 animations:^{
            self.faderLabel.alpha = 0;
        }];
        
        NSDate *now = [NSDate date];
        self.lastDelay = [now timeIntervalSince1970] - [self.last timeIntervalSince1970];
        self.last = now;
        self.actualLabel2.text = [NSString stringWithFormat:@"%lu", (unsigned long)self.lastDelay];
        
        [self letsWait2];
    }];
}

- (void)letsWait3 {
    
    [self.waiter3 waitForIt3:^(NSNumber *number, NSError *error) {
        if (number) {
            self.waitedLabel.text = [NSString stringWithFormat:@"%u", number.intValue];
        } else if (error) {
            self.waitedLabel.text = [error description];
        }
        self.faderLabel.text = self.waitedLabel.text;
        self.faderLabel.alpha = 1.0;
        [UIView animateWithDuration:1.0 animations:^{
            self.faderLabel.alpha = 0;
        }];
        
        NSDate *now = [NSDate date];
        self.lastDelay = [now timeIntervalSince1970] - [self.last timeIntervalSince1970];
        self.last = now;
        self.actualLabel3.text = [NSString stringWithFormat:@"%lu", (unsigned long)self.lastDelay];
        
        [self letsWait3];
    }];
}

- (void)letsWait4 {
    
    [self.waiter4 waitForIt4:^(NSNumber *number, NSError *error) {
        if (number) {
            self.waitedLabel.text = [NSString stringWithFormat:@"%u", number.intValue];
        } else if (error) {
            self.waitedLabel.text = [error description];
        }
        self.faderLabel.text = self.waitedLabel.text;
        self.faderLabel.alpha = 1.0;
        [UIView animateWithDuration:1.0 animations:^{
            self.faderLabel.alpha = 0;
        }];
        
        NSDate *now = [NSDate date];
        self.lastDelay = [now timeIntervalSince1970] - [self.last timeIntervalSince1970];
        self.last = now;
        self.actualLabel4.text = [NSString stringWithFormat:@"%lu", (unsigned long)self.lastDelay];
        
        [self letsWait4];
    }];
}


- (void)letsWait5 {
    
    [self.waiter5 waitForIt5:^(NSNumber *number, NSError *error) {
        if (number) {
            self.waitedLabel.text = [NSString stringWithFormat:@"%u", number.intValue];
        } else if (error) {
            self.waitedLabel.text = [error description];
        }
        self.faderLabel.text = self.waitedLabel.text;
        self.faderLabel.alpha = 1.0;
        [UIView animateWithDuration:1.0 animations:^{
            self.faderLabel.alpha = 0;
        }];
        
        NSDate *now = [NSDate date];
        self.lastDelay = [now timeIntervalSince1970] - [self.last timeIntervalSince1970];
        self.last = now;
        
        
        [self letsWait5];
    }];
}

- (void)letsWait6 {
    
    [self.waiter6 waitForIt6:^(NSNumber *number, NSError *error) {
        if (number) {
            self.waitedLabel.text = [NSString stringWithFormat:@"%u", number.intValue];
        } else if (error) {
            self.waitedLabel.text = [error description];
        }
        self.faderLabel.text = self.waitedLabel.text;
        self.faderLabel.alpha = 1.0;
        [UIView animateWithDuration:1.0 animations:^{
            self.faderLabel.alpha = 0;
        }];
        
        NSDate *now = [NSDate date];
        self.lastDelay = [now timeIntervalSince1970] - [self.last timeIntervalSince1970];
        self.last = now;
        
        
        [self letsWait6];
    }];
}

- (void)letsWait7 {
    
    [self.waiter7 waitForIt7:^(NSNumber *number, NSError *error) {
        if (number) {
            self.waitedLabel.text = [NSString stringWithFormat:@"%u", number.intValue];
        } else if (error) {
            self.waitedLabel.text = [error description];
        }
        self.faderLabel.text = self.waitedLabel.text;
        self.faderLabel.alpha = 1.0;
        [UIView animateWithDuration:1.0 animations:^{
            self.faderLabel.alpha = 0;
        }];
        
        NSDate *now = [NSDate date];
        self.lastDelay = [now timeIntervalSince1970] - [self.last timeIntervalSince1970];
        self.last = now;
        
        
        [self letsWait7];
    }];
}




#pragma mark - Actions

- (IBAction)doSetup:(id)sender {
    [self.waiter createPortsAndScripts];
    [self.waiter2 createPortsAndScripts];
    [self.waiter3 createPortsAndScripts];
    [self.waiter4 createPortsAndScripts];
    [self.waiter5 createPortsAndScripts];
    [self.waiter6 createPortsAndScripts];
    [self.waiter7 createPortsAndScripts];
    
    self.setupButton.enabled = !self.waiter.isSetup;
    self.setupButton.enabled = !self.waiter2.isSetup;
    self.setupButton.enabled = !self.waiter3.isSetup;
    self.setupButton.enabled = !self.waiter4.isSetup;
    self.setupButton.enabled = !self.waiter5.isSetup;
    self.setupButton.enabled = !self.waiter6.isSetup;
    self.setupButton.enabled = !self.waiter7.isSetup;
    
    [self performSelector:@selector(letsWait) withObject:nil afterDelay:3];
    [self performSelector:@selector(letsWait2) withObject:nil afterDelay:4];
    [self performSelector:@selector(letsWait3) withObject:nil afterDelay:4];
    
//    [self performSelector:@selector(letsWait4) withObject:nil afterDelay:10];
//    [self performSelector:@selector(letsWait5) withObject:nil afterDelay:5];
    [self performSelector:@selector(startTimer) withObject:nil afterDelay:1];
}

- (IBAction)updateSlider:(UISlider*)sender {
    
    self.rateLabel.text = [NSString stringWithFormat:@"%u", (unsigned int)sender.value];
}

- (IBAction)endSlider:(UISlider*)sender {
    
    [self.waiter setWaitRate:sender.value];
}


- (IBAction)updateSlider2:(UISlider*)sender {
   
    self.rateLabel2.text = [NSString stringWithFormat:@"%u", (unsigned int)sender.value];
}

- (IBAction)endSlider2:(UISlider*)sender {
    
    [self.waiter2 setWaitRate2:sender.value];
}

- (IBAction)updateSlider3:(UISlider*)sender {
    
    self.rateLabel3.text = [NSString stringWithFormat:@"%u", (unsigned int)sender.value];
}

- (IBAction)endSlider3:(UISlider*)sender {
    
    [self.waiter3 setWaitRate3:sender.value];
}

- (IBAction)updateSlider4:(UISlider*)sender {
    
    self.rateLabel4.text = [NSString stringWithFormat:@"%u", (unsigned int)sender.value];
}

- (IBAction)endSlider4:(UISlider*)sender {

    [self.waiter4 setWaitRate4:sender.value];
}


- (IBAction)crash:(id)sender {
    
    [self.waiter5 setWaitRate5:button_value];
    button_value++;
}

- (IBAction)service:(id)sender {

    [self.waiter6 setWaitRate6:service_btn_value];
    service_btn_value++;
}

- (IBAction)critical:(id)sender {
    
    
    NSString *tempStr=[NSString stringWithFormat:@"%d",critical_btn_value];
    [self.waiter7 setWaitRate7:tempStr];
    critical_btn_value++;
}

-(void) increaseValue {
    if (increment_val>280) {
        increment_val = 25;
        increment_val++;
    }
    else {
        increment_val++;
    }
    
//    self.rateSlider.value = (float)increment_val;
//    self.rateSlider2.value = (float)increment_val+5.0;
//    self.rateSlider3.value = (float)increment_val+10.0;
//    self.rateSlider4.value = (float)increment_val+20.0;
//    
//    [self.waiter setWaitRate:increment_val];
//    [self.waiter2 setWaitRate2:increment_val+5.0];
//    [self.waiter3 setWaitRate3:increment_val+10.0];
//    [self.waiter4 setWaitRate4:increment_val+20.0];

    NSLog(@"The increment valeue is --- %d",increment_val);
    //self.rateSlider.value = (float)increment_val;

}

-(void)startTimer {
    NSRunLoop *runloop = [NSRunLoop currentRunLoop];
    self.incrementTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(createRoundProgessView) userInfo:nil repeats:YES];
    [runloop addTimer:self.incrementTimer forMode:NSRunLoopCommonModes];
    [runloop addTimer:self.incrementTimer forMode:UITrackingRunLoopMode];
}


-(void)createRoundProgessView {
    myProgressLabel.labelVCBlock = ^(KAProgressLabel *label) {
        label.text = [NSString stringWithFormat:@"%.0f%%", (label.progress * 100)];
    };
    
    [myProgressLabel setProgressColor:[UIColor redColor]]; // black progress bar
    [myProgressLabel setTrackColor:[UIColor whiteColor]];  // gray track bar
    [myProgressLabel setFillColor:[UIColor clearColor]];   // transparent fill color
 
    [myProgressLabel setTrackWidth:2.0f];
    [myProgressLabel setRoundedCornersWidth:2.0f];
    [myProgressLabel setProgressWidth:3.0f];
    
    //float rndValue2 =  arc4random() % 360;
    
    if (increment_val>100) {
        increment_val = 0;
        increment_val+=10;
    }
    else {
        increment_val+=10;
    }

    float rndValue = increment_val % 100*0.01;

//    [myProgressLabel setStartDegree:rndValue timing:TPPropertyAnimationTimingLinear duration:1 delay:0]
//    [myProgressLabel setEndDegree:rndValue2 timing:TPPropertyAnimationTimingLinear duration:1 delay:0];
//    [myProgressLabel  sette]
    
    [myProgressLabel setProgress:rndValue timing:TPPropertyAnimationTimingEaseInEaseOut duration:1.0 delay:0];
    //[myProgressLabel setProgress:(float)(increment_val/100)];
    
    NSLog(@"The increment value is --- %f",rndValue);

}

#pragma mark - delegate

- (void)progressLabel:(KAProgressLabel *)label dr:(CGFloat)progress
{
    [label setText:[NSString stringWithFormat:@"%.0f%%", (progress*100)]];
}

@end
