//
//  LoginViewController.h
//  SnackCaddy Golfer
//
//  Created by BHARATH L.N on 02/07/15.
//  Copyright (c) 2015 Mowares. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginHelper.h"
#import "Reachability.h"


@interface LoginViewController : UIViewController


@property (weak, nonatomic) IBOutlet UITextField *txt_username;
@property (weak, nonatomic) IBOutlet UITextField *txt_password;
@property (weak, nonatomic) IBOutlet UIButton *sign_in_btn;





@end
