//
//  AllStatsVC.m
//  WaitForIt
//
//  Created by AC on 12/08/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import "AllStatsVC.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "InfoVC.h"
#import "WaitForItWorker.h"
@import CoreLocation;


@interface AllStatsVC ()
@property (nonatomic, strong) CLLocationManager *locationManager;


@property (strong, nonatomic) IBOutlet UILabel *lblEngineRunTime;
@property (strong, nonatomic) IBOutlet UILabel *lblDistTravelled;
@property (strong, nonatomic) IBOutlet MBProgressHUD *HUD;



@end

@implementation AllStatsVC
{
    InfoVC *infoObj;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Get Total Distance travelled
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"0131"];
    
    // Get Total Engine running time
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"011f"];
    
    //Get Coolant temperature
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"0105"];
    
    
    _HUD = [[MBProgressHUD alloc] initWithView:self.view];
    _HUD.labelText = @"Please Wait";
    [self.view addSubview:_HUD];
    _HUD.mode = MBProgressHUDModeIndeterminate;
    [_HUD show:YES];
    //[_HUD hide:YES];
    //Get Location
   
   // [self getLocation];
    

   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
-(void )deviceFailedToConnect:(NSNotification *)notification
{
    //[self disconnectedDevices];
}
-(void )deviceDisConnected:(NSNotification *)notification
{
    [self disconnectedDevicesInAllStats];
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self getLocation];
    
        //self.navigationController.delegate = self;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showResults:) name:kNotificationCodeResult object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceDisConnected:) name:kNotificationDeviceDisconnected object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceFailedToConnect:) name:kNotificationDeviceFailedToConnect object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ErrorNotificationArrivedInAllStats:) name:kNotificationErrorInRecieving object:nil];
}
-(void)ErrorNotificationArrivedInAllStats:(NSNotification *)notification
{
    [_HUD hide:YES];
}
- (IBAction)showAllStatsEvent:(id)sender {
    [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"statType"];
    
    [self performSegueWithIdentifier:@"showIndividualStats" sender:self];
}


- (NSString *)timeFormatted:(int)totalSeconds {
    int seconds = totalSeconds % 60;
    int minutes = (totalSeconds / 60) % 60;
    int hours = totalSeconds / 3600;
    
    return [NSString stringWithFormat:@"%02d:%02d:%02d",hours, minutes, seconds];
}

- (IBAction)getStatsEvent:(id)sender {
   // Get Total Distance travelled
   [[AppDelegate sharedAppDelegate].bleManager sendData:@"0131"];
    
    // Get Total Engine running time
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"011f"];
    
    //Get Coolant temperature
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"0105"];
    
    //Get Location
    [self getLocation];
    
}

-(void)getLocation
{
   
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    // Check for iOS 8. Without this guard the code will crash with "unknown selector" on iOS 7.
    if ([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [self.locationManager requestWhenInUseAuthorization];
    }
    [self.locationManager startUpdatingLocation];
    NSLog(@"%f %f",_locationManager.location.coordinate.latitude, _locationManager.location.coordinate.longitude);
    
    
    
   
    NSString * getAddress = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/geocode/json?latlng=%f,%f&sensor=true",_locationManager.location.coordinate.latitude,_locationManager.location.coordinate.longitude];
    NSLog(@"ADDRESS %@", getAddress);
    
    CLGeocoder *geoCoder = [[CLGeocoder alloc]init];
    
    [geoCoder reverseGeocodeLocation:_locationManager.location completionHandler:^(NSArray *placemarks, NSError *error){
        CLPlacemark *placemark = placemarks[0];
        
        
        self.locationLabel.text=placemark.locality;
      
        
        
    }];

}

/*
 
 Codes for various parameters,
 • Engine RPM - 010C
 • Engine running time - 011F

 • Calculate engine load - 0104
 
 • Vehicle speed  - 010D
 • Vehicle running distance - 0131
 
*/

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
*/

- (IBAction)showParticularStatsEvent:(id)sender {
    /*
     StatType
     0 - All
     1 - Engine
     2 - Battery
     3 - Vehicle (Speed)
     */
    
    UIButton *btn = (UIButton *)sender;
    
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%d",[btn tag]] forKey:@"statType"];
    
    
    [self performSegueWithIdentifier:@"showIndividualStats" sender:self];
}



- (void)showResults:(NSNotification *)notification {
    
       [_HUD hide:YES];
    // Show Total Distance travelled
    if ([[[notification userInfo] objectForKey:kCode] isEqualToString:@"0131"]) {
        NSString *distanceStr = [NSString stringWithFormat:@"%@: %@%@",[[notification userInfo] objectForKey:kCodeName],[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        NSLog(@"DISTANCE - %@",distanceStr);
        
        self.distanceLabel.text=[NSString stringWithFormat:@"%@%@",[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        
                [[AppDelegate sharedAppDelegate].bleManager sendData:@"0131"];
        
    }
    
    
    // Show Total Engine Running time
    else if ([[[notification userInfo] objectForKey:kCode] isEqualToString:@"011f"]) {
        NSLog(@"reached");
        NSString *engineStr = [NSString stringWithFormat:@"%@: %@%@",[[notification userInfo] objectForKey:kCodeName],[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        NSLog(@"ENGINE RUNNING TIME - %@",engineStr);
        
        NSString *secondsStr = [NSString stringWithFormat:@"%@",[[notification userInfo] objectForKey:kCodeResult]];
        NSString *formattedStr = [self timeFormatted:[secondsStr intValue]];
        
        self.engineRunningLabel.text = formattedStr;
        
        [[AppDelegate sharedAppDelegate].bleManager sendData:@"011f"];

    }
    
    
    //Engine coolant temperature
    else if ([[[notification userInfo] objectForKey:kCode] isEqualToString:@"0105"]) {
        
        NSString *engineCoolant = [NSString stringWithFormat:@"%@: %@%@",[[notification userInfo] objectForKey:kCodeName],[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        NSLog(@"ENGINE COOLANT TEMP - %@",engineCoolant);
        
        NSString *secondsStr = [NSString stringWithFormat:@"%@",[[notification userInfo] objectForKey:kCodeResult]];
        NSString *formattedStr = [self timeFormatted:[secondsStr intValue]];
        
        
        self.temperatureLabel.text= [NSString stringWithFormat:@"%@%@",[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        
        [[AppDelegate sharedAppDelegate].bleManager sendData:@"0105"];
}
    
    
    
    
}

-(void)disconnectedDevicesInAllStats
{

    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Device got Disconnected"
                                                    message:@"Unable to connect to device. Try replugging in the device to the OBD port or restart Bluetooth on your phone"
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if([alertView.title isEqualToString:@"Device got Disconnected"])
    {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kNotificationCodeResult object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kNotificationDeviceDisconnected object:nil];
}




@end
