//
//  HomeVC.h
//  WaitForIt
//
//  Created by Dev on 06/08/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeVC : UIViewController

@end
