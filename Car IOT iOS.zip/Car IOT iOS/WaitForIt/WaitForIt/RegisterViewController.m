//
//  RegisterViewController.m
//  SnackCaddy Golfer
//
//  Created by BHARATH L.N on 03/07/15.
//  Copyright (c) 2015 Mowares. All rights reserved.
//

#import "RegisterViewController.h"
#import "Constants.h"
#import "AFNetworking.h"
#import "MBProgressHUD.h"
#import "JFMinimalNotification.h"
#import <QuartzCore/QuartzCore.h>
#import "RSKImageCropViewController.h"
#import "AppDelegate.h"
#import "LoginHelper.h"
#import "Lockbox.h"


@interface RegisterViewController () < JFMinimalNotificationDelegate, UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate>



@property (nonatomic, strong) JFMinimalNotification* minimalNotification;

@end


@implementation RegisterViewController
{
    NSString *userName,*passWord;
    MBProgressHUD * hud ;
}



-(void)viewDidLoad
{
   
    self.navigationController.navigationBarHidden=YES;
    
    
    self.signup_button.layer.cornerRadius = 25.0;
    self.txt_email.delegate = self;
    self.txt_lname.delegate = self;
    self.txt_name.delegate = self;
    self.txt_password.delegate = self;
    self.txt_phone.delegate = self;
    self.txt_retype.delegate = self;
    self.imageView.layer.cornerRadius = 40.0;
    self.imageView.clipsToBounds = YES;
    
    CALayer *imageLayer = _imageView.layer;
    [imageLayer setCornerRadius:20];
    [imageLayer setBorderWidth:2];
    [imageLayer setBorderColor:(__bridge CGColorRef)([UIColor whiteColor])];
    [imageLayer setMasksToBounds:YES];
    [_imageView.layer setCornerRadius:_imageView.frame.size.width/2];
    

}




-(void)viewDidAppear:(BOOL)animated
{

}

- (IBAction)backaction:(id)sender {
    	[self.navigationController popToRootViewControllerAnimated:YES];
    
}
//Since that method is already there, the void did disappear method is redundat



-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    textField.text = @"";
    [self.minimalNotification dismiss];
    
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
    [self.minimalNotification dismiss];
    
}



-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    if(textField.returnKeyType==UIReturnKeyNext) {
        UIView *next = [[textField superview] viewWithTag:textField.tag+1];
        [next becomeFirstResponder];
    } else if (textField.returnKeyType==UIReturnKeyDone) {
        [textField resignFirstResponder];
    }
    return YES;
}



// Sign UP

- (IBAction)signup_action:(id)sender {
    
    [self.txt_email endEditing:YES];
        [self.txt_lname endEditing:YES];
        [self.txt_name endEditing:YES];
        [self.txt_password endEditing:YES];
    [self.txt_retype endEditing:YES];
    [self.txt_phone endEditing:YES];
    
    
    NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
    
    if([[self.txt_email text] isEqualToString:@""])
    {
        
        
        self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleWarning
                                                                          title:@"Email can't be empty"
                                                                       subTitle:@"Please enter your email address"];
        
        [self.view addSubview:self.minimalNotification];
        [self.minimalNotification show];
        double delayInSeconds = 2.0;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            NSLog(@"Do some work");
            [self.minimalNotification dismiss];
            
            
        });

        
        
    }
    else if([[self.txt_lname text] isEqualToString:@""])
    {
        
        
        self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleWarning
                                                                          title:@"Last Name can't be empty"
                                                                       subTitle:@"Please enter your Last Name"];
        
        [self.view addSubview:self.minimalNotification];
        [self.minimalNotification show];
        double delayInSeconds = 2.0;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            NSLog(@"Do some work");
            [self.minimalNotification dismiss];
            
            
        });

        
        
    }
    else if([[self.txt_name text] isEqualToString:@""])
    {
        
        
        self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleWarning
                                                                          title:@"Last Name can't be empty"
                                                                       subTitle:@"Please enter your Last Name"];
        
        [self.view addSubview:self.minimalNotification];
        [self.minimalNotification show];
        double delayInSeconds = 2.0;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            NSLog(@"Do some work");
            [self.minimalNotification dismiss];
            
            
        });

        
        
    }
    else if([[self.txt_password text] isEqualToString:@""])
    {
        self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleWarning
                                                                          title:@"Password cannot be empty"
                                                                       subTitle:@"Please enter your Password"];
        
        [self.view addSubview:self.minimalNotification];
        [self.minimalNotification show];
        double delayInSeconds = 2.0;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            NSLog(@"Do some work");
            [self.minimalNotification dismiss];
            
            
        });


    }
    else if([[self.txt_retype text] isEqualToString:@""])
    {
        self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleWarning
                                                                          title:@"Password cannot be empty"
                                                                       subTitle:@"Please enter your Password"];
        
        [self.view addSubview:self.minimalNotification];
        [self.minimalNotification show];
        double delayInSeconds = 2.0;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            NSLog(@"Do some work");
            [self.minimalNotification dismiss];
            
            
        });
        
        
    }
    else if (![self.txt_password.text isEqualToString:self.txt_retype.text])
    {
        NSLog(@"%@",_txt_password.text);
        NSLog(@"%@",_txt_retype.text);
        self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleWarning
                                                                          title:@"Passwords do not match"
                                                                       subTitle:@"Make sure you passwords are same"];
        
        [self.view addSubview:self.minimalNotification];
        [self.minimalNotification show];
        double delayInSeconds = 2.0;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            NSLog(@"Do some work");
            [self.minimalNotification dismiss];
            
            
        });
        
        
    }
    
    else
    {

    NSData *imageData = UIImageJPEGRepresentation(self.imageView.image, 0.5);
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *imagePostUrl = [NSString stringWithFormat:@"%@signup", SERVER_URL];
    NSDictionary *params = @{@"email": self.txt_email.text,
                             @"password": self.txt_password.text,
                             @"first_name": self.txt_name.text,
                             @"last_name": self.txt_lname.text,
                             @"phone": self.txt_phone.text,
                             @"device_token": @"asdasdasdasd",
                             @"device_type": @"ios",
                             @"login_by": @"manual"};
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:imagePostUrl parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"picture" fileName:@"temp.jpg" mimeType:@"image/jpeg"];
    }];
    
    
        userName= self.txt_email.text;
        passWord= self.txt_password.text;
    
    
    hud =[MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    NSString *strloadingText = [NSString stringWithFormat:@"Please Wait"];
    NSString *strloadingText2 = [NSString stringWithFormat:@"Signing you up"];
    
    NSLog(@"the loading text will be %@",strloadingText);
    hud.labelText = strloadingText;
    hud.detailsLabelText=strloadingText2;
    
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.01 * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        // Do something...
        AFHTTPRequestOperation *op = [manager HTTPRequestOperationWithRequest:request success: ^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"response: %@", responseObject);
            NSLog(@"SUCCESS %@", [responseObject valueForKey:@"success"]);
            NSInteger success= [[responseObject valueForKey:@"success"] integerValue];
            if(success==1)
            {
                NSLog(@"reached");

            self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleSuccess
                                                                              title:@"Registration Successful"
                                                                           subTitle:@"Please Login to start using the app"];
            
            [self.view addSubview:self.minimalNotification];
            [self.minimalNotification show];
                hud.detailsLabelText=@"Login You in";
                
                AppDelegate *obj = (AppDelegate *)[[UIApplication sharedApplication]delegate];
                obj.CIK=[responseObject valueForKey:@"cik"];
                
            double delayInSeconds = 2.0;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                NSLog(@"Do some work");

                [self logINAfterSignUp];
            });
            }
            
            else
            {
            NSLog(@"reached else");
            [MBProgressHUD hideHUDForView:self.view animated:YES];
                NSString *errorStr= [NSString stringWithFormat:@"Error: %@",[responseObject valueForKey:@"error"] ];
                self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleInfo
                                                                                  title:@"Failed to SignUp"
                                                                               subTitle:errorStr];
                
                [self.view addSubview:self.minimalNotification];
                [self.minimalNotification show];
                double delayInSeconds = 2.0;
                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                    NSLog(@"Do some work");
                    [self.minimalNotification dismiss];
                    
                    
                });

            }
            
            
        }
            
                                      
            failure:^(AFHTTPRequestOperation *operation, NSError *error)
        {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            
            NSLog(@"Error: %@", error);
            self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleInfo
                                                                              title:@"Filed to SignUp"
                                                                           subTitle:@"Please check your internet connection."];
            
            [self.view addSubview:self.minimalNotification];
            [self.minimalNotification show];
            double delayInSeconds = 2.0;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                NSLog(@"Do some work");
                [self.minimalNotification dismiss];
                
            });
            
            
            
        }];
        op.responseSerializer = [AFJSONResponseSerializer serializer];
        [[NSOperationQueue mainQueue] addOperation:op];
        
        
        
        
        
    });
    }
    
    
}

// Method to automatically login after signing up

-(void) logINAfterSignUp
{
   
   
  
    
    LoginHelper *loginobject = [[LoginHelper alloc]init];
    [loginobject login:userName password:passWord success:^(id responseObject)
     {
         //Session management
         [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"logged_in"];
         NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
         NSString* emailusername = userName;
         [defaults setObject:emailusername forKey:@"email"];
         [defaults setValue:[responseObject valueForKey:@"cik"]
                     forKey:@"cik"];
        
         if ([responseObject valueForKey:@"dashboard_link"] != nil) {
             [defaults setValue:[responseObject valueForKey:@"dashboard_link"] forKey:@"dashboard_link"];
         }
         [defaults synchronize];
         AppDelegate *obj = (AppDelegate *)[[UIApplication sharedApplication]delegate];
         [Lockbox setString:userName forKey:@"username"];
         [Lockbox setString:passWord forKey:@"password"];
         
         
         
         //Visual alert
         self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleSuccess title:@"Login Successful" subTitle:@""];
         [self.view addSubview:self.minimalNotification];
         [self.minimalNotification show];
         
         
         //Injecting a delay of 1.5 seconds and loading home screen
         double delayInSeconds = 1.5;
         dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
         dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            // NSLog(@"Do some work");
             
             

             
             AppDelegate *appDelegateTemp = [[UIApplication sharedApplication]delegate];

              [hud hide:YES];
             UIViewController* rootController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"login_success"];
             UINavigationController* navigation = [[UINavigationController alloc] initWithRootViewController:rootController];
             
             appDelegateTemp.window.rootViewController = navigation;
         });
         
         
     }
               failure:^(NSError *error)
     {
             [hud hide:YES];
         NSString *errorstring= [error valueForKey:@"error"];
         self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleError title:@"Error" subTitle:errorstring];
         [self.view addSubview:self.minimalNotification];
         [self.minimalNotification show];
         [self dismissPopupAfterDelayInReg:(2.0)];
         
         NSLog(@"Failure");
         
         
     }];
}



- (IBAction)add_image:(id)sender {
    
    UIWindow* window = [[[UIApplication sharedApplication] delegate] window];
    UIActionSheet *actionpass;
    
    actionpass = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", nil) destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Select Photo", @""),NSLocalizedString(@"Take Photo", @""),nil];
    [actionpass showInView:window];
    
}
-(void)dismissPopupAfterDelayInReg: (double)delay
{
    
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        
        [self.minimalNotification dismiss];
        
        
    });
}



#pragma mark
#pragma mark - ActionSheet Delegate

- (void)actionSheet:(UIActionSheet *)actionSheet willDismissWithButtonIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 1:
        {
            [self takePhoto];
        }
            break;
        case 0:
        {
            [self selectPhotos];
        }
            break;
            
        default:
            break;
    }
    
}


#pragma mark
#pragma mark - Action to Share


- (void)selectPhotos
{
    // Set up the image picker controller and add it to the view
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    imagePickerController.sourceType =UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:imagePickerController animated:YES completion:^{
        
    }];
    /*
     */
    
}

-(void)takePhoto
{
    // Set up the image picker controller and add it to the view
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    imagePickerController.sourceType =UIImagePickerControllerSourceTypeCamera;
    
    [self presentViewController:imagePickerController animated:YES completion:^{
        
    }];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    UIImage *tempimage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    RSKImageCropViewController *imageCropVC = [[RSKImageCropViewController alloc] initWithImage:tempimage];
    imageCropVC.delegate = self;
    [self.navigationController pushViewController:imageCropVC animated:YES];
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}



// The original image has been cropped.
- (void)imageCropViewController:(RSKImageCropViewController *)controller didCropImage:(UIImage *)croppedImage
{
    _imageView.image = croppedImage;
    [self.navigationController popViewControllerAnimated:YES];
}

- (CGRect)imageCropViewControllerCustomMaskRect:(RSKImageCropViewController *)controller
{
    CGSize maskSize;
    if ([controller isPortraitInterfaceOrientation]) {
        maskSize = CGSizeMake(250, 250);
    } else {
        maskSize = CGSizeMake(220, 220);
    }
    
    CGFloat viewWidth = CGRectGetWidth(controller.view.frame);
    CGFloat viewHeight = CGRectGetHeight(controller.view.frame);
    
    CGRect maskRect = CGRectMake((viewWidth - maskSize.width) * 0.5f,
                                 (viewHeight - maskSize.height) * 0.5f,
                                 maskSize.width,
                                 maskSize.height);
    
    return maskRect;
}

// Returns a custom path for the mask.
- (UIBezierPath *)imageCropViewControllerCustomMaskPath:(RSKImageCropViewController *)controller
{
    CGRect rect = controller.maskRect;
    CGPoint point1 = CGPointMake(CGRectGetMinX(rect), CGRectGetMaxY(rect));
    CGPoint point2 = CGPointMake(CGRectGetMaxX(rect), CGRectGetMaxY(rect));
    CGPoint point3 = CGPointMake(CGRectGetMidX(rect), CGRectGetMinY(rect));
    
    UIBezierPath *triangle = [UIBezierPath bezierPath];
    [triangle moveToPoint:point1];
    [triangle addLineToPoint:point2];
    [triangle addLineToPoint:point3];
    [triangle closePath];
    
    return triangle;
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

// Crop image has been canceled.
- (void)imageCropViewControllerDidCancelCrop:(RSKImageCropViewController *)controller
{
    [self.navigationController popViewControllerAnimated:YES];
}

// The original image has been cropped.
- (void)imageCropViewController:(RSKImageCropViewController *)controller
                   didCropImage:(UIImage *)croppedImage
                  usingCropRect:(CGRect)cropRect
{
    self.imageView.image = croppedImage;
    [self.navigationController popViewControllerAnimated:YES];
    self.navigationController.navigationBarHidden=NO;
}

// The original image has been cropped. Additionally provides a rotation angle used to produce image.
- (void)imageCropViewController:(RSKImageCropViewController *)controller
                   didCropImage:(UIImage *)croppedImage
                  usingCropRect:(CGRect)cropRect
                  rotationAngle:(CGFloat)rotationAngle
{
    self.imageView.image = croppedImage;
    [self.navigationController popViewControllerAnimated:YES];
    self.navigationController.navigationBarHidden=NO;
}

// The original image will be cropped.
- (void)imageCropViewController:(RSKImageCropViewController *)controller
                  willCropImage:(UIImage *)originalImage
{
    // Use when `applyMaskToCroppedImage` set to YES.
    
}
@end

