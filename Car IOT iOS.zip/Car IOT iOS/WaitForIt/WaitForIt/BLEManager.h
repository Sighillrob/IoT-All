//
//  BLEManager.h
//  obd2
//
//  Created by Madhu V Swamy on 10/08/15.
//  Copyright (c) 2015 Cumulations Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "BLEConstants.h"
#import "Queue.h"

@interface BLEManager : NSObject<CBCentralManagerDelegate>
{
    NSString *initializeCMD;
    BOOL isWriteInProgress;
}

@property (nonatomic, strong) CBPeripheral *toConnectPeripheral;
@property (nonatomic, strong) CBPeripheral *connectedPeripheral;
@property (nonatomic, strong) CBCentralManager *manager;
@property (nonatomic, strong) CBCharacteristic *writeCharacteristic;
@property (nonatomic, strong) CBCharacteristic *readCharacteristic;

@property (nonatomic, strong) NSMutableString *responseString;

@property (nonatomic, strong) Queue *queue;

-(void)scanBLEDevices;
-(void)connectToDevice:(CBPeripheral *)periferalDetected;
-(void)cancelConnectionWithDevice:(CBPeripheral *)periferalConnected;
-(void)sendData:(NSString *)obdCommand;
- (void)initializeConnection:(NSString *)command;





@end
