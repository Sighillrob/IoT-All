//
//  LoginViewController.m
//  SnackCaddy Golfer
//
//  Created by BHARATH L.N on 02/07/15.
//  Copyright (c) 2015 Mowares. All rights reserved.
//

#import "LoginViewController.h"
#import "Constants.h"
#import <AFNetworking.h>
#import "JFMinimalNotification.h"
#import "Lockbox.h"
#import "MBProgressHUD.h"

@interface LoginViewController ()<JFMinimalNotificationDelegate, UITextFieldDelegate>
{
    Reachability *internetReachableFoo;
}

@property (nonatomic, strong) JFMinimalNotification* minimalNotification;
@end


@implementation LoginViewController



-(void)viewDidLoad
{
    self.navigationController.navigationBarHidden=YES;
    
    self.sign_in_btn.layer.cornerRadius = 25.0;
  
    self.txt_username.delegate = self;
    self.txt_password.delegate = self;

    
    
}



-(void)textFieldDidBeginEditing:(UITextField *)textField
{
   
    textField.text = @"";
    
    
}









- (IBAction)backaction:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}




- (void)testInternetConnection
{
    internetReachableFoo = [Reachability reachabilityWithHostname:@"www.google.com"];
    
    // Internet is reachable
    internetReachableFoo.reachableBlock = ^(Reachability*reach)
    {
        // Update the UI on the main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self sign_in_action];
        });
    };

    
    // Internet is not reachable
    internetReachableFoo.unreachableBlock = ^(Reachability*reach)
    {
        // Update the UI on the main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            NSLog(@"Someone broke the internet :(");
            self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleInfo
                                                                              title:@"Connection error"
                                                                           subTitle:@"Please check your internet connection"];
            
            [self.view addSubview:self.minimalNotification];
            [self.minimalNotification show];
            
            [self dismissPopupAfterDelay:(2.0)];
        });
    };
    
    [internetReachableFoo startNotifier];
}





- (IBAction)sign_in_tapped:(id)sender {
    [self.txt_password endEditing:YES];
    [self.txt_username endEditing:YES];
    [self testInternetConnection];
   
}



// Login method

-(void)sign_in_action
{
  
    
    NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
    
    
    if([[self.txt_username text] isEqualToString:@""])
    {
        
        
        self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleWarning
                                                                          title:@"Username can't be empty"
                                                                       subTitle:@"Please enter your email address"];
        
        [self.view addSubview:self.minimalNotification];
        [self.minimalNotification show];
        [self dismissPopupAfterDelay:(2.0)];
        
        
        
    }
    
    else if([[self.txt_password text] isEqualToString:@""])
    {
        
        self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleWarning
                                                                          title:@"Password can't be empty"
                                                                       subTitle:@"Please enter your Password"];
        
        [self.view addSubview:self.minimalNotification];
        [self.minimalNotification show];
        [self dismissPopupAfterDelay:(2.0)];
        
    }
    else if ([emailTest evaluateWithObject:self.txt_username.text] == NO) {
        
        self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleWarning
                                                                          title:@"Invalid Email"
                                                                       subTitle:@"Please enter a valid Email address"];
        
        [self.view addSubview:self.minimalNotification];
        [self.minimalNotification show];
        [self dismissPopupAfterDelay:(2.0)];
    }
    else
    {
    
        MBProgressHUD *hudLogin=[[MBProgressHUD alloc]init];
        hudLogin.labelText=@"Please Wait";
        hudLogin.detailsLabelText=@"Logging you in";
        [self.view addSubview:hudLogin];
        hudLogin.mode = MBProgressHUDModeIndeterminate;
        [hudLogin show:YES];
        
    //Creating Login Helper instance
    LoginHelper *loginobject = [[LoginHelper alloc]init];
    [loginobject login:self.txt_username.text password:self.txt_password.text success:^(id responseObject)
     {
         //Session management
         [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"logged_in"];
         NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
         NSString* emailusername = self.txt_username.text;
         [defaults setObject:emailusername forKey:@"email"];
         [defaults setValue:[responseObject valueForKey:@"cik"]
                     forKey:@"cik"];
         
         if ([responseObject valueForKey:@"dashboard_link"] != nil) {
                      [defaults setValue:[responseObject valueForKey:@"dashboard_link"] forKey:@"dashboard_link"];
         }

         
         [defaults synchronize];
         AppDelegate *obj = (AppDelegate *)[[UIApplication sharedApplication]delegate];
         [Lockbox setString:self.txt_username.text forKey:@"username"];
         [Lockbox setString:self.txt_password.text forKey:@"password"];
         
      
         
         //Visual alert
         self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleSuccess title:@"Login Successful" subTitle:@""];
         [self.view addSubview:self.minimalNotification];
         [self.minimalNotification show];
         
         
         //Injecting a delay of 1.5 seconds and loading home screen
         double delayInSeconds = 1.5;
         dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
         dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
             NSLog(@"Do some work");

             [hudLogin hide:YES];
                          AppDelegate *appDelegateTemp = [[UIApplication sharedApplication]delegate];
             UIViewController* rootController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"login_success"];
             UINavigationController* navigation = [[UINavigationController alloc] initWithRootViewController:rootController];
             
             appDelegateTemp.window.rootViewController = navigation;
         });
         
         
     }
    failure:^(NSError *error)
     {
                  [hudLogin hide:YES];
         NSString *errorstring= [error valueForKey:@"error"];
         self.minimalNotification = [JFMinimalNotification notificationWithStyle:JFMinimalNotificationStyleError title:@"Error" subTitle:errorstring];
         [self.view addSubview:self.minimalNotification];
         [self.minimalNotification show];
         [self dismissPopupAfterDelay:(2.0)];
         
         NSLog(@"Failure");
         
         
     }];
    }

}

    
    




-(void)dismissPopupAfterDelay: (double)delay
{
    
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        
        [self.minimalNotification dismiss];
        
        
    });
}





@end
