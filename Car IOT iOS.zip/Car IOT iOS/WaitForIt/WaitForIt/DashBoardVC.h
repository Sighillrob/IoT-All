//
//  DashBoardVC.h
//  WaitForIt
//
//  Created by Dev on 27/07/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashBoardVC : UIViewController

@end
