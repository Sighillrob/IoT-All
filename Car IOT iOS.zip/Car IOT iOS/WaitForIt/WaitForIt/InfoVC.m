//
//  InfoVC.m
//  WaitForIt
//
//  Created by AC on 10/08/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import "InfoVC.h"
#import "KAProgressLabel.h"
#import "AppDelegate.h"
#import "WaitForItWorker.h"
#import <AFNetworking.h>
#import "Constants.h"
#import "MAThermometer.h"
#import "DevicesListVC.h"
@import CoreLocation;

#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_RETINA ([[UIScreen mainScreen] scale] >= 2.0)

#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define SCREEN_MAX_LENGTH (MAX(SCREEN_WIDTH, SCREEN_HEIGHT))
#define SCREEN_MIN_LENGTH (MIN(SCREEN_WIDTH, SCREEN_HEIGHT))

#define IS_IPHONE_4_OR_LESS (IS_IPHONE && SCREEN_MAX_LENGTH < 568.0)
#define IS_IPHONE_5 (IS_IPHONE && SCREEN_MAX_LENGTH == 568.0)
#define IS_IPHONE_6 (IS_IPHONE && SCREEN_MAX_LENGTH == 667.0)
#define IS_IPHONE_6P (IS_IPHONE && SCREEN_MAX_LENGTH == 736.0)


@interface InfoVC () <CLLocationManagerDelegate>
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (strong,nonatomic) WaitForItWorker *waiter;
// Tab Bar
@property (strong, nonatomic) IBOutlet UIView *tabbar;
@property (strong, nonatomic) IBOutlet UIButton *btnEngine;
@property (strong, nonatomic) IBOutlet UIButton *btnBattery;
@property (strong, nonatomic) IBOutlet UIButton *btnSpeed;
@property (strong, nonatomic) IBOutlet UIButton *btnLocation;
@property (strong, nonatomic) IBOutlet UIButton *btnCritical;

@property (strong, nonatomic) IBOutlet UILabel *stateLabel;
@property (strong, nonatomic) IBOutlet UILabel *cityLabel;
@property (strong, nonatomic) IBOutlet UILabel *streetLabel;
@property (strong, nonatomic) IBOutlet UILabel *countryLabel;




@property (strong, nonatomic) IBOutlet UIView *criticalView;


@property (strong, nonatomic) IBOutlet UIView *locationView;


// Engine Info
@property (weak, nonatomic) IBOutlet KAProgressLabel *rpmLbl;
@property (strong, nonatomic) IBOutlet UIImageView *engine_splitImgView;
@property (strong, nonatomic) IBOutlet UILabel *lblEngineHeader;
@property (strong, nonatomic) IBOutlet UIView *engineView;
@property (strong, nonatomic) IBOutlet UILabel *lblEngineTime;
@property (strong, nonatomic) IBOutlet UILabel *engineLoad;


// Battery Info
@property (strong, nonatomic) IBOutlet UIView *batteryView;
@property (strong, nonatomic) IBOutlet UILabel *lblBatteryHeader;
@property (strong, nonatomic) IBOutlet MAThermometer *thermometer;
@property (strong, nonatomic) IBOutlet MAThermometer *thermometer2;
@property (strong, nonatomic) IBOutlet UILabel *coolant_label;
@property (strong, nonatomic) IBOutlet UILabel *air_label;




// Vehicle Info
@property (strong, nonatomic) IBOutlet UIView *vehicleInfoView;
@property (strong, nonatomic) IBOutlet UILabel *lblVehicleInfoHeader;
@property (strong, nonatomic) IBOutlet KAProgressLabel *speedLbl;
@property (strong, nonatomic) IBOutlet UILabel *lblKms;
@property (strong, nonatomic) IBOutlet UILabel *lblKmPerHour;
@property (strong, nonatomic) IBOutlet UILabel *lblRunningDist;
@property (strong, nonatomic) IBOutlet UILabel *lblSpeedAlert;
@property (strong, nonatomic) IBOutlet UILabel *distanceLbl;


//Critical Info
@property (strong, nonatomic) IBOutlet UILabel *engine_code;
@property (strong, nonatomic) IBOutlet UILabel *solution_label;
@property (strong, nonatomic) IBOutlet UITextView *problem_view;
@property (strong, nonatomic) IBOutlet UITextView *solution_view;
@property (strong, nonatomic) IBOutlet UILabel *critical_alert_label;


// All Timers
@property (strong, nonatomic)  NSTimer *timerToCheckDisconnection;
@property (strong, nonatomic)  NSTimer *myTimerCritical;
@property (strong, nonatomic)  NSTimer *myTimerLocation;
@property (strong, nonatomic)  NSTimer* myTimerRPM;
@property (strong, nonatomic)  NSTimer* myTimerEngineRunTime;
@property (strong, nonatomic)  NSTimer* myTimerCoolant;
@property (strong, nonatomic)  NSTimer* myTimerAirIntake;
@property (strong, nonatomic)  NSTimer* myTimerSpeed;
@property (strong, nonatomic)  NSTimer* myTimerDistance;

@end


static NSString *UnableToConnect= @"UNABLE TO CONNECT";
static NSString *NoData= @"NO DATA";

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

int test_value=10;
NSString *res3;

@implementation InfoVC
{
    NSMutableArray *troubleCodes;
    int isMapThere;
    AFHTTPRequestOperationManager *manager;
    NSString *errorMessageStr;
    int isNoData;
}


- (void) setMapView:(GMSMapView *)mapView {
    if (!mapView) {
        mapView = [[GMSMapView alloc] initWithFrame:mapView.bounds];
    }
    _mapView.delegate=self;
    _mapView = mapView;
}

GMSMapView* mapView;

- (IBAction)engineRunTimeErrorAlertAction:(id)sender {
    
//    if(isNoData)
    
    NSString *alertTitle = [NSString stringWithFormat:@"Message from the car OBD : %@",errorMessageStr];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle
                                                    message:@"This car does not allow Engine Run Time information to be read through the OBD under normal scenarios. This could be due to engine turned off or other security reasons. Please contact the authorized car dealer to hardwire information to the On-Board Diagnostics Channel."
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];

}

- (IBAction)distanceErrorAlertAction:(id)sender {
    NSString *alertTitle = [NSString stringWithFormat:@"Message from the car OBD : %@",errorMessageStr];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle
                                                    message:@"This car does not allow Distance information to be read through the OBD under normal scenarios. This could be due to engine turned off or other to security reasons. Please contact the authorized car dealer to hardwire information to the On-Board Diagnostics Channel."
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];

}

- (IBAction)AirIntakeErrorAction:(id)sender {
    
    NSString *alertTitle = [NSString stringWithFormat:@"Message from the car OBD : %@",errorMessageStr];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle
                                                    message:@"This car does not allow Air Intake temperature information to be read through the OBD under normal scenarios. This could be due to engine turned off or other security reasons. Please contact the authorized car dealer to hardwire information to the On-Board Diagnostics Channel."
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];
}

- (IBAction)tempErrorAlertAction:(id)sender
{
    
    NSString *alertTitle = [NSString stringWithFormat:@"Message from the car OBD : %@",errorMessageStr];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle
                                                    message:@"This car does not allow Coolant Temperature information to be read through the OBD under normal scenarios. This could be due to engine turned off or other security reasons. Please contact the authorized car dealer to hardwire information to the On-Board Diagnostics Channel."
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];
}

- (IBAction)CriticalerrorAlertAction:(id)sender
{
    
    NSString *alertTitle = [NSString stringWithFormat:@"Message from the car OBD : %@",errorMessageStr];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle
                                                    message:@"This car does not allow Critical Alert information to be read through the OBD under normal scenarios. This could be due to engine turned off or other security reasons. Please contact the authorized car dealer to hardwire information to the On-Board Diagnostics Channel."
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];
}

- (IBAction)engineInfoErrorAlertAction:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message from the car OBD :"
                                                    message:@"This car does not allow RPM information to be read through the OBD under normal scenarios. This could be due to engine turned off or other security reasons. Please contact the authorized car dealer to hardwire information to the On-Board Diagnostics Channel."
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];
}

- (IBAction)vehicleErrorAlertAction:(id)sender
{
    
    NSString *alertTitle = [NSString stringWithFormat:@"Message from the car OBD : %@",errorMessageStr];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle
                                                    message:@"This car does not allow Speed information to be read through the OBD under normal scenarios. This could be due to engine turned off or other security reasons. Please contact the authorized car dealer to hardwire information to the On-Board Diagnostics Channel."
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];
}

- (void)viewDidLoad {
    [super viewDidLoad];

        isMapThere=0;
    
    _engineInfoErrorAlertButton.hidden=YES;
    _tempErrorAlertButton.hidden=YES;
    _vehicleErrorAlertButton.hidden=YES;
    _criticalErrorAlertButton.hidden=YES;
    _distanceErrorAlertButton.hidden=YES;
    _engineRunTimeAlertButton.hidden=YES;
    _airIntakeEroorButton.hidden=YES;
    
    
    
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
      //  self.navigationController.delegate = self;
    
    [self setNeedsStatusBarAppearanceUpdate];
    self.waiter = [WaitForItWorker new];
    [self.waiter createPortsAndScripts];
    isNoData=0;
    
    [self customViews];
    //[self startTimer];
    
    NSString *statType = [[NSUserDefaults standardUserDefaults] objectForKey:@"statType"];
    
    if ([statType isEqualToString:@"1"]) {
        [self speedEvent:nil];
    }
    else if ([statType isEqualToString:@"2"]) {
        [self engineEvent:nil];
    }
    else if ([statType isEqualToString:@"3"])
    {
        [self batteryEvent:nil];
    }
    else if ([statType isEqualToString:@"4"])
    {
        [self criticalEvent:nil];
    }
    else if ([statType isEqualToString:@"5"])
    {
        [self locationEvent:nil];
    }
    
    //Get engine running time and RPM
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"010c"];
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"011f"];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showResultsInInfo:) name:kNotificationCodeResult object:nil];
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(disconnectedDevices:) name:kNotificationDeviceDisconnected object:nil];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceDisConnectedInInfo:) name:kNotificationDeviceDisconnected object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceFailedToConnectInInfo:) name:kNotificationDeviceFailedToConnect object:nil];
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ErrorNotificationArrived:) name:kNotificationErrorInRecieving object:nil];
    
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
 //    [self.testTimer invalidate];

   
}
- (void)viewDidDisappear:(BOOL)animated
{
      //  [self.waiter cancelAllOperations];
    self.navigationController.delegate=nil;
}
-(void)customViews {
    // Engine
    [self.engineView setBackgroundColor:UIColorFromRGB(0x30267d)];
    self.lblEngineHeader.font = [UIFont fontWithName:@"Century Gothic" size:18.0f];
    
    [self.criticalView setBackgroundColor:UIColorFromRGB(0xf7b449)];
    
    [self.locationView setBackgroundColor:UIColorFromRGB(0x53c0a2)];
    
    self.lblEngineTime.font=[UIFont fontWithName:@"LetsgoDigital-Regular" size:40.0];
    // Battery
    [self.batteryView setBackgroundColor:UIColorFromRGB(0xe63c45)];
    self.lblBatteryHeader.font = [UIFont fontWithName:@"Century Gothic" size:18.0f];
    

    
    //Vehicle Info
    [self.vehicleInfoView setBackgroundColor:UIColorFromRGB(0x1898c4)];
    
    self.lblVehicleInfoHeader.font = [UIFont fontWithName:@"Century Gothic" size:18.0f];

    self.lblKmPerHour.font = [UIFont fontWithName:@"Century Gothic" size:15.0f];
    
    self.lblRunningDist.font = [UIFont fontWithName:@"Century Gothic" size:15.0f];
    self.lblSpeedAlert.font = [UIFont fontWithName:@"Century Gothic" size:16.0f];

    [self.rpmLbl setProgressColor:[UIColor whiteColor]];
    [self.rpmLbl setTrackColor:[UIColor colorWithWhite:1.0f alpha:0.4f]];
    [self.rpmLbl setFillColor:[UIColor clearColor]];
    
    [self.rpmLbl setTrackWidth:9.0f];
    [self.rpmLbl setRoundedCornersWidth:0.0f];
    [self.rpmLbl setProgressWidth:9.0f];
    
    [self.speedLbl setTrackColor:[UIColor grayColor]];
    [self.speedLbl setProgressColor:[UIColor whiteColor]];
    [self.speedLbl setFillColor:[UIColor clearColor]];
    
    [self.speedLbl setTrackWidth:9.0f];
    [self.speedLbl setRoundedCornersWidth:0.0f];
    [self.speedLbl setProgressWidth:9.0f];
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)createRoundProgessView {
    self.rpmLbl.labelVCBlock = ^(KAProgressLabel *label) {
        label.text = [NSString stringWithFormat:@"%.0f", (label.progress * 100)];
    };
    
    self.speedLbl.labelVCBlock = ^(KAProgressLabel *label) {
        NSString *kmCount = [NSString stringWithFormat:@"%.0f", (label.progress * 100)];
        
        UIFont *arialFont = [UIFont fontWithName:@"EuphemiaUCAS" size:40.0];
        NSDictionary *arialDict = [NSDictionary dictionaryWithObject:arialFont forKey:NSFontAttributeName];
        NSMutableAttributedString *aAttrString = [[NSMutableAttributedString alloc] initWithString:kmCount attributes: arialDict];
        
        UIFont *VerdanaFont = [UIFont fontWithName:@"Century Gothic" size:15.0];
        NSDictionary *verdanaDict = [NSDictionary dictionaryWithObject:VerdanaFont forKey:NSFontAttributeName];
        NSMutableAttributedString *vAttrString = [[NSMutableAttributedString alloc]initWithString:@" Km/h" attributes:verdanaDict];
        
        [aAttrString appendAttributedString:vAttrString];

        label.attributedText = aAttrString;
    };

    if (test_value>100) {
        test_value = 10;
    }
    else {
        test_value+=10;
    }
    
    float rndValue = test_value % 100*0.01;
    
    [self.rpmLbl setProgress:rndValue timing:TPPropertyAnimationTimingEaseInEaseOut duration:1.0 delay:0];
    [self.speedLbl setProgress:rndValue timing:TPPropertyAnimationTimingEaseInEaseOut duration:1.0 delay:0];
}
- (void)mapView:(GMSMapView *)mapView willMove:(BOOL)gesture
{
    NSLog(@"Map Moved");
}

//-(void)startTimer {
//    NSRunLoop *runloop = [NSRunLoop currentRunLoop];
//    self.testTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(createRoundProgessView) userInfo:nil repeats:YES];
//    [runloop addTimer:self.testTimer forMode:NSRunLoopCommonModes];
//    [runloop addTimer:self.testTimer forMode:UITrackingRunLoopMode];
//}
- (IBAction)criticalEvent:(id)sender {
    
    [self.engineView setHidden:YES];
    [self.batteryView setHidden:YES];
    [self.vehicleInfoView setHidden:YES];
    [self.criticalView setHidden:NO];
    [self.locationView setHidden:YES];
    [self.engine_code setHidden:YES];
    [self.solution_label setHidden:YES];
    [self.problem_view setHidden:YES];
    [self.solution_view setHidden:YES];
//    for(UIView *view in self.view.subviews)
//    {
//        if([view isKindOfClass:[GMSMapView class]])
//        {
            //[mapView setHidden:YES];
            [mapView removeFromSuperview];
    isMapThere=0;
//        }
//    }

   
    
    [self.btnEngine setImage:nil forState:UIControlStateNormal];
    [self.btnBattery setImage:nil forState:UIControlStateNormal];
    [self.btnSpeed setImage:nil forState:UIControlStateNormal];
    [self.btnLocation setImage:nil forState:UIControlStateNormal];
    [self.btnCritical setImage:[UIImage imageNamed:@"criticalSelected"] forState:UIControlStateNormal];
    
     [[AppDelegate sharedAppDelegate].queueManager clear];
    
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"03"];
    
    //[self getTroubleInfo:@"P0057"];
    
//    _myTimerCritical = [NSTimer scheduledTimerWithTimeInterval: 5.0 target: self
//                                                      selector: @selector(updateCritical:) userInfo: nil repeats: YES];
}



- (IBAction)locationEvent:(id)sender
{
     [[AppDelegate sharedAppDelegate].queueManager clear];
    
    [self.engineView setHidden:YES];
    [self.batteryView setHidden:YES];
    [self.vehicleInfoView setHidden:YES];
    [self.criticalView setHidden:YES];
    [self.locationView setHidden:NO];
    
    [self.btnEngine setImage:nil forState:UIControlStateNormal];
    [self.btnBattery setImage:nil forState:UIControlStateNormal];
    [self.btnSpeed setImage:nil forState:UIControlStateNormal];
    [self.btnLocation setImage:[UIImage imageNamed:@"locationSelected.png"] forState:UIControlStateNormal];
    [self.btnCritical setImage:nil forState:UIControlStateNormal];
    
    
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    // Check for iOS 8. Without this guard the code will crash with "unknown selector" on iOS 7.
    if ([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [self.locationManager requestWhenInUseAuthorization];
    }
    [self.locationManager startUpdatingLocation];
 
    if(isMapThere==0)
    {
        GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:_locationManager.location.coordinate.latitude
                                                            longitude:_locationManager.location.coordinate.longitude
                                                                 zoom:15];
    
        if(IS_IPHONE_6)
        {
            mapView =
            [GMSMapView mapWithFrame: CGRectMake(5,100,365, 200) camera: camera];
        }
        else
        {
            mapView =
            [GMSMapView mapWithFrame: CGRectMake(10,100,300, 200) camera: camera];
        }

        [mapView setHidden:NO];
        mapView.delegate=self;
        mapView.myLocationEnabled = YES;
    
    
    
            NSLog(@"User's location: %@", mapView.myLocation);
    
        mapView.settings.myLocationButton = YES;
        
        NSLog(@"%f %f",_locationManager.location.coordinate.latitude, _locationManager.location.coordinate.longitude);
   
        GMSMarker *marker = [[GMSMarker alloc] init];
        marker.position = CLLocationCoordinate2DMake(_locationManager.location.coordinate.latitude, _locationManager.location.coordinate.longitude);
        marker.appearAnimation = kGMSMarkerAnimationPop;
        marker.icon = [UIImage imageNamed:@"persons.png"];
        marker.title = @"You";
        marker.map = mapView;
        mapView.tag=1;


        [self.view addSubview:mapView];
        isMapThere=1;
    }
    _tabbar.hidden=NO;
    NSString * getAddress = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/geocode/json?latlng=%f,%f&sensor=true",_locationManager.location.coordinate.latitude,_locationManager.location.coordinate.longitude];
    NSLog(@"ADDRESS %@", getAddress);
    
   CLGeocoder *geoCoder = [[CLGeocoder alloc]init];
    
    [geoCoder reverseGeocodeLocation:_locationManager.location completionHandler:^(NSArray *placemarks, NSError *error){
        CLPlacemark *placemark = placemarks[0];
        
        
        _cityLabel.text=placemark.locality;
        _stateLabel.text=placemark.administrativeArea;
        _streetLabel.text=placemark.name;
        _countryLabel.text=placemark.country;
        
        
    }];
    
    
    int latSeconds = (int)(_locationManager.location.coordinate.latitude * 3600);
    //int latSeconds = (int)(42.3343 * 3600);
    int latDegrees = latSeconds / 3600;
    latSeconds = ABS(latSeconds % 3600);
    int latMinutes = latSeconds / 60;
    latSeconds %= 60;
    double latsec= latSeconds*0.0166667;
    double latmin= latMinutes+latsec;
    NSString *res=[NSString stringWithFormat:@"%d%f", latDegrees, latmin];
    NSLog(@"LAT %@",res);
    
   
    
    int longSeconds = (int)(_locationManager.location.coordinate.longitude * 3600);
    //int longSeconds = (int)(-93.2323 * 3600);
    int longDegrees = longSeconds / 3600;
    longSeconds = ABS(longSeconds % 3600);
    int longMinutes = longSeconds / 60;
    longSeconds %= 60;
    double lonsec= longSeconds*0.0166667;
    double lonmin= longMinutes+lonsec;
    NSString *res2=[NSString stringWithFormat:@"%d%f", longDegrees, lonmin];
    NSLog(@"LON %@",res2);
    res3=[NSString stringWithFormat:@"%@_%@", res, res2];
    NSLog(@"LOC %@",res3);
    
   
    
    NSString* result = [NSString stringWithFormat:@"%d°%d'%d\"%@ %d°%d'%d\"%@",
                        ABS(latDegrees),
                        latMinutes,
                        latSeconds,
                        latDegrees >= 0 ? @"N" : @"S",
                        ABS(longDegrees),
                        longMinutes,
                        longSeconds,
                        longDegrees >= 0 ? @"E" : @"W"];
    
    
    
    NSLog(@"DMS VALUE %@", result);
 
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self.waiter setWaitRate8:res3];
    });
    
    
//    _myTimerLocation = [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self
//                                                      selector: @selector(updateLocation:) userInfo: nil repeats: YES];
    
    
}


// updating all 8 values to server

//-(void) updateRPM:(NSTimer*) t
//{
//    NSLog(@"Updating RPM");
//    [self.waiter setWaitRate2:[self.rpmLbl.text integerValue]];
//}
-(void) updateRPM
{
    NSLog(@"Updating RPM");
   [self.waiter setWaitRate2:[self.rpmLbl.text integerValue]];
}

-(void) updateSpeed
{
    NSLog(@"Updating Speed");
   [self.waiter setWaitRate:[self.speedLbl.text integerValue]];
}

-(void) updateLocation
{
    NSLog(@"Updating Location");
   [self.waiter setWaitRate8:res3];
}

-(void) updateDistance
{
    NSLog(@"Updating Distance");
    [self.waiter setWaitRate3:[self.distanceLbl.text integerValue]];
}

-(void) updateCoolant
{
    NSLog(@"Updating Coolant");
    [self.waiter setWaitRate4:[self.coolant_label.text integerValue]];
}
-(void) updateAirIntake
{
    NSLog(@"Updating Air Intake");
    [self.waiter setWaitRate5:[self.air_label.text integerValue]];
}
-(void) updateEngineRunTime
{
   
    NSLog(@"Updating Engine Running Time");
    [self.waiter setWaitRate6:[self.lblEngineTime.text integerValue]];
}
-(void) updateCritical
{
   
//    if(![self.problem_view.text isEqualToString:@""]) {
//         NSLog(@"Updating Critical");
//    [self.waiter setWaitRate7:1];
//    }
    
    
    for(int i=0;i<[troubleCodes count];i++)
    {
        NSString *tempCritical =troubleCodes[i] ;
        [self.waiter setWaitRate7:tempCritical];
    }

}

- (IBAction)engineEvent:(id)sender {
    
    [[AppDelegate sharedAppDelegate].queueManager clear];
    // Get Current RPM
   [[AppDelegate sharedAppDelegate].bleManager sendData:@"010c"];
      //  [mapView setHidden:YES];
    [mapView removeFromSuperview];
       isMapThere=0;
    // Get Total Engine running time
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"011f"];
    
   
    

    [self.engineView setBackgroundColor:UIColorFromRGB(0x30267d)];
    
    [self.btnEngine setImage:[UIImage imageNamed:@"engine_selected"] forState:UIControlStateNormal];
    [self.btnBattery setImage:nil forState:UIControlStateNormal];
    [self.btnSpeed setImage:nil forState:UIControlStateNormal];
    [self.btnLocation setImage:nil forState:UIControlStateNormal];
    [self.btnCritical setImage:nil forState:UIControlStateNormal];
    
    [self.engineView setHidden:NO];
    [self.batteryView setHidden:YES];
    [self.vehicleInfoView setHidden:YES];
    [self.criticalView setHidden:YES];
    [self.locationView setHidden:YES];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self.waiter setWaitRate2:[self.rpmLbl.text integerValue]];
    });
    
//    _myTimerRPM = [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self
//                                                      selector: @selector(updateRPM:) userInfo: nil repeats: YES];
//    _myTimerEngineRunTime = [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self
//                                                      selector: @selector(updateEngineRunTime:) userInfo: nil repeats: YES];
    
}



- (IBAction)batteryEvent:(id)sender {
    [[AppDelegate sharedAppDelegate].queueManager clear];
    [self.batteryView setBackgroundColor:UIColorFromRGB(0xe63c45)];
    [[AppDelegate sharedAppDelegate].queueManager clear];
    // Get Coolant Temperature
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"0105"];
       // [mapView setHidden:YES];
    [mapView removeFromSuperview];
    isMapThere=0;
    // Get Air Intake Temperature
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"010f"];

    [self.btnEngine setImage:nil forState:UIControlStateNormal];
    [self.btnBattery setImage:[UIImage imageNamed:@"battery_selected"] forState:UIControlStateNormal];
    [self.btnSpeed setImage:nil forState:UIControlStateNormal];
    [self.btnLocation setImage:nil forState:UIControlStateNormal];
    [self.btnCritical setImage:nil forState:UIControlStateNormal];
    
    [self.engineView setHidden:YES];
    [self.batteryView setHidden:NO];
    [self.vehicleInfoView setHidden:YES];
    [self.criticalView setHidden:YES];
    [self.locationView setHidden:YES];
    
    
    
    _thermometer.minValue=-40;
    _thermometer.maxValue=215;
    _thermometer2.minValue=-40;
    _thermometer2.maxValue=215;
    
   
//    _myTimerCoolant = [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self
//                                                                   selector: @selector(updateCoolant:) userInfo: nil repeats: YES];
//    _myTimerAirIntake = [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self
//                                                                   selector: @selector(updateAirIntake:) userInfo: nil repeats: YES];
}


- (IBAction)speedEvent:(id)sender {
    [[AppDelegate sharedAppDelegate].queueManager clear];
    // Get Speed value
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"010d"];
   // [mapView setHidden:YES];
    [mapView removeFromSuperview];
    isMapThere=0;
    
    // Get Total Distance travelled value
    [[AppDelegate sharedAppDelegate].bleManager sendData:@"0131"];

    // View changes
    [self.vehicleInfoView setBackgroundColor:UIColorFromRGB(0x1898c4)];

    [self.btnEngine setImage:nil forState:UIControlStateNormal];
    [self.btnBattery setImage:nil forState:UIControlStateNormal];
    [self.btnSpeed setImage:[UIImage imageNamed:@"speed_selected"] forState:UIControlStateNormal];
    [self.btnLocation setImage:nil forState:UIControlStateNormal];
    [self.btnCritical setImage:nil forState:UIControlStateNormal];

    [self.engineView setHidden:YES];
    [self.batteryView setHidden:YES];
    [self.vehicleInfoView setHidden:NO];
    [self.locationView setHidden:YES];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self.waiter setWaitRate:[self.speedLbl.text integerValue]];
    });
    
//    _myTimerSpeed = [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self
//                                                      selector: @selector(updateSpeed:) userInfo: nil repeats: YES];
//    _myTimerDistance = [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self
//                                                      selector: @selector(updateDistance:) userInfo: nil repeats: YES];
}



-(void)setStringForValue:(NSString *)value andUnit:(NSString *)unit {
    NSString *kmsStr = value;
    UIFont *arialFont = [UIFont fontWithName:@"LetsgoDigital-Regular" size:40.0];
    NSDictionary *arialDict = [NSDictionary dictionaryWithObject: arialFont forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString = [[NSMutableAttributedString alloc] initWithString:kmsStr attributes: arialDict];
    
    UIFont *VerdanaFont = [UIFont fontWithName:@"Century Gothic" size:18.0];
    NSDictionary *verdanaDict = [NSDictionary dictionaryWithObject:VerdanaFont forKey:NSFontAttributeName];
    NSMutableAttributedString *vAttrString = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@" %@",unit] attributes:verdanaDict];
    
    [aAttrString appendAttributedString:vAttrString];
    
    [self.lblKms setTextColor:[UIColor whiteColor]];
    self.lblKms.attributedText = aAttrString;
}

#define SPEED_MAX_VAL 240
#define RPM_MAX_VAL 16000

- (IBAction)infoView:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info"
                                                    message:@"The coolant temperature sensor is used to measure the temperature of the engine coolant of an internal combustion engine. The readings from this sensor are then fed back to the Engine control unit (ECU), which uses this data to adjust the fuel injection and ignition timing. A heated air inlet or warm air intake is a system commonly used on the original air cleaner assemblies of carburetted engines to increase the temperature of the air going into the engine for the purpose of increasing the consistency of mixing of the air and fuel in order to reduce engine emissions and fuel usage."
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];
    
    
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    // the user clicked OK
    if (buttonIndex == 0) {
        // do something here...
    }
}
- (IBAction)rpmInfo:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info"
                                                    message:@"Revolutions per minute (abbreviated rpm, RPM, rev/min, r/min) is a measure of the frequency of rotation, specifically the number of rotations around a fixed axis in one minute. It is used as a measure of rotational speed of a mechanical component. "
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];
    
    
}


- (IBAction)speedInfo:(id)sender {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info"
                                                    message:@"In everyday use and in kinematics, the speed of an object is the magnitude of its velocity (the rate of change of its position); it is thus a scalar quantity.[1] The average speed of an object in an interval of time is the distance travelled by the object divided by the duration of the interval;[2] the instantaneous speed is the limit of the average speed as the duration of the time interval approaches zero."
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];
    
    
    
}




- (void)showResultsInInfo:(NSNotification *)notification {

    // invalidating timer to check if no change in data happend for 30 secs.
  //   [self.timerToCheckDisconnection invalidate];
    
// Show Current Speed
    
    
    if ([[[notification userInfo] objectForKey:kCode] isEqualToString:@"010d"]) {

        NSString *speedStr = [NSString stringWithFormat:@"%@: %@%@",[[notification userInfo] objectForKey:kCodeName],[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        NSLog(@"SPEED - %@",speedStr);
        
        
        
        self.speedLbl.labelVCBlock = ^(KAProgressLabel *label) {
            NSString *kmCount = [[notification userInfo] objectForKey:kCodeResult];
            
            UIFont *arialFont = [UIFont fontWithName:@"EuphemiaUCAS" size:40.0];
            NSDictionary *arialDict = [NSDictionary dictionaryWithObject:arialFont forKey:NSFontAttributeName];
            NSMutableAttributedString *aAttrString = [[NSMutableAttributedString alloc] initWithString:kmCount attributes: arialDict];
            
            UIFont *VerdanaFont = [UIFont fontWithName:@"Century Gothic" size:15.0];
            NSDictionary *verdanaDict = [NSDictionary dictionaryWithObject:VerdanaFont forKey:NSFontAttributeName];
            NSMutableAttributedString *vAttrString = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@" %@",[[notification userInfo] objectForKey:kCodeUnits]] attributes:verdanaDict];
            
            [aAttrString appendAttributedString:vAttrString];
            
            label.attributedText = aAttrString;
            _vehicleErrorAlertButton.hidden=YES;
        };
        
        float speedVal = [[NSString stringWithFormat:@"%@",[[notification userInfo] objectForKey:kCodeResult]] floatValue];
        float indicatorVal = speedVal / SPEED_MAX_VAL;
        
        [self.speedLbl setProgress:indicatorVal timing:TPPropertyAnimationTimingEaseInEaseOut duration:1.0 delay:0];
        
       
        [self updateSpeed];
        // Update Speed value
        [[AppDelegate sharedAppDelegate].bleManager sendData:@"010d"];
    }
    
// Show Total Distance travelled
    else if ([[[notification userInfo] objectForKey:kCode] isEqualToString:@"0131"]) {
        NSString *distanceStr = [NSString stringWithFormat:@"%@: %@%@",[[notification userInfo] objectForKey:kCodeName],[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        NSLog(@"DISTANCE - %@",distanceStr);
        self.distanceLbl.text=distanceStr;
        
        [self setStringForValue:[[notification userInfo] objectForKey:kCodeResult] andUnit:[[notification userInfo] objectForKey:kCodeUnits]];
        _distanceErrorAlertButton.hidden=YES;
        [self updateDistance];
        // Update Total Distance travelled value
        [[AppDelegate sharedAppDelegate].bleManager sendData:@"0131"];
    }
    
// Show Current RPM
    else if ([[[notification userInfo] objectForKey:kCode] isEqualToString:@"010c"]) {
 
        NSString *rpmStr = [NSString stringWithFormat:@"%@: %@%@",[[notification userInfo] objectForKey:kCodeName],[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        NSLog(@"RPM - %@",rpmStr);
        
        self.rpmLbl.labelVCBlock = ^(KAProgressLabel *label) {
            NSString *rpmCount = [[notification userInfo] objectForKey:kCodeResult];
            label.text = rpmCount;
            _engineInfoErrorAlertButton.hidden=YES;
            
        };


        float rpmVal = [[NSString stringWithFormat:@"%@",[[notification userInfo] objectForKey:kCodeResult]] floatValue];
        float rpmIndicatorVal = rpmVal / RPM_MAX_VAL;
        
        [self.rpmLbl setProgress:rpmIndicatorVal timing:TPPropertyAnimationTimingEaseInEaseOut duration:1.0 delay:0];

        [self updateRPM];
        // Update Current RPM
        [[AppDelegate sharedAppDelegate].bleManager sendData:@"010c"];
    }
    
    // Show Total Engine Running time
    else if ([[[notification userInfo] objectForKey:kCode] isEqualToString:@"011f"]) {
        NSLog(@"reached");
        NSString *engineStr = [NSString stringWithFormat:@"%@: %@%@",[[notification userInfo] objectForKey:kCodeName],[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        NSLog(@"ENGINE RUNNING TIME - %@",engineStr);
        
        NSString *secondsStr = [NSString stringWithFormat:@"%@",[[notification userInfo] objectForKey:kCodeResult]];
        NSString *formattedStr = [self timeFormatted:[secondsStr intValue]];
        
        self.lblEngineTime.text = formattedStr;
        _engineRunTimeAlertButton.hidden=YES;
        
       [self updateEngineRunTime];
        
        
        // Update Total Engine Running time
        [[AppDelegate sharedAppDelegate].bleManager sendData:@"011f"];
    }
    //Engine coolant temperature
    else if ([[[notification userInfo] objectForKey:kCode] isEqualToString:@"0105"]) {
     
        NSString *engineCoolant = [NSString stringWithFormat:@"%@: %@%@",[[notification userInfo] objectForKey:kCodeName],[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        NSLog(@"ENGINE COOLANT TEMP - %@",engineCoolant);
        
        NSString *secondsStr = [NSString stringWithFormat:@"%@",[[notification userInfo] objectForKey:kCodeResult]];
        NSString *formattedStr = [self timeFormatted:[secondsStr intValue]];
        
        
        self.coolant_label.text= [NSString stringWithFormat:@"%@%@",[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
       _thermometer.curValue=[[[notification userInfo] objectForKey:kCodeResult] integerValue];
    
        
        _tempErrorAlertButton.hidden=YES;
        [self updateCoolant];
        // Update Total Engine Running time
        [[AppDelegate sharedAppDelegate].bleManager sendData:@"0105"];
    }
    
    //Air Intake
    else if ([[[notification userInfo] objectForKey:kCode] isEqualToString:@"010f"]) {
        
        NSString *air = [NSString stringWithFormat:@"%@: %@%@",[[notification userInfo] objectForKey:kCodeName],[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        NSLog(@"AIR INTAKE TEMP - %@",air);
        
        NSString *secondsStr = [NSString stringWithFormat:@"%@",[[notification userInfo] objectForKey:kCodeResult]];
        NSString *formattedStr = [self timeFormatted:[secondsStr intValue]];
        
        
        self.air_label.text=[NSString stringWithFormat:@"%@%@",[[notification userInfo] objectForKey:kCodeResult],[[notification userInfo] objectForKey:kCodeUnits]];
        _thermometer2.curValue=[[[notification userInfo] objectForKey:kCodeResult] integerValue];
        
        _airIntakeEroorButton.hidden=YES;
        
        [self updateAirIntake];
        // Update Total Engine Running time
        [[AppDelegate sharedAppDelegate].bleManager sendData:@"010f"];
    }
    
 
    //Critical alerts
    
    else if([[[notification userInfo] objectForKey:kCode] isEqualToString:@"03"])
    {
        NSLog(@"REACHED");
        NSMutableString *codesStr = [[NSMutableString alloc]init];
        troubleCodes = [[notification userInfo] objectForKey:kCodeResult];
        NSLog(@"TROUBLE CODES%@",troubleCodes);
        if([troubleCodes count]>1)
        {
        [self.critical_alert_label setHidden:YES];
        for(int i=0;i<[troubleCodes count];i++)
        {
            [self getTroubleInfo:troubleCodes[i]];
        }
        
    }
        [self updateCritical];
    }
    
    // timer to to check whether any data change is happening for 30 sec. if not disconnect and go back.
    
//    self.timerToCheckDisconnection= [NSTimer scheduledTimerWithTimeInterval: 30.0 target: self
//                                   selector: @selector(disconnectedDevices) userInfo: nil repeats: YES];
    
}

-(void)disconnectedDevices
{
    
    // Invalidate all running timers
    
//    [self.timerToCheckDisconnection invalidate];
//    self.timerToCheckDisconnection=nil;
    
    
//    [_myTimerCritical invalidate];
//    _myTimerCritical=nil;
//    [_myTimerLocation invalidate];
//    _myTimerLocation=nil;
//    [_myTimerRPM invalidate];
//    _myTimerRPM=nil;
//    [_myTimerEngineRunTime invalidate];
//    _myTimerEngineRunTime=nil;
//    [_myTimerCoolant invalidate];
//    _myTimerCoolant=nil;
//    [_myTimerAirIntake invalidate];
//    _myTimerAirIntake=nil;
//    
//    [_myTimerSpeed invalidate];
//    _myTimerSpeed=nil;
//    [_myTimerDistance invalidate];
//    _myTimerDistance=nil;
    
    
    // call BLEManager disconnect from DevicesListVC as we dont have the connected peripheral object in this method.
    
//    DevicesListVC *DevicesObj=[[DevicesListVC alloc]init];
//    [DevicesObj disconnectConnection];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Device Disconnected"
                                                             message:@"Unable to connect to device. Try replugging in the device to the OBD port or restart Bluetooth on your phone"
                                                            delegate:self
                                                   cancelButtonTitle:@"OK"
                                                   otherButtonTitles:nil];
    [alert show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if([alertView.title isEqualToString:@"Device Disconnected"])
    {
        // Checking and Invalidating all timers again
       
//        if([_myTimerSpeed isValid] || [_myTimerRPM isValid] || [_myTimerLocation isValid] || [_myTimerEngineRunTime isValid] || [_myTimerDistance isValid] || [_myTimerCritical isValid] || [_myTimerCoolant isValid] || [_myTimerAirIntake isValid])
//        {
//            [_myTimerCritical invalidate];
//            _myTimerCritical=nil;
//            [_myTimerLocation invalidate];
//            _myTimerLocation=nil;
//            [_myTimerRPM invalidate];
//            _myTimerRPM=nil;
//            [_myTimerEngineRunTime invalidate];
//            _myTimerEngineRunTime=nil;
//            [_myTimerCoolant invalidate];
//            _myTimerCoolant=nil;
//            [_myTimerAirIntake invalidate];
//            _myTimerAirIntake=nil;
//            
//            [_myTimerSpeed invalidate];
//            _myTimerSpeed=nil;
//            [_myTimerDistance invalidate];
//            _myTimerDistance=nil;
//        }

        [self.navigationController popToRootViewControllerAnimated:YES];
    }
   
}
-(void)getTroubleInfo :(NSString*)code
{

    manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSString *loginurl = [NSString stringWithFormat:@"%@%@", TROUBLE_CODES_URL,code];
    [manager GET:loginurl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        // do whatever you'd like here; for example, if you want to convert
        // it to a string and log it, you might do something like:
        NSLog(@"RESPONSE %@",responseObject);
        NSString *string = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"%@", string);
        NSArray *jsonDataArray = [[NSArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:NULL]];
        if(jsonDataArray.count !=0) {
        NSLog(@"RESPONSE %@", jsonDataArray[1]);
        
        self.engine_code.text=[jsonDataArray[1] valueForKey:@"code"];
        self.problem_view.text=[jsonDataArray[1] valueForKey:@"description"];
        self.solution_view.text=[jsonDataArray[1] valueForKey:@"causes"];

        }
        [self.engine_code setHidden:NO];
        [self.problem_view setHidden:NO];
        [self.solution_view setHidden:NO];
        [self.solution_label setHidden:NO];
        [self.critical_alert_label setHidden:YES];
        self.critical_alert_label.hidden=YES;
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
    
    
}
-(void) ErrorNotificationArrived:(NSNotification *)notification
{
            errorMessageStr=[NSString stringWithFormat:@"%@",[[notification userInfo] objectForKey:kErrorMessage] ];
    if ([[[notification userInfo] objectForKey:kErrorType] isEqualToString:@"010d"])
    {
        _vehicleErrorAlertButton.hidden=NO;
        
       
    }
    else if ([[[notification userInfo] objectForKey:kErrorType] isEqualToString:@"010c"])
    {
        _engineInfoErrorAlertButton.hidden=NO;
        
    }
    else if ([[[notification userInfo] objectForKey:kErrorType] isEqualToString:@"0131"])
    {
        _distanceErrorAlertButton.hidden=NO;
        
    }
    else if ([[[notification userInfo] objectForKey:kErrorType] isEqualToString:@"010f"])
    {
        _airIntakeEroorButton.hidden=NO;
       
    }
    else if ([[[notification userInfo] objectForKey:kErrorType] isEqualToString:@"0105"])
    {
        _tempErrorAlertButton.hidden=NO;
        
    }
    else if ([[[notification userInfo] objectForKey:kErrorType] isEqualToString:@"011f"])
    {
        _engineRunTimeAlertButton.hidden=NO;
        
    }
    else if ([[[notification userInfo] objectForKey:kErrorType] isEqualToString:@"03"])
    {
        _criticalErrorAlertButton.hidden=NO;
       
    }
    

}
    
-(void )deviceFailedToConnectInInfo:(NSNotification *)notification
{
    //[self disconnectedDevices];
}
-(void )deviceDisConnectedInInfo:(NSNotification *)notification
{
    [self disconnectedDevices];
}


- (NSString *)timeFormatted:(int)totalSeconds
{
    int seconds = totalSeconds % 60;
    int minutes = (totalSeconds / 60) % 60;
    int hours = totalSeconds / 3600;
    
    return [NSString stringWithFormat:@"%02d:%02d:%02d",hours, minutes, seconds];

}

- (IBAction)backEvent:(id)sender
{

    [[NSNotificationCenter defaultCenter] removeObserver:self name:kNotificationCodeResult object:nil];
    [self.waiter cancelAllOperations];

    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:kNotificationCodeResult object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kNotificationDeviceDisconnected object:nil];
}




/*
 Codes for various parameters,
 • Engine RPM - 010c
 • Engine running time - 011f

 • Calculate engine load - 0104
 
 • Vehicle speed  - 010D
 • Vehicle running distance - 0131
*/


@end
