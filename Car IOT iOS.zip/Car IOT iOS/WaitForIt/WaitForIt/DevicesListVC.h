//
//  DevicesListVC.h
//  WaitForIt
//
//  Created by AC on 13/08/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "BLEManager.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"

@interface DevicesListVC : UIViewController <UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *devicesTableView;


@property (nonatomic) CBCentralManager *bluetoothManager;
@property (nonatomic, retain) NSMutableArray *devices;
@property (nonatomic, retain) NSMutableArray *deviceUUIDs;
@property (nonatomic) MBProgressHUD *HUD;
@property (weak, nonatomic) IBOutlet UIButton *moveNextButton;
-(void)cancelConnection;
- (IBAction)refreshButtonAction:(id)sender;
- (IBAction)goToSettingsAction:(id)sender;
-(void) disconnectConnection;
-(void) cantConnectionVehicleMethod;
-(void) hideHUD;
@end
