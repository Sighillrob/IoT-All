//
//  WaitForItWorker.h
//  WaitForIt
//
//  Created by Michael Conrad Tadpol Tilstra on 12/11/14.
//  Copyright (c) 2014 Exosite. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^WaitedForThis)(NSNumber* number, NSError *error);

@interface WaitForItWorker : NSObject
@property (assign,nonatomic,readonly) BOOL isSetup;

- (void)createPortsAndScripts;
- (void)setWaitRate:(NSUInteger)seconds;
- (void)setWaitRate2:(NSUInteger)seconds;
- (void)setWaitRate3:(NSUInteger)seconds;
- (void)setWaitRate4:(NSUInteger)seconds;
- (void)setWaitRate5:(NSUInteger)seconds;
- (void)setWaitRate6:(NSUInteger)seconds;
- (void)setWaitRate7:(NSString*)seconds;
- (void)setWaitRate8:(NSString*)seconds;

- (void)waitForIt:(WaitedForThis)complete;
- (void)waitForIt2:(WaitedForThis)complete;
- (void)waitForIt3:(WaitedForThis)complete;
- (void)waitForIt4:(WaitedForThis)complete;
- (void)waitForIt5:(WaitedForThis)complete;
- (void)waitForIt6:(WaitedForThis)complete;
- (void)waitForIt7:(WaitedForThis)complete;
- (void)waitForIt8:(WaitedForThis)complete;


- (void)cancelAllOperations;
@end
