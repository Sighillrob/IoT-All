//
//  GaugesVC.m
//  WaitForIt
//
//  Created by Dev on 28/07/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import "GaugesVC.h"

@interface GaugesVC ()

@property (weak, nonatomic) IBOutlet UILabel *indicatorLbl1;
@property (weak, nonatomic) IBOutlet UILabel *indicatorLbl2;
@property (weak, nonatomic) IBOutlet UILabel *indicatorLbl3;
@property (weak, nonatomic) IBOutlet UILabel *indicatorLbl4;
@property (weak, nonatomic) IBOutlet UILabel *indicatorLbl5;
@property (weak, nonatomic) IBOutlet UILabel *indicatorLbl6;


@end

@implementation GaugesVC

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setNeedsStatusBarAppearanceUpdate];

    self.indicatorLbl1.layer.cornerRadius = self.indicatorLbl1.frame.size.height/2;
    self.indicatorLbl2.layer.cornerRadius = self.indicatorLbl2.frame.size.height/2;
    self.indicatorLbl3.layer.cornerRadius = self.indicatorLbl3.frame.size.height/2;
    self.indicatorLbl4.layer.cornerRadius = self.indicatorLbl4.frame.size.height/2;
    self.indicatorLbl5.layer.cornerRadius = self.indicatorLbl5.frame.size.height/2;
    self.indicatorLbl6.layer.cornerRadius = self.indicatorLbl6.frame.size.height/2;
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)backEvent:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}


- (IBAction)logoutEvent:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Logout" message:@"Are you sure you want to logout?" delegate:self cancelButtonTitle:@"YES" otherButtonTitles:@"NO", nil];
    [alert show];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"isLogin"];
        
        UIViewController *nextWindow = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"HomeVC"];
        [self.navigationController setViewControllers:[NSArray arrayWithObject:nextWindow] animated:NO];
    }
}

@end
