//
//  forgotPassVC.m
//  WaitForIt
//
//  Created by Dev on 12/10/15.
//  Copyright © 2015 Exosite. All rights reserved.
//

#import "forgotPassVC.h"
#import "MBProgressHUD.h"
#import <AFHTTPRequestOperation.h>


@interface forgotPassVC ()

@end

@implementation forgotPassVC
{
    MBProgressHUD* hUd;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.resetBtn .layer.cornerRadius=12.0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)resetBtnAction:(id)sender {
    
    NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
    
    
    if([[self.txtEmail text] isEqualToString:@""])
    {

        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Empty Email Address Field"
                                                        message:@"Please enter your Email address"
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        
        self.txtEmail.text=@"";
        
    }
    else if ([emailTest evaluateWithObject:self.txtEmail.text] == NO)
    {
        

        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Invalid Email Address"
                                                        message:@"Please enter a valid Email address"
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        self.txtEmail.text=@"";
    }
    else
    {
        NSString *string = [NSString stringWithFormat:@"%@forgot_password",SERVER_URL];
       // NSURL *url = [NSURL URLWithString:string];
      //  NSURLRequest *request = [NSURLRequest requestWithURL:url];
        NSString *emailStrTemp=self.txtEmail.text;

        
        
        
        hUd=[[MBProgressHUD alloc]init];
        hUd.labelText=@"Please Wait";
        [self.view addSubview:hUd];
        [hUd show:YES];
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        [params setValue:emailStrTemp forKey:@"email"];
        

        [manager POST:string parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             //Logging Response
             NSLog(@"JSON: %@", responseObject);
                          [hUd hide:YES];
             if([[responseObject valueForKey:@"success"] intValue] == 1) {
             UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Password Reset Successfull"
                                                                 message:@"We've sent an e-mail to your e-mail address consisting a link to reset your pasword"
                                                                delegate:nil
                                                       cancelButtonTitle:@"Ok"
                                                       otherButtonTitles:nil];
             alertView.tag=1;
             [alertView show];
                 self.txtEmail.text=@"";
             }
             else {
                 UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Sorry Something went wrong"
                                                                     message:@"Please try again"
                                                                    delegate:nil
                                                           cancelButtonTitle:@"Ok"
                                                           otherButtonTitles:nil];

                 [alertView show];
             }


             
         }
         
              failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
                          [hUd hide:YES];
             NSLog(@"Error: %@", error);
             UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error!!"
                                                                 message:[error localizedDescription]
                                                                delegate:nil
                                                       cancelButtonTitle:@"Ok"
                                                       otherButtonTitles:nil];
             [alertView show];
         }];


           }
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==1)
    {
        [self backEvent:nil];
    }
    
    
}
- (IBAction)backEvent:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];

}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
   
    
    [self.txtEmail endEditing:YES];
}

@end
