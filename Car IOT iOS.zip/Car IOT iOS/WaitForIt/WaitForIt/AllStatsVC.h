//
//  AllStatsVC.h
//  WaitForIt
//
//  Created by AC on 12/08/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AllStatsVC : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *locationLabel;
@property (strong, nonatomic) IBOutlet UILabel *distanceLabel;
@property (strong, nonatomic) IBOutlet UILabel *engineRunningLabel;
@property (strong, nonatomic) IBOutlet UILabel *temperatureLabel;
- (void)showResults:(NSNotification *)notification;

@end
