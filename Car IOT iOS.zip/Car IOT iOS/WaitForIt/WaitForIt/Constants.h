//
//  Constants.h
//  SnackCaddy Golfer
//
//  Created by BHARATH L.N on 03/07/15.
//  Copyright (c) 2015 Mowares. All rights reserved.
//


//DEV
#define SERVER_URL @"http://50.112.149.198/api/"
#define TROUBLE_CODES_URL @"http://engine-codes.herokuapp.com/api/troublecode?troublecode="


//STAGE
//#define SERVER_URL @""

//PROD
//#define SERVER_URL @""
