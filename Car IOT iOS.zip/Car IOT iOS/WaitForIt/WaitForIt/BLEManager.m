//
//  BLEManager.m
//  obd2
//
//  Created by Madhu V Swamy on 10/08/15.
//  Copyright (c) 2015 Cumulations Technologies. All rights reserved.
//

#import "BLEManager.h"
#import "DevicesListVC.h"

@implementation BLEManager
{
    DevicesListVC *devicesObj;
   
}
static NSString *kCodeForSpeed     =@"010d";
static NSString *kCodeForRpm       =@"010c";
static NSString *kCodeForDistance  =@"0131";
static NSString *kCodeForAirIntake =@"010f";
static NSString *kCodeForCoolant   =@"0105";
static NSString *kCodeForEngineRun =@"011f";
static NSString *kCodeForCritical  =@"03";

@synthesize responseString;

-(id)init {
    if (self = [super init])  {
        self.manager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
        self.manager.delegate=self;
    }
    return self;
}

//Scan BLE Devices
-(void)scanBLEDevices
{
    NSLog(@"scanning devices");
    NSLog(@"%@",self.manager);
    [self.manager scanForPeripheralsWithServices:nil options:nil];
}

-(void)connectToDevice:(CBPeripheral *)periferalDetected
{
    self.toConnectPeripheral = periferalDetected;
    if(self.toConnectPeripheral!=nil && self.toConnectPeripheral.state!=CBPeripheralStateConnected)
        [self.manager connectPeripheral:self.toConnectPeripheral options:nil];
}
-(void)cancelConnectionWithDevice:(CBPeripheral *)periferalConnected
{
    self.toConnectPeripheral = periferalConnected;
    
    if(self.toConnectPeripheral!=nil )
        [self.manager cancelPeripheralConnection:self.toConnectPeripheral];

}


-(void)sendData:(NSString *)obdCommand
{
    //responseString = [[NSMutableString alloc]init];
//    NSMutableArray *initializationCommands = [[NSMutableArray alloc]init];
//    [initializationCommands addObject:@"atz"];
//    [initializationCommands addObject:@"atsp0"];
//    [initializationCommands addObject:@"ate1"];
    
    if(obdCommand!=nil && ![obdCommand isEqualToString:@""])// && ![initializationCommands containsObject:obdCommand])
        [self.queue addObject:obdCommand];
    
    NSLog(@"Write In progress : %hhd",isWriteInProgress);
    if(self.writeCharacteristic!=nil && obdCommand!=nil && !isWriteInProgress){
        NSString *presentCommand = [self.queue takeObject];
        NSLog(@"Writing %@",presentCommand);
        isWriteInProgress=YES;
        [self.connectedPeripheral writeValue:[[NSString stringWithFormat:@"%@\r",presentCommand] dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.writeCharacteristic type:CBCharacteristicWriteWithResponse];
    }
}

//CBCentralManagerDelegate Methods
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    char * managerStrings[]={
        "Unknown",
        "Resetting",
        "Unsupported",
        "Unauthorized",
        "PoweredOff",
        "PoweredOn"
    };
    
    NSString * newstring=[NSString stringWithFormat:@"Manager State: %s",managerStrings[central.state]];
    NSLog(@"%@",newstring);
    
    if([newstring isEqualToString:@"Manager State: PoweredOff"])
    {
        UIAlertView *alertBluetooth = [[UIAlertView alloc] initWithTitle:@"Bluetooth Turned Off"
                                                                 message:@"Please turn ON your bluetooth connection"
                                                                delegate:self
                                                       cancelButtonTitle:@"OK"
                                                       otherButtonTitles:nil];
        [alertBluetooth show];
    }
    
    if(central.state==CBCentralManagerStatePoweredOn)
    {
        NSDictionary *options = @{
                                  CBCentralManagerScanOptionAllowDuplicatesKey: @NO
                                  };
        [self.manager scanForPeripheralsWithServices:nil options: options];
    }
}

- (void) centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    BOOL (^test)(id obj, NSUInteger idx, BOOL *stop);
    test = ^ (id obj, NSUInteger idx, BOOL *stop) {
        if([[[obj peripheral] name] compare:peripheral.name] == NSOrderedSame)
            return YES;
        return NO;
    };
    NSString *uuid = [[peripheral identifier] UUIDString];
    //NSLog(@"Detected %@ %@",[peripheral name],uuid);
    if(peripheral.name!=nil)
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationDiscoveredDevice object:self userInfo:@{kBLEPeripheral:peripheral,kBLEPeripheralName:peripheral.name}];
    else
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationDiscoveredDevice object:self userInfo:@{kBLEPeripheral:peripheral,kBLEPeripheralName:@"No Name"}];
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"Connected peripheral %@",peripheral);
    self.connectedPeripheral = peripheral;
    self.connectedPeripheral.delegate=self;
    [self.connectedPeripheral discoverServices:nil];
    
//    [[NSNotificationCenter defaultCenter] postNotificationName:kBLEPeripheralConnected object:self userInfo:@{kBLEPeripheral:peripheral,kBLEPeripheralName:peripheral.name}];
    
    responseString = [[NSMutableString alloc]init];
    isWriteInProgress = NO;
    self.queue = [[Queue alloc]init];
    [self.queue addObject:@"atz"];
    [self.queue addObject:@"atsp0"];
    [self.queue addObject:@"ate1"];
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    if(peripheral.name==nil) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationDeviceFailedToConnect object:self userInfo:@{kBLEPeripheral:peripheral,kBLEPeripheralName:@"no_name"}];
    }
    else {
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationDeviceFailedToConnect object:self userInfo:@{kBLEPeripheral:peripheral,kBLEPeripheralName:peripheral.name}];
    }
}

- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"Device is disconnected");


  
    if(peripheral.name==nil) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationDeviceDisconnected object:self userInfo:@{kBLEPeripheral:peripheral,kBLEPeripheralName:@"no_name"}];
    }
    else {
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationDeviceDisconnected object:self userInfo:@{kBLEPeripheral:peripheral,kBLEPeripheralName:peripheral.name}];
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error {
    if (!error) {
        for (int i=0;i<self.connectedPeripheral.services.count;i++) {
            CBService *service = [self.connectedPeripheral.services objectAtIndex:i];
            [self.connectedPeripheral discoverCharacteristics:nil forService:service];
        }
    }else {
        printf("Service discovery was unsuccessfull !");
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
    if (!error)
    {
        for(int i=0;i<service.characteristics.count; i++)
        {
            CBCharacteristic *characteristic = [service.characteristics objectAtIndex:i];
            if([characteristic.UUID isEqual:[CBUUID UUIDWithString:kUUIDSTR_ISSC_TRANS_RX]]){
                self.writeCharacteristic = characteristic;
            }
            if([characteristic.UUID isEqual:[CBUUID UUIDWithString:kUUIDSTR_ISSC_TRANS_TX]])
                self.readCharacteristic = characteristic;
            NSLog(@"Characteristic-%i %@",i,characteristic.UUID);
        }
        
        if ([kUUIDSTR_ISSC_PROPRIETARY_SERVICE isEqualToString:[service.UUID UUIDString]]) {
//            [self initializeConnection:@"one"];
            [self.connectedPeripheral writeValue:[[NSString stringWithFormat:@"%@\r",[self.queue takeObject]] dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.writeCharacteristic type:CBCharacteristicWriteWithResponse];
        }
        
    }
    else {
        printf("Characteristic discorvery unsuccessfull !\r\n");
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    if(!error){
        isWriteInProgress=YES;
        NSLog(@"didWriteValueForCharacteristic - %@",characteristic.UUID);
        [self.connectedPeripheral setNotifyValue:YES forCharacteristic:self.readCharacteristic];
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error
{
    NSLog(@"didUpdateValueForDescriptor - %@",[descriptor value]);
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)descriptor error:(NSError *)error
{
    if(!error){
        @try {
            NSMutableString *str = [[NSMutableString alloc] initWithData:descriptor.value encoding:NSASCIIStringEncoding];
            NSString *errorMessage = [[NSString alloc]init];
            
            //BOOL isAbleToConnect = YES;
            
            // Debug code, manipulate result for connection failures
          /* if(
               
               [responseString containsString:kCodeForSpeed]
                ||
                [responseString containsString:kCodeForSpeed]
               ||
               [responseString containsString:kCodeForCritical]
               ||
               [responseString containsString:kCodeForDistance]
               ||
               [responseString containsString:kCodeForEngineRun]
               ||
               [responseString containsString:kCodeForCoolant]
               ||
               [responseString containsString:kCodeForRpm]
               ||
               [responseString containsString:kCodeForAirIntake]
               
               ){
                //str = [[NSMutableString alloc ] initWithString: @"UNABLE TO CONNECT \n>"];
                              // str = [[NSMutableString alloc ] initWithString: @"NO DATA \n>"];
            } */
            // TODO Handle atsp0, ate1 errors
            
            if(([str containsString:@"UNABLE TO CONNECT"] && [str containsString:@">"] ) || ([str containsString:@"NO DATA"] && [str containsString:@">"]))
            {
                
               if([str containsString:@"UNABLE TO CONNECT"] && [str containsString:@">"] )
               {
                   errorMessage=@"UNABLE TO CONNECT";
               }
                else if ([str containsString:@"NO DATA"] && [str containsString:@">"])
                {
                    errorMessage=@"NO DATA";
                }
                // Create notification object
                // Fire
                NSString *errorStr=[[NSString alloc]init];
                
                        if([responseString containsString:kCodeForSpeed])
                            {
                                errorStr=kCodeForSpeed;
                            }
                        else if([responseString containsString:kCodeForRpm])
                            {
                                errorStr=kCodeForRpm;
                            }
                        else if([responseString containsString:kCodeForDistance])
                            {
                                errorStr=kCodeForDistance;
                            }
                        else if([responseString containsString:kCodeForAirIntake])
                            {
                                errorStr=kCodeForAirIntake;
                            }
                        else if([responseString containsString:kCodeForCoolant])
                            {
                                errorStr=kCodeForCoolant;
                            }
                        else if([responseString containsString:kCodeForEngineRun])
                            {
                                errorStr=kCodeForEngineRun;
                            }
                        else if([responseString containsString:kCodeForCritical])
                            {
                                errorStr=kCodeForCritical;
                            }
                
                
                
                [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationErrorInRecieving object:self userInfo:@{kErrorType:errorStr,kErrorMessage:errorMessage}];
                
                
                
                
                
            }
          
            NSLog(@"Read Data: %@",str);
            
            [responseString appendString:str];
            NSString *nextCommand = @"";

            if(![responseString containsString:@"UNABLE TO CONNECT"]){
            if ([responseString containsString:@">"] && [responseString containsString:@"41"] && [[responseString substringToIndex:2] isEqualToString:@"01"])
            {
                nextCommand = [self.queue takeObject];
                NSString *parm = [responseString substringWithRange:NSMakeRange(2, 2)];
                NSLog(@"Param:%@",parm);
                

                NSRange codeRange = [responseString rangeOfString:@"41"];
                NSMutableString *str1 = [[NSMutableString alloc]initWithString:[NSString stringWithFormat:@"41%@",[responseString substringFromIndex:codeRange.location+codeRange.length]]];

                [str1 stringByReplacingOccurrencesOfString:@" " withString:@""];
                
                NSString *str2 = [str1 stringByReplacingOccurrencesOfString:@"\r\r>" withString:@""];
                NSString *valueStr = [[str2 stringByReplacingOccurrencesOfString:@" " withString:@""] substringFromIndex:4];
                NSLog(@"Value:%@",valueStr);
                

                if ([parm caseInsensitiveCompare:@"0c"] == NSOrderedSame){
    //                ((A*256)+B)/4
                    NSString *a = [valueStr substringToIndex:2];
                    NSString *b = [valueStr substringWithRange:NSMakeRange(2, 2)];
                    
                    unsigned aResult = 0;
                    NSScanner *aScanner = [NSScanner scannerWithString:a];
                    [aScanner scanHexInt:&aResult];
                    NSLog(@"A in decimal:%u",aResult);
                    
                    unsigned bResult = 0;
                    NSScanner *bScanner = [NSScanner scannerWithString:b];
                    [bScanner scanHexInt:&bResult];
                    NSLog(@"B in decimal:%u",bResult);
                    
                    long rpm = ((aResult*256)+bResult)/4;
                    NSLog(@"Vehicle RPM:%ld",rpm);
                    
                    NSString *code = [NSString stringWithFormat:@"01%@",parm];
                    if(nextCommand==nil)
                        isWriteInProgress=NO;
                    [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationCodeResult object:self userInfo:@{kCode:code,kCodeName:@"rpm",kCodeResult:[NSString stringWithFormat:@"%ld",rpm],kCodeUnits:@"rpm"}];
                    

                  }else if ([parm caseInsensitiveCompare:@"0d"] == NSOrderedSame){
                    //               A
                    NSString *a = [valueStr substringToIndex:2];
                    
                    unsigned aResult = 0;
                    NSScanner *aScanner = [NSScanner scannerWithString:a];
                    [aScanner scanHexInt:&aResult];
                    NSLog(@"A in decimal:%u",aResult);
                    
                    NSLog(@"Vehicle speed:%u",aResult);
                    
                    NSString *code = [NSString stringWithFormat:@"01%@",parm];
                    if(nextCommand==nil)
                        isWriteInProgress=NO;
                    [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationCodeResult object:self userInfo:@{kCode:code,kCodeName:@"speed",kCodeResult:[NSString stringWithFormat:@"%u",aResult],kCodeUnits:@"km/h"}];
                    
    //            }else if ([parm isEqualToString:@"04"]){
                  }else if ([parm caseInsensitiveCompare:@"04"] == NSOrderedSame){
    //                A*100/255
                    NSString *a = [valueStr substringToIndex:2];
                    
                    unsigned aResult = 0;
                    NSScanner *aScanner = [NSScanner scannerWithString:a];
                    [aScanner scanHexInt:&aResult];
                    NSLog(@"A in decimal:%u",aResult);
                    
                    long load = (aResult*100)/255;
                    NSLog(@"Vehicle engine load:%ld",load);
                    
                    NSString *code = [NSString stringWithFormat:@"01%@",parm];
                    if(nextCommand==nil)
                        isWriteInProgress=NO;
                    [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationCodeResult object:self userInfo:@{kCode:code,kCodeName:@"engine load",kCodeResult:[NSString stringWithFormat:@"%ld",load],kCodeUnits:@"%"}];
                    
    //            }else if ([parm isEqualToString:@"1f"]){
                  }else if ([parm caseInsensitiveCompare:@"1f"] == NSOrderedSame){
    //                (A*256)+B
                    NSString *a = [valueStr substringToIndex:2];
                    NSString *b = [valueStr substringWithRange:NSMakeRange(2, 2)];
                    
                    unsigned aResult = 0;
                    NSScanner *aScanner = [NSScanner scannerWithString:a];
                    [aScanner scanHexInt:&aResult];
                    NSLog(@"A in decimal:%u",aResult);
                    
                    unsigned bResult = 0;
                    NSScanner *bScanner = [NSScanner scannerWithString:b];
                    [bScanner scanHexInt:&bResult];
                    NSLog(@"B in decimal:%u",bResult);
                    
                    long time = (aResult*256)+bResult;
                    NSLog(@"Vehicle running time:%ld",time);
                    
                    NSString *code = [NSString stringWithFormat:@"01%@",parm];
                    if(nextCommand==nil)
                        isWriteInProgress=NO;
                    [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationCodeResult object:self userInfo:@{kCode:code,kCodeName:@"running time",kCodeResult:[NSString stringWithFormat:@"%ld",time],kCodeUnits:@"seconds"}];
                
    //            }else if ([parm isEqualToString:@"31"]){
                  }else if ([parm caseInsensitiveCompare:@"31"] == NSOrderedSame){
    //                (A*256)+B
                    NSString *a = [valueStr substringToIndex:2];
                    NSString *b = [valueStr substringWithRange:NSMakeRange(2, 2)];
                    
                    unsigned aResult = 0;
                    NSScanner *aScanner = [NSScanner scannerWithString:a];
                    [aScanner scanHexInt:&aResult];
                    NSLog(@"A in decimal:%u",aResult);
                    
                    unsigned bResult = 0;
                    NSScanner *bScanner = [NSScanner scannerWithString:b];
                    [bScanner scanHexInt:&bResult];
                    NSLog(@"B in decimal:%u",bResult);
                    
                    long distance = (aResult*256)+bResult;
                    NSLog(@"Vehicle distance traveled:%ld",distance);
                    
                    NSString *code = [NSString stringWithFormat:@"01%@",parm];
                    if(nextCommand==nil)
                        isWriteInProgress=NO;
                    [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationCodeResult object:self userInfo:@{kCode:code,kCodeName:@"distance traveled",kCodeResult:[NSString stringWithFormat:@"%ld",distance],kCodeUnits:@"km"}];
                  }else if ([parm caseInsensitiveCompare:@"05"] == NSOrderedSame){
//                      A-40
                      NSString *a = [valueStr substringToIndex:2];
                      
                      unsigned aResult = 0;
                      NSScanner *aScanner = [NSScanner scannerWithString:a];
                      [aScanner scanHexInt:&aResult];
                      NSLog(@"A in decimal:%u",aResult);
                      
                      long load = aResult - 40;
                      NSLog(@"Engine coolant temperature:%ld",load);
                      
                      NSString *code = [NSString stringWithFormat:@"01%@",parm];
                      if(nextCommand==nil)
                          isWriteInProgress=NO;
                      [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationCodeResult object:self userInfo:@{kCode:code,kCodeName:@"Engine coolant temp",kCodeResult:[NSString stringWithFormat:@"%ld",load],kCodeUnits:@"°C"}];
                  }else if ([parm caseInsensitiveCompare:@"0f"] == NSOrderedSame){
//                      A-40
                      NSString *a = [valueStr substringToIndex:2];
                      
                      unsigned aResult = 0;
                      NSScanner *aScanner = [NSScanner scannerWithString:a];
                      [aScanner scanHexInt:&aResult];
                      NSLog(@"A in decimal:%u",aResult);
                      
                      long load = aResult - 40;
                      NSLog(@"Intake air temperature:%ld",load);
                      
                      NSString *code = [NSString stringWithFormat:@"01%@",parm];
                      if(nextCommand==nil)
                          isWriteInProgress=NO;
                      [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationCodeResult object:self userInfo:@{kCode:code,kCodeName:@"Intake air temp",kCodeResult:[NSString stringWithFormat:@"%ld",load],kCodeUnits:@"°C"}];
                  }
                
                unsigned result = 0;
                NSScanner *scanner = [NSScanner scannerWithString:valueStr];
                [scanner scanHexInt:&result];
    //            NSLog(@"Value Param in decimal:%u",result);
            }
            
            if ([responseString containsString:@">"] && [responseString containsString:@"43"])
            {
                NSString *str1=[responseString stringByReplacingOccurrencesOfString:@" " withString:@""];
                NSString *str2=[str1 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
                NSString *rawDataWithoutSpaces=[str2 stringByReplacingOccurrencesOfString:@"\r\r" withString:@""];
                NSError *error = nil;
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@".:" options:NSRegularExpressionCaseInsensitive error:&error];
                NSString *modifiedString = [regex stringByReplacingMatchesInString:rawDataWithoutSpaces options:0 range:NSMakeRange(0, [rawDataWithoutSpaces length]) withTemplate:@""];
                NSLog(@"%@", modifiedString);
                NSRange range1 = [modifiedString rangeOfString:@"43"];
                NSString *troubleCodeData = [modifiedString substringFromIndex:range1.location+2];
                NSLog(@"%@", troubleCodeData);
                NSMutableArray *troubleCodes = [[NSMutableArray alloc]init];
                NSMutableString *tempCode = [[NSMutableString alloc]init];
                NSDictionary *troubleCodesMapper = [[NSDictionary alloc] initWithObjectsAndKeys:@"p0",@"0",@"p1",@"1",@"p2",@"2",@"p3",@"3",
                                                    @"c0",@"4",@"c1",@"5",@"c2",@"6",@"c3",@"7",
                                                    @"b0",@"8",@"b1",@"9",@"b2",@"A",@"b3",@"B",
                                                    @"u0",@"c",@"u1",@"d",@"u2",@"e",@"u3",@"f",nil];
                for(int i=0;i<troubleCodeData.length;i++){
                    [tempCode appendString:[NSString stringWithFormat:@"%c",[troubleCodeData characterAtIndex:i]]];
                    if(tempCode.length==4){
                        if(![tempCode isEqualToString:@"0000"]){
                            NSString *firstcharacter = [NSString stringWithFormat:@"%c",[tempCode characterAtIndex:0]];
                            NSRange FIRST_CHAR = {0, 1};
                            [tempCode replaceCharactersInRange:FIRST_CHAR withString:[troubleCodesMapper valueForKey:firstcharacter]];
                            [troubleCodes addObject:tempCode];
                            NSLog(@"%@",tempCode);
                        }
                        tempCode=[[NSMutableString alloc]init];
                    }
                }
                NSLog(@"%@",troubleCodes);
                NSMutableString *codesStr = [[NSMutableString alloc]init];
                for(int i=0;i<troubleCodes.count;i++){
                    [codesStr appendString:[NSString stringWithFormat:@"%@,",[troubleCodes objectAtIndex:i]]];
                }
            
                [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationCodeResult object:self userInfo:@{kCode:@"03",kCodeName:@"trouble codes",kCodeResult:troubleCodes,kCodeUnits:@""}];
    //            NSString *str1 = [responseString stringByReplacingOccurrencesOfString:@" " withString:@""];
    //            NSRange range1 = [str1 rangeOfString:@"0:"];
    //            NSString *str2 = [str1 substringFromIndex:(range1.location + 4)];
    //
    //            NSString *str3 = str2;
    //            
    //            NSRange searchRange = NSMakeRange(0,str2.length);
    //            NSRange foundRange;
    //            while (searchRange.location < str2.length) {
    //                searchRange.length = str2.length-searchRange.location;
    //                foundRange = [str2 rangeOfString:@":" options:1 range:searchRange];
    //                if (foundRange.location != NSNotFound) {
    //                    // found an occurrence of the substring! do stuff here
    //                    
    //                    str3 = [str3 stringByReplacingCharactersInRange:NSMakeRange(foundRange.location-1, 2) withString:@""];
    //                    searchRange.location = foundRange.location+foundRange.length;
    //                } else {
    //                    // no more substring to find
    //                    break;
    //                }
    //            }
    //            
    //            
    //            NSString *str4 = [str3 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    //            
    //            NSArray *array = [NSArray arrayWithObjects:[str4 substringWithRange:NSMakeRange(0, 4)],[str4 substringWithRange:NSMakeRange(4, 4)],[str4 substringWithRange:NSMakeRange(8, 4)],[str4 substringWithRange:NSMakeRange(12, 4)],[str4 substringWithRange:NSMakeRange(16, 4)], nil];
    //            NSLog(@"Array-%@",array);
            }
            }
            
            if ([responseString containsString:@">"])
            {
                if ([responseString length] >= 4 && [[responseString substringToIndex:4] caseInsensitiveCompare:@"ate1"] == NSOrderedSame)
    //            if ([[responseString substringToIndex:4] isEqualToString:@"ate1"])
                    [[NSNotificationCenter defaultCenter] postNotificationName:kBLEPeripheralConnected object:self userInfo:@{kBLEPeripheral:peripheral,kBLEPeripheralName:peripheral.name}];
                
                responseString = [[NSMutableString alloc]init];
                if(nextCommand==nil || [nextCommand isEqualToString:@""])
                    nextCommand = [self.queue takeObject];
                
                NSLog(@"================");
                NSLog(@"Next is %@",nextCommand);
                
                if(nextCommand!=nil){
                    isWriteInProgress=YES;
                    [self.connectedPeripheral writeValue:[[NSString stringWithFormat:@"%@\r",nextCommand] dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.writeCharacteristic type:CBCharacteristicWriteWithResponse];
                }else{
                    isWriteInProgress=NO;
                    //devicesObj = [[DevicesListVC alloc]init];
                    //[devicesObj hideHUD];
                    // TODO Hide progress bar
                }
                
            }
        }@catch (NSException *exception) {
            NSLog(@"Exception %@",[exception description]);
        }
        @finally {
            // TODO Hide progress bar
            //devicesObj = [[DevicesListVC alloc]init];
            //[devicesObj hideHUD];
        }
        
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    NSMutableString *temp = [[NSMutableString alloc]initWithFormat: [NSString stringWithFormat:@"%@",[characteristic value]]];
    NSLog(@"Notification delegate %@",temp);
}

/*
- (void)initializeConnection:(NSString *)command
{
    if ([command isEqualToString:@"one"]) {
        initializeCMD = @"two";
        [self sendData:@"atz"];
    }
    else if ([command isEqualToString:@"two"])
    {
        initializeCMD = @"three";
        [self sendData:@"atsp0"];
    }
    else if ([command isEqualToString:@"three"])
    {
        initializeCMD = @"four";
        [self sendData:@"ate1"];
        //        [self sendData:@"ate0"];
    }
}
 */

@end
