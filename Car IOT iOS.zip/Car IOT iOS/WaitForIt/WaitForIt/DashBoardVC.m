//
//  DashBoardVC.m
//  WaitForIt
//
//  Created by Dev on 27/07/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import "DashBoardVC.h"
#import "KAProgressLabel.h"

@interface DashBoardVC ()

@property (weak, nonatomic) IBOutlet KAProgressLabel *progressLbl1;
@property (weak, nonatomic) IBOutlet KAProgressLabel *progressLbl2;
@property (weak, nonatomic) IBOutlet KAProgressLabel *progressLbl3;
@property (weak, nonatomic) IBOutlet KAProgressLabel *progressLbl4;
@property (weak, nonatomic) IBOutlet KAProgressLabel *progressLbl5;

@property(nonatomic, strong) NSTimer *demoTimer;

@end

int increment_value=0;

@implementation DashBoardVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setNeedsStatusBarAppearanceUpdate];
    
    [self startTimer];
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    [self.demoTimer invalidate];
}

-(void)startTimer {
    NSRunLoop *runloop = [NSRunLoop currentRunLoop];
    self.demoTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(createRoundProgessView) userInfo:nil repeats:YES];
    [runloop addTimer:self.demoTimer forMode:NSRunLoopCommonModes];
    [runloop addTimer:self.demoTimer forMode:UITrackingRunLoopMode];
}


-(void)createRoundProgessView {
    self.progressLbl1.labelVCBlock = ^(KAProgressLabel *label) {
        label.text = [NSString stringWithFormat:@"%.0f", (label.progress * 100)];
    };
    
    self.progressLbl2.labelVCBlock = ^(KAProgressLabel *label) {
        label.text = [NSString stringWithFormat:@"%.0f", (label.progress * 100)];
    };
    
    self.progressLbl3.labelVCBlock = ^(KAProgressLabel *label) {
        label.text = [NSString stringWithFormat:@"%.0f", (label.progress * 100)];
    };

    self.progressLbl4.labelVCBlock = ^(KAProgressLabel *label) {
        label.text = [NSString stringWithFormat:@"%.0f", (label.progress * 100)];
    };

    self.progressLbl5.labelVCBlock = ^(KAProgressLabel *label) {
        label.text = [NSString stringWithFormat:@"%.0f", (label.progress * 100)];
    };

    
    [self.progressLbl1 setProgressColor:[UIColor colorWithRed:0.9873 green:0.6751 blue:0.3461 alpha:1.0]];
    [self.progressLbl2 setProgressColor:[UIColor colorWithRed:0.9873 green:0.6751 blue:0.3461 alpha:1.0]];
    [self.progressLbl3 setProgressColor:[UIColor colorWithRed:0.7262 green:0.4663 blue:0.9978 alpha:1.0]];
    [self.progressLbl4 setProgressColor:[UIColor colorWithRed:0.7262 green:0.4663 blue:0.9978 alpha:1.0]];
    [self.progressLbl5 setProgressColor:[UIColor colorWithRed:0.3098 green:0.8224 blue:0.7578 alpha:1.0]];

    [self.progressLbl1 setTrackColor:[UIColor whiteColor]];
    [self.progressLbl2 setTrackColor:[UIColor whiteColor]];
    [self.progressLbl3 setTrackColor:[UIColor whiteColor]];
    [self.progressLbl4 setTrackColor:[UIColor whiteColor]];
    [self.progressLbl5 setTrackColor:[UIColor whiteColor]];

    [self.progressLbl1 setFillColor:[UIColor clearColor]];
    [self.progressLbl2 setFillColor:[UIColor clearColor]];
    [self.progressLbl3 setFillColor:[UIColor clearColor]];
    [self.progressLbl4 setFillColor:[UIColor clearColor]];
    [self.progressLbl5 setFillColor:[UIColor clearColor]];

    
    [self.progressLbl1 setTrackWidth:2.0f];
    [self.progressLbl2 setTrackWidth:2.0f];
    [self.progressLbl3 setTrackWidth:2.0f];
    [self.progressLbl4 setTrackWidth:2.0f];
    [self.progressLbl5 setTrackWidth:2.0f];

    [self.progressLbl1 setRoundedCornersWidth:2.0f];
    [self.progressLbl2 setRoundedCornersWidth:2.0f];
    [self.progressLbl3 setRoundedCornersWidth:2.0f];
    [self.progressLbl4 setRoundedCornersWidth:2.0f];
    [self.progressLbl5 setRoundedCornersWidth:2.0f];

    [self.progressLbl1 setProgressWidth:3.0f];
    [self.progressLbl2 setProgressWidth:3.0f];
    [self.progressLbl3 setProgressWidth:3.0f];
    [self.progressLbl4 setProgressWidth:3.0f];
    [self.progressLbl5 setProgressWidth:3.0f];

    
    if (increment_value>100) {
        increment_value = 0;
        increment_value+=10;
    }
    else {
        increment_value+=10;
    }
    
    float rndValue = increment_value % 100*0.01;
    
    [self.progressLbl1 setProgress:rndValue timing:TPPropertyAnimationTimingEaseInEaseOut duration:1.0 delay:0];
    [self.progressLbl2 setProgress:rndValue timing:TPPropertyAnimationTimingEaseIn duration:1.0 delay:0];
    [self.progressLbl3 setProgress:rndValue timing:TPPropertyAnimationTimingEaseOut duration:1.0 delay:0];
    [self.progressLbl4 setProgress:rndValue timing:TPPropertyAnimationTimingLinear duration:1.0 delay:0];
    [self.progressLbl5 setProgress:rndValue timing:TPPropertyAnimationTimingEaseInEaseOut duration:1.0 delay:0];
    
    NSLog(@"The increment value is --- %f",rndValue);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)startSImulation:(id)sender {
    [self startTimer];
}

- (IBAction)goToHomeEvent:(id)sender {
//    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"isLogin"];
    
    UIViewController *nextWindow = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"HomeVC"];
    [self.navigationController setViewControllers:[NSArray arrayWithObject:nextWindow] animated:YES];
}


@end
