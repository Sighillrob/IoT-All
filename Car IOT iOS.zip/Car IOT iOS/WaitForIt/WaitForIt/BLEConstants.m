//
//  BLEConstants.m
//  obd2
//
//  Created by Madhu V Swamy on 10/08/15.
//  Copyright (c) 2015 Cumulations Technologies. All rights reserved.
//

#import "BLEConstants.h"

@implementation BLEConstants

NSString * const kNotificationDiscoveredDevice = @"kNotificationDiscoveredDevice";
NSString * const kBLEPeripheral = @"kBLEPeripheral";
NSString * const kBLEPeripheralName = @"kBLEPeripheralName";
NSString * const kNotificationDeviceDisconnected = @"kNotificationDeviceDisconnected";
NSString * const kNotificationDeviceFailedToConnect = @"kNotificationDeviceFailedToConnect";
NSString * const kNotificationErrorInRecieving = @"kNotificationErrorInRecieving";
NSString * const kNotificationCodeResult = @"kNotificationCodeResult";
NSString * const kCode = @"kCode";
NSString * const kCodeName = @"kCodeName";
NSString * const kCodeUnits = @"kCodeUnits";
NSString * const kCodeResult = @"kCodeResult";


NSString * const kErrorType = @"kErrorType";
NSString * const kErrorMessage = @"kErrorMessage";


NSString * const kBLEPeripheralConnected = @"kBLEPeripheralConnected";

NSString * const kUUIDSTR_ISSC_PROPRIETARY_SERVICE = @"49535343-FE7D-4AE5-8FA9-9FAFD205E455";
NSString * const kUUIDSTR_CONNECTION_PARAMETER_CHAR = @"49535343-6DAA-4D02-ABF6-19569ACA69FE";
NSString * const kUUIDSTR_ISSC_TRANS_TX = @"49535343-1E4D-4BD9-BA61-23C647249616";
NSString * const kUUIDSTR_ISSC_TRANS_RX = @"49535343-8841-43F4-A8D4-ECBE34729BB3";
NSString * const kUUIDSTR_ISSC_MP = @"49535343-ACA3-481C-91EC-D85E28A60318";

@end
