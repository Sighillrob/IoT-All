//
//  InfoVC.h
//  WaitForIt
//
//  Created by AC on 10/08/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>
#import <CoreLocation/CoreLocation.h>


@interface InfoVC : UIViewController<GMSMapViewDelegate>

@property(nonatomic, strong) NSTimer *testTimer;
@property (weak, nonatomic) IBOutlet GMSMapView *mapView;
@property (weak, nonatomic) IBOutlet UIButton *engineInfoErrorAlertButton;
@property (weak, nonatomic) IBOutlet UIButton *tempErrorAlertButton;
@property (weak, nonatomic) IBOutlet UIButton *vehicleErrorAlertButton;
@property (weak, nonatomic) IBOutlet UIButton *criticalErrorAlertButton;
@property (weak, nonatomic) IBOutlet UIButton *distanceErrorAlertButton;
@property (weak, nonatomic) IBOutlet UIButton *engineRunTimeAlertButton;

@property (weak, nonatomic) IBOutlet UIButton *airIntakeEroorButton;
- (IBAction)engineRunTimeErrorAlertAction:(id)sender;

- (IBAction)distanceErrorAlertAction:(id)sender;
- (IBAction)AirIntakeErrorAction:(id)sender;

- (IBAction)tempErrorAlertAction:(id)sender;
- (IBAction)CriticalerrorAlertAction:(id)sender;
- (IBAction)engineInfoErrorAlertAction:(id)sender;
- (IBAction)vehicleErrorAlertAction:(id)sender;
-(void)disconnectedDevices;
@end
