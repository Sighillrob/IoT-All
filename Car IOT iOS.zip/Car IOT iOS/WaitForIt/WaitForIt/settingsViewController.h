//
//  settingsViewController.h
//  WaitForIt
//
//  Created by naveen on 8/20/15.
//  Copyright (c) 2015 Exosite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface settingsViewController : UIViewController <UITextFieldDelegate,UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedcontrol;
- (IBAction)valuechanged:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *generalView;
@property (weak, nonatomic) IBOutlet UIView *carView;
@property (weak, nonatomic) IBOutlet UIView *accountView;

@property (weak, nonatomic) IBOutlet UITextField *txt_accountEmail;

@property (weak, nonatomic) IBOutlet UITextField *txt_accountPhone;
@property (weak, nonatomic) IBOutlet UITextField *txt_accountPassword;
@property (weak, nonatomic) IBOutlet UITextField *txt_accountRetypePassword;
@property (weak, nonatomic) IBOutlet UITextField *txt_carMake;
@property (weak, nonatomic) IBOutlet UITextField *txt_carYear;
@property (weak, nonatomic) IBOutlet UITextField *txt_carModel;
@property (weak, nonatomic) IBOutlet UITextField *txt_CarEngineNo;
@property (weak, nonatomic) IBOutlet UIButton *shoeDashBtn;
@property (weak, nonatomic) IBOutlet UITextField *txt_GeneralFName;
@property (weak, nonatomic) IBOutlet UITextField *txt_GeneralLName;
@property (weak, nonatomic) IBOutlet UITextField *txt_GeneralCountry;
@property (weak, nonatomic) IBOutlet UITextField *txt_GeneralAddress;
@property (weak, nonatomic) IBOutlet UITextField *txt_GeneralAge;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmeneAge;
- (IBAction)ageChanged:(UISegmentedControl *)sender;
@property (weak, nonatomic) IBOutlet UIButton *datePickerButton;

- (IBAction)btn_Calendar:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_saveAccount;
- (IBAction)btn_ClickSaveAccount:(id)sender;
- (IBAction)ShowDashBoardBtnAction:(id)sender;
-(void)getSettings;
@property (weak, nonatomic) IBOutlet UIButton *btn_saveGeneral;
- (IBAction)btn_ClickSaveGeneral:(id)sender;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;

- (IBAction)pickerAction:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *btn_SaveCar;
- (IBAction)btn_ClickSaveCar:(id)sender;
- (IBAction)setDate:(id)sender;

@property (weak, nonatomic) IBOutlet UIImageView *dateImageBackground;
@property (weak, nonatomic) IBOutlet UIButton *dateImageButton;

-(void)showTextFeilds;
@property (weak, nonatomic) IBOutlet UIView *datePickerView;
@property (weak, nonatomic) IBOutlet UILabel *lbl_GeneralFirstName;
@property (weak, nonatomic) IBOutlet UILabel *label_GeneralLastName;
@property (weak, nonatomic) IBOutlet UILabel *lbl_GeneralCountry;
@property (weak, nonatomic) IBOutlet UILabel *lbl_GeneralAddress;
@property (weak, nonatomic) IBOutlet UILabel *lbl_GeneralBirthDate;
@property (weak, nonatomic) IBOutlet UILabel *lbl_CarMake;
@property (weak, nonatomic) IBOutlet UILabel *lbl_CarYear;
@property (weak, nonatomic) IBOutlet UILabel *lbl_CarModel;
@property (weak, nonatomic) IBOutlet UILabel *lbl_CarEngineNo;
@property (weak, nonatomic) IBOutlet UILabel *lbl_AccountEmail;
@property (weak, nonatomic) IBOutlet UILabel *lbl_AccountPhone;
@property (weak, nonatomic) IBOutlet UILabel *lblAccountPassword;
@property (weak, nonatomic) IBOutlet UILabel *lbl_AccountReTypePassword;
- (IBAction)btn_ClickLogout:(id)sender;

@end
