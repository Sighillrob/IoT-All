//
//  Queue.m
//  obd2
//
//  Created by Madhu V Swamy on 12/08/15.
//  Copyright (c) 2015 Cumulations Technologies. All rights reserved.
//

#import "Queue.h"

@implementation Queue
@synthesize objects;
- (id)init {
    if ((self = [super init])) {
        objects = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void)addObject:(id)object {
    [objects addObject:object];
}

- (id)takeObject  {
    id object = nil;
    if ([objects count] > 0) {
        object = [objects objectAtIndex:0];
        [objects removeObjectAtIndex:0];
    }
    return object;
}

- (void)clear{
    
    if([objects count] > 0){
        
        [objects removeAllObjects];
        
    }
    
}



@end
