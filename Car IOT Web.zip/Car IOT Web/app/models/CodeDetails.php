<?php

class CodeDetails extends \Eloquent {
		protected $table = 'all_response';
}