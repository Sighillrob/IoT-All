
package com.provenlogic.cario.model;

import com.google.gson.annotations.Expose;

public class TroubleCodesResponse {

    @Expose
    private String make;
    @Expose
    private String model;
    @Expose
    private String year;
    @Expose
    private String code;
    @Expose
    private String title;
    @Expose
    private String description;
    @Expose
    private String image;
    @Expose
    private String detect;
    @Expose
    private String symptoms;
    @Expose
    private String causes;
    @Expose
    private String solution;
    @Expose
    private String notes;

    /**
     * 
     * @return
     *     The make
     */
    public String getMake() {
        return make;
    }

    /**
     * 
     * @param make
     *     The make
     */
    public void setMake(String make) {
        this.make = make;
    }

    /**
     * 
     * @return
     *     The model
     */
    public String getModel() {
        return model;
    }

    /**
     * 
     * @param model
     *     The model
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * 
     * @return
     *     The year
     */
    public String getYear() {
        return year;
    }

    /**
     * 
     * @param year
     *     The year
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * 
     * @return
     *     The code
     */
    public String getCode() {
        return code;
    }

    /**
     * 
     * @param code
     *     The code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 
     * @return
     *     The title
     */
    public String getTitle() {
        return title;
    }

    /**
     * 
     * @param title
     *     The title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 
     * @return
     *     The description
     */
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The image
     */
    public String getImage() {
        return image;
    }

    /**
     * 
     * @param image
     *     The image
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     * 
     * @return
     *     The detect
     */
    public String getDetect() {
        return detect;
    }

    /**
     * 
     * @param detect
     *     The detect
     */
    public void setDetect(String detect) {
        this.detect = detect;
    }

    /**
     * 
     * @return
     *     The symptoms
     */
    public String getSymptoms() {
        return symptoms;
    }

    /**
     * 
     * @param symptoms
     *     The symptoms
     */
    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    /**
     * 
     * @return
     *     The causes
     */
    public String getCauses() {
        return causes;
    }

    /**
     * 
     * @param causes
     *     The causes
     */
    public void setCauses(String causes) {
        this.causes = causes;
    }

    /**
     * 
     * @return
     *     The solution
     */
    public String getSolution() {
        return solution;
    }

    /**
     * 
     * @param solution
     *     The solution
     */
    public void setSolution(String solution) {
        this.solution = solution;
    }

    /**
     * 
     * @return
     *     The notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * 
     * @param notes
     *     The notes
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }

}
