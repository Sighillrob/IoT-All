package com.provenlogic.cario.rest;

import com.google.gson.JsonObject;
import com.provenlogic.cario.model.AccountDetailsResponse;
import com.provenlogic.cario.model.CarDetailsResponse;
import com.provenlogic.cario.model.PersonalSettingsResponse;
import com.provenlogic.cario.model.SignInResponse;
import com.provenlogic.cario.model.SignUpResponse;
import com.provenlogic.cario.model.TroubleCodesResponse;

import java.util.List;

import retrofit.Callback;
import retrofit.http.Field;
import retrofit.http.FormUrlEncoded;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.Query;

/**
 * Created by mathan on 9/9/15.
 */
public interface ApiService {

    @GET("/troublecode")
    void getTroubleCodeInformation(@Query("troublecode") String troubleCode,
                                   Callback<List<TroubleCodesResponse>> callback);

    @FormUrlEncoded
    @POST("/signup")
    void registerUser(@Field("email") String email,
                      @Field("password") String password,
                      @Field("first_name") String firstName,
                      @Field("last_name") String lastName,
                      @Field("phone") String phone,
                      @Field("device_token") String deviceToken,
                      @Field("device_type") String deviceType,
                      @Field("login_by") String loginBy,
                      Callback<SignUpResponse> callback);

    @FormUrlEncoded
    @POST("/login")
    void signInUser(@Field("email") String email,
                    @Field("password") String password,
                    @Field("device_token") String deviceToken,
                    @Field("device_type") String deviceType,
                    @Field("login_by") String loginBy,
                    Callback<SignInResponse> callback);

    @FormUrlEncoded
    @POST("/get_personal_setting")
    void getProfileDetails(@Field("user_id") String userId,
                           Callback<PersonalSettingsResponse> callback);

    @FormUrlEncoded
    @POST("/get_car_details")
    void getCarDetails(@Field("user_id") String userId,
                       Callback<CarDetailsResponse> callback);

    @FormUrlEncoded
    @POST("/get_security_setting")
    void getAccountDetails(@Field("user_id") String userId,
                           Callback<AccountDetailsResponse> callback);

    @FormUrlEncoded
    @POST("/personal_setting")
    void editProfileDetails(@Field("user_id") String userId,
                            @Field("first_name") String firstName,
                            @Field("last_name") String lastName,
                            @Field("country") String country,
                            @Field("address") String address,
                            @Field("gender") String gender,
                            @Field("dob") String dob,
                            Callback<JsonObject> callback);

    @FormUrlEncoded
    @POST("/edit_car_details")
    void editCarDetails(@Field("user_id") String userId,
                        @Field("car_make") String carMake,
                        @Field("car_model") String carModel,
                        @Field("car_year") String carYear,
                        @Field("engine_no") String engineNo,
                        Callback<JsonObject> callback);

    @FormUrlEncoded
    @POST("/security_setting")
    void editAccountDetails(@Field("user_id") String userId,
                            @Field("phone") String phone,
                            @Field("email") String email,
                            @Field("retype_password") String retypePassword,
                            @Field("password") String password,
                            Callback<JsonObject> callback);
    @FormUrlEncoded
    @POST("/add_car_details")
    void addCarDetails(@Field("user_id") String userId,
                       @Field("car_make") String carMake,
                       @Field("car_model") String carModel,
                       @Field("car_year") String carYear,
                       @Field("engine_no") String engineNo,
                       Callback<JsonObject> callback);

    @FormUrlEncoded
    @POST("/forgot_password")
    void forgotPassword(@Field("email") String email,
                        Callback<JsonObject> callback);

}
