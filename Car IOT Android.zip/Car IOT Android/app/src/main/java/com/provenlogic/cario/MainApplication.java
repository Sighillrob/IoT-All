package com.provenlogic.cario;

import android.app.Application;

import com.crashlytics.android.Crashlytics;
import com.provenlogic.cario.rest.ApiService;
import com.provenlogic.cario.rest.RestClient;

import io.fabric.sdk.android.Fabric;
import timber.log.Timber;

/**
 * Created by mathan on 2/9/15.
 */
public class MainApplication extends Application {

    RestClient restClient;

    public ApiService getClientInterface() {
        return restClient.getApiService();
    }

    public ApiService getApiClientInterface() {
        return restClient.getRestService();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Fabric.with(this, new Crashlytics());
        Timber.plant(new Timber.DebugTree());
        restClient = new RestClient();

        /*StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder()
                        .detectAll()
                        .penaltyDialog()
                        .penaltyLog()
                        .penaltyDeath()
                        .build();
        StrictMode.setThreadPolicy(policy);

        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectAll()
                .penaltyLog()
                .penaltyDeath()
                .build());*/

    }
}
