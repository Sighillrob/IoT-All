package com.provenlogic.cario;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.os.SystemClock;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStates;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.provenlogic.cario.utils.AlarmReceiver;
import com.provenlogic.cario.utils.Bluebit;
import com.provenlogic.cario.utils.Constants;
import com.provenlogic.cario.utils.DisconnectReceiver;
import com.provenlogic.cario.utils.MySharedPreference;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import api.ExoCallback;
import api.ExoException;
import api.onep.RPC;
import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DetailActivity extends AppCompatActivity implements View.OnClickListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

    private static final int ENABLE_BT = 0;
    private static final int CLEAR_ALL = 10;
    private static final int CLEAR_ALL_LOGIN = 11;
    private static final int START_ACTIVITY_TIME = 1 * 1000;
    private static final String TAG = DetailActivity.class.getSimpleName();
    private static final int RPM_COMMAND = 0;
    private static final int RUNNING_TIME = 1;
    private static final int SPEED = 2;
    private static final int DISTANCE_TRAVELLED = 3;
    private static final int TROUBLE_CODES = 4;
    private static final int COOLANT_TEMPERATURE = 5;
    private static final int AIR_INTAKE = 6;
    private static final int NOT_CONNECTED_STATE = 15;
    private static final int DUMMY_TEXT = 7;
    private static final int NOT_RECEIVING_DATA = 1000;
    private final Messenger mMessenger;
    @Bind(R.id.start_icon)
    ImageView mStartIcon;
    @Bind(R.id.total_distance_travelled)
    TextView mTotalDistanceTravelled;
    @Bind(R.id.running_time)
    TextView mRunningTime;
    @Bind(R.id.battery_level)
    TextView mCoolantTemperature;
    @Bind(R.id.header)
    LinearLayout mHeader;
    @Bind(R.id.battery_frame)
    FrameLayout mBatteryFrame;
    @Bind(R.id.distance_frame)
    FrameLayout mDistanceFrame;
    @Bind(R.id.current_city)
    TextView mCurrentCity;
    @Bind(R.id.tiles)
    LinearLayout mTiles;
    @Bind(R.id.footer)
    RelativeLayout mFooter;
    @Bind(R.id.user_icon)
    ImageView mUserIcon;
    @Bind(R.id.temperature_tile)
    ImageView mTemperatureTile;
    @Bind(R.id.total_distance_tile)
    ImageView mTotalDistanceTile;
    @Bind(R.id.engine_running_time_tile)
    ImageView mEngineRunningTimeTile;
    @Bind(R.id.service_alert_tile)
    ImageView mServiceAlertTile;
    @Bind(R.id.location_tile)
    ImageView mDistanceTile;
    private BleService mService;
    private Intent mServiceIntent;
    private String mDevice;
    private ProgressDialog mDialog;
    private GoogleApiClient mGoogleApiClient;
    private LocationRequest mLocationRequest;
    private Location mCurrentLocation;
    private ServiceHandler mServiceHandler;
    private HandlerThread mThread;
    private String mRPMValue = "";
    private String mDistanceTravelled = "";
    private String mLocation = "";
    private String mSpeed = "";
    private String mAirIntake = "";
    private String mCoolant = "";
    private String mCriticalAlerts = "";
    private String mEngineTime = "";

    private IncomingHandler mIncomingHandler = new IncomingHandler(this);

    BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && Constants.BLUETOOTH_MESSAGE_INTENT.equalsIgnoreCase(intent.getAction())) {
                String message = intent.getStringExtra(Constants.BLUETOOTH_MESSAGE);
                parseAndGenerate(message);
            }
        }
    };

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mService = ((BleService.LocalBinder) service).getService();
            mService.connect(mDevice);
            mIncomingHandler.sendEmptyMessageDelayed(NOT_CONNECTED_STATE, 30000);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService = null;
        }
    };

    private BleService.State mState;
    private PendingIntent mPendingIntent;

    BroadcastReceiver mStatesReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && Constants.STATES_INTENT.equalsIgnoreCase(intent.getAction())) {
                int message = intent.getIntExtra(Constants.STATES_FIELD, 0);
                stateChanged(BleService.State.values()[message]);
            }
        }
    };

    private RPC mRpcService;
    private MySharedPreference mPrefs;

    public DetailActivity() {
        super();
        mMessenger = new Messenger(mIncomingHandler);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);
        ButterKnife.bind(this);
        buildGoogleApiClient();
        mDevice = getIntent().getStringExtra("device");
        showProgressDialog();

        mPrefs = new MySharedPreference(getApplicationContext());
        mRpcService = new RPC();
        mIncomingHandler.sendEmptyMessageDelayed(Constants.TIMER_TRIGGER, mPrefs.getTimeDelay());

        createBackgroundHandler();
        mServiceIntent = new Intent(this, BleService.class);
        bindService(mServiceIntent, mConnection, BIND_AUTO_CREATE);
        IntentFilter statesFilter = new IntentFilter();
        statesFilter.addAction(Constants.STATES_INTENT);
        Log.d("!IMPORTANT", "Detail Registered");
        registerReceiver(mStatesReceiver, statesFilter);
        IntentFilter messageFilter = new IntentFilter();
        messageFilter.addAction(Constants.BLUETOOTH_MESSAGE_INTENT);
        registerReceiver(mBroadcastReceiver, messageFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopLocationUpdates();
        if (mConnection != null) {
            unbindService(mConnection);
        }
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
        Log.d("!IMPORTANT", "Detail unregister");
        unregisterReceiver(mStatesReceiver);
        mIncomingHandler.removeMessages(NOT_RECEIVING_DATA);
        unregisterReceiver(mBroadcastReceiver);
    }

    @OnClick(R.id.engine_running_time_tile)
    public void gotoRunningTileFragment() {
        gotoHomeScreenWithFragment(Constants.RUNNING_TILE_FRAGMENT);
    }

    @OnClick(R.id.total_distance_tile)
    public void gotoDistanceTravelledFragment() {
        gotoHomeScreenWithFragment(Constants.DISTANCE_TRAVELLED_FRAGMENT);
    }

    @OnClick(R.id.temperature_tile)
    public void gotoTemperatureFragment() {
        gotoHomeScreenWithFragment(Constants.TEMPERATURE_FRAGMENT);
    }

    @OnClick(R.id.service_alert_tile)
    public void gotoCriticalAlertsFragment() {
        gotoHomeScreenWithFragment(Constants.TROUBLE_CODE_FRAGMENT);
    }

    @OnClick(R.id.location_tile)
    public void gotoLocationTileFragment() {
        gotoHomeScreenWithFragment(Constants.LOCATION_FRAGMENT);
    }

    private void gotoHomeScreenWithFragment(int type) {
        Intent intent = new Intent(getApplicationContext(), HomeScreenActivity.class);
        intent.putExtra(Constants.FRAGMENT_POSITION, type);
        startActivityForResult(intent, CLEAR_ALL);
    }

    private void createBackgroundHandler() {
        mThread = new HandlerThread(TAG, android.os.Process.THREAD_PRIORITY_BACKGROUND);
        mThread.start();
        mServiceHandler = new ServiceHandler(mThread.getLooper());
    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(getApplicationContext())
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        createLocationRequest();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    private void showProgressDialog() {
        mDialog = new ProgressDialog(this, R.style.Dialog);
        mDialog.setCancelable(false);
        mDialog.setMessage(getString(R.string.initializing_device));
        mDialog.setTitle("");
        mDialog.show();
    }

    @OnClick(R.id.user_icon)
    public void gotoSettingsScreen() {
        startActivityForResult(new Intent(getApplicationContext(), SettingsActivity.class), CLEAR_ALL_LOGIN);
    }

    @Override
    public void onConnected(Bundle arg0) {
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            mCurrentLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        }
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            if (mCurrentLocation != null) {
                getCurrentCity(mCurrentLocation);
            }
        }
        startLocationUpdates();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == CLEAR_ALL) {
            startAlarm(START_ACTIVITY_TIME);
            finish();
            Process.killProcess(Process.myPid());
        } else if(resultCode == CLEAR_ALL_LOGIN) {
            startAlarmLogout(START_ACTIVITY_TIME);
            finish();
            Process.killProcess(Process.myPid());
        }
    }

    public void startAlarmLogout(int time) {
        Intent alarmIntent = new Intent(getApplicationContext(), DisconnectReceiver.class);
        mPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, alarmIntent, 0);
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        manager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + time, mPendingIntent);
    }

    @Override
    public void onClick(View view) {
        /*switch (view.getId()) {
            case R.id.send:
//                sendCommand(mCommand.getText().toString());
                Intent intent = new Intent(this, HomeScreenActivity.class);
                intent.putExtra("device", mDevice);
                startActivity(intent);
                break;
        }*/
    }

    private void stateChanged(BleService.State newState) {
        mState = newState;
        switch (mState) {
            case BLUETOOTH_OFF:
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, ENABLE_BT);
                break;

            case CONNECTED:
                if (mService != null) {
                    mService.stopScan();
                }
                mIncomingHandler.removeMessages(NOT_CONNECTED_STATE);
                mIncomingHandler.sendEmptyMessageDelayed(NOT_RECEIVING_DATA, 30000);
                break;

            case DISCONNECTED:
                showDisconnectedDialog();
                break;

            case SERVICES_DISCOVERED:
                enableNotification();
                break;

            case NOTIFICATION_ENABLED:
                initObd();
                mStartIcon.setVisibility(View.VISIBLE);
                break;
        }
    }

    public void startAlarm(int time) {
        Intent alarmIntent = new Intent(getApplicationContext(), AlarmReceiver.class);
        mPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, alarmIntent, 0);
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        manager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + time, mPendingIntent);
    }

    @Override
    public void onLocationChanged(Location location) {
        // TODO Auto-generated method stub
        mCurrentLocation = location;
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            if (mCurrentLocation != null) {
                getCurrentCity(mCurrentLocation);
                double latitude = mCurrentLocation.getLatitude() * 100;
                double longitude = mCurrentLocation.getLongitude() * 100;
                mLocation = latitude + "_" + longitude;
            }
        }
    }

    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_LOW_POWER);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);
        builder.setAlwaysShow(true);
        PendingResult<LocationSettingsResult> result =
                LocationServices.SettingsApi.checkLocationSettings(mGoogleApiClient, builder.build());
        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(LocationSettingsResult result) {
                final Status status = result.getStatus();
                final LocationSettingsStates state = result.getLocationSettingsStates();
                switch (status.getStatusCode()) {
                    case LocationSettingsStatusCodes.SUCCESS:
                        // All location settings are satisfied. The client can initialize location
                        // requests here.
                        break;
                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        // Location settings are not satisfied. But could be fixed by showing the user
                        // a dialog.
                        try {
                            // Show the dialog by calling startResolutionForResult(),
                            // and check the result in onActivityResult().
                            status.startResolutionForResult(DetailActivity.this, 1000);
                        } catch (IntentSender.SendIntentException e) {
                            // Ignore the error.
                        }
                        break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        // Location settings are not satisfied. However, we have no way to fix the
                        // settings so we won't show the dialog.
                        break;
                }
            }
        });
    }

    protected void startLocationUpdates() {
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    protected void stopLocationUpdates() {
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        // TODO Auto-generated method stub
        Log.i("ERROR", "Connection failed: ConnectionResult.getErrorCode() = " + connectionResult.getErrorCode());
        //Toast.makeText(this, "Failed in service ", Toast.LENGTH_SHORT).show();
    }

    private void enableNotification() {
        BluetoothGatt mGatt = mService.getGatt();
        if (mGatt != null) {
            BluetoothGattService proprietary = mGatt.getService(Bluebit.SERVICE_ISSC_PROPRIETARY);
            if (proprietary != null) {
                BluetoothGattCharacteristic mTransTx = proprietary.getCharacteristic(Bluebit.CHR_ISSC_TRANS_TX);

                boolean set = mGatt.setCharacteristicNotification(mTransTx, true);
                Log.d(TAG, "!set notification:" + set);
                BluetoothGattDescriptor dsc = mTransTx.getDescriptor(Bluebit.DES_CLIENT_CHR_CONFIG);
                if (dsc != null) {
                    dsc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    boolean success = mGatt.writeDescriptor(dsc);
                    Log.d(TAG, "!writing enable descriptor:" + success);
                } else {
                    Log.e(TAG, "!Descriptor not found");
                }
            } else {
                if (mDialog != null) {
                    mDialog.dismiss();
                }
                BluetoothGatt gatt = mService.getGatt();
                gatt.disconnect();
                gatt.close();
                Log.e(TAG, "!service not found: " + Bluebit.SERVICE_ISSC_PROPRIETARY);
                Toast.makeText(getApplicationContext(), "Did not find the service try " +
                        "reconnecting the device", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void initObd() {
        sendCommandQueue("atz");
        sendCommandQueue("atsp0");
        sendCommandQueue("ate1");
        sendRecursiveWrite();
    }

    private void sendRecursiveWrite() {
        mServiceHandler.obtainMessage(DUMMY_TEXT).sendToTarget();
        mServiceHandler.obtainMessage(DISTANCE_TRAVELLED).sendToTarget();
        mServiceHandler.obtainMessage(RUNNING_TIME).sendToTarget();
        mServiceHandler.obtainMessage(AIR_INTAKE).sendToTarget();
        mServiceHandler.obtainMessage(RPM_COMMAND).sendToTarget();
        mServiceHandler.obtainMessage(COOLANT_TEMPERATURE).sendToTarget();
        mServiceHandler.obtainMessage(SPEED).sendToTarget();
        mServiceHandler.obtainMessage(TROUBLE_CODES).sendToTarget();
    }

    private void uploadDatas() {
        if (mRpcService == null) {
            return;
        }
        mRpcService.writeInBackground(mPrefs.getClkValue(), Constants.RPC_RPM, mRPMValue,
                new ExoCallback<Void>() {
                    @Override
                    public void done(Void result, ExoException e) {

                    }
                });
        mRpcService.writeInBackground(mPrefs.getClkValue(), Constants
                .RPC_ENGINE_RUNNING_TIME, mEngineTime, new ExoCallback<Void>() {
            @Override
            public void done(Void result, ExoException e) {

            }
        });
        mRpcService.writeInBackground(mPrefs.getClkValue(), Constants.RPC_AIRINTAKE,
                mAirIntake, new ExoCallback<Void>() {
                    @Override
                    public void done(Void result, ExoException e) {

                    }
                });
        mRpcService.writeInBackground(mPrefs.getClkValue(), Constants.RPC_COOLANT,
                mCoolant, new ExoCallback<Void>() {
                    @Override
                    public void done(Void result, ExoException e) {

                    }
                });
        mRpcService.writeInBackground(mPrefs.getClkValue(), Constants.RPC_SPEED, mSpeed,
                new ExoCallback<Void>() {
                    @Override
                    public void done(Void result, ExoException e) {

                    }
                });
        mRpcService.writeInBackground(mPrefs.getClkValue(), Constants.RPC_DISTANCE,
                mDistanceTravelled, new ExoCallback<Void>() {
                    @Override
                    public void done(Void result, ExoException e) {

                    }
                });
        mRpcService.writeInBackground(mPrefs.getClkValue(), Constants.RPC_LOCATION,
                mLocation, new ExoCallback<Void>() {
                    @Override
                    public void done(Void result, ExoException e) {

                    }
                });
        if (!TextUtils.isEmpty(mCriticalAlerts)) {
            mRpcService.writeInBackground(mPrefs.getClkValue(), Constants
                    .RPC_CRITICAL_ALERTS, mCriticalAlerts, new ExoCallback<Void>() {
                @Override
                public void done(Void result, ExoException e) {

                }
            });
        }

    }

    private void sendCommand(String text) {
        if (mService != null) {
            mService.write(text.replaceAll("\\s+", ""));
        }
    }

    private void sendCommandQueue(String text) {
        if (mService != null) {
            mService.write(text.replaceAll("\\s+", ""));
        }
    }

    @OnClick(R.id.start_icon)
    public void gotoHomeScreen() {
        Intent intent = new Intent(getApplicationContext(), HomeScreenActivity.class);
        startActivityForResult(intent, CLEAR_ALL);
    }

    private void parseAndGenerate(final String message) {
        if (TextUtils.isEmpty(message)) {
            return;
        }

        if (mDialog != null) {
            mDialog.dismiss();
        }
        mIncomingHandler.removeMessages(NOT_RECEIVING_DATA);
        mIncomingHandler.sendEmptyMessageDelayed(NOT_RECEIVING_DATA, 30000);
        String errorMessage = "";
        final String[] messageValue = message.split("\\|");
        if (messageValue.length > 1) {
            Log.d("IMPORTANT LOG", "0 - " + messageValue[0] + " 1 - " + messageValue[1] + " size : "
                    + messageValue.length + " Message : " + message);
            switch (messageValue[0]) {
                case Constants.DISTANCE_TRAVELLED:
                    if(message.contains(Constants.IS_ERROR)) {
                        errorMessage = getErrorString("Distance Travelled");
                    } else {
                        mDistanceTravelled = messageValue[1];
                        mTotalDistanceTravelled.setText(messageValue[1] + "kms");
                    }
                    mServiceHandler.obtainMessage(DISTANCE_TRAVELLED).sendToTarget();
                    break;
                case Constants.RUNNING_TIME:
                    if(message.contains(Constants.IS_ERROR)) {
                        errorMessage = getErrorString("Running Time");
                    } else {
                        mEngineTime = messageValue[1];
                        setRunningTime(Long.parseLong(messageValue[1]));
                    }
                    mServiceHandler.obtainMessage(RUNNING_TIME).sendToTarget();
                    break;
                case Constants.SPEED:
                    if(message.contains(Constants.IS_ERROR)) {
                        errorMessage = getErrorString("Speed");
                    } else {
                        mSpeed = messageValue[1];
                    }
                    mServiceHandler.obtainMessage(SPEED).sendToTarget();
                    break;
                case Constants.RPM:
                    if(message.contains(Constants.IS_ERROR)) {
                        errorMessage = getErrorString("Rpm");
                    } else {
                        mRPMValue = messageValue[1];
                    }
                    mServiceHandler.obtainMessage(RPM_COMMAND).sendToTarget();
                    break;
                case Constants.COOLANT_TEMPERATURE:
                    if(message.contains(Constants.IS_ERROR)) {
                        errorMessage = getErrorString("Coolant Temperature");
                    } else {
                        mCoolant = messageValue[1];
                        mCoolantTemperature.setText(messageValue[1] + " " + (char) 0x00B0 + " C");
                    }
                    mServiceHandler.obtainMessage(COOLANT_TEMPERATURE).sendToTarget();
                    break;
                case Constants.INTAKE_AIR_TEMPERATURE:
                    if(message.contains(Constants.IS_ERROR)) {
                        errorMessage = getErrorString("Intake air temperature");
                    } else {
                        mAirIntake = messageValue[1];
                    }
                    mServiceHandler.obtainMessage(AIR_INTAKE).sendToTarget();
                    break;
                case Constants.TROUBLE_CODES:
                    if(message.contains(Constants.IS_ERROR)) {
                        errorMessage = getErrorString("Trouble codes");
                    } else {
                        ArrayList<String> messageList = new ArrayList<>(Arrays.asList(messageValue));
                        messageList.remove(0);
                        ArrayList<String> codesList = messageList;
                        for (int i = 0; i < codesList.size(); i++) {
                            if (i == 0) {
                                mCriticalAlerts = codesList.get(i);
                            } else {
                                mCriticalAlerts = mCriticalAlerts + " , " + codesList.get(i);
                            }
                        }
                    }
                    mServiceHandler.obtainMessage(TROUBLE_CODES).sendToTarget();
                    break;
            }

            /*if(!TextUtils.isEmpty(errorMessage)) {
                showErrorDialog(errorMessage);
            }*/
        }
    }

    private String getErrorString(String errorMessage) {
        return Constants.ERROR_PREFIX + errorMessage + Constants.ERROR_SUFFIX;
    }

    public void setRunningTime(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        seconds = seconds % 60;

        String hoursString = "" + hours;
        String minutesString = "" + minutes;
        String hrString = "Hr";
        minutesString = " : " + minutesString;

        SpannableStringBuilder spanTxt = new SpannableStringBuilder(hoursString);
        spanTxt.append(hrString)
                .append(minutesString)
                .append("Min");
        spanTxt.setSpan(new AbsoluteSizeSpan(18, true), 0, hoursString.length(), Spanned
                .SPAN_INCLUSIVE_INCLUSIVE);
        spanTxt.setSpan(new AbsoluteSizeSpan(18, true), spanTxt.toString().indexOf(minutesString),
                spanTxt.toString().indexOf(minutesString) + minutesString.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);

        String timeString = String.format("%02dHr : %02dMin", hours, minutes);
        Log.d("IMPORTANT_LOG", timeString);
        mRunningTime.setText(spanTxt);
    }

    private void getCurrentCity(final Location currentLocation) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Geocoder gcd = new Geocoder(getApplicationContext(), Locale.getDefault());
                    List<Address> addresses = null;
                    addresses = gcd.getFromLocation(currentLocation.getLatitude(),
                            currentLocation.getLongitude(), 1);
                    if (addresses.size() > 0) {
                        final List<Address> finalAddresses = addresses;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mCurrentCity.setText("in " + finalAddresses.get(0).getLocality());
                            }
                        });
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void showDeviceNotSupported() {
        new AlertDialog.Builder(DetailActivity.this)
                .setMessage("Not able to connect, do you want to try again?")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        BluetoothGatt gatt = mService.getGatt();
                        if (gatt != null) {
                            gatt.close();
                            gatt.disconnect();
                        }
                        dialog.dismiss();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent
                                .FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        mDialog.dismiss();
                    }
                })
                .setCancelable(false)
                .show();
    }

    private void showDisconnectedDialog() {
        new AlertDialog.Builder(DetailActivity.this)
                .setMessage("Device disconnected. Restart the app?")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startAlarm(START_ACTIVITY_TIME);
                        Toast.makeText(getApplicationContext(), "Restarting", Toast.LENGTH_SHORT).show();
                        Process.killProcess(Process.myPid());
                    }
                })
                .setCancelable(false)
                .show();
    }

    private void showDeviceIdleDialog() {
        try {
            new AlertDialog.Builder(this)
                    .setMessage("Connection broken, Please restart the app.")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            BluetoothGatt gatt = mService.getGatt();
                            if (gatt != null) {
                                gatt.close();
                                gatt.disconnect();
                            }
                            dialog.dismiss();
                            startAlarm(START_ACTIVITY_TIME);
                            android.os.Process.killProcess(Process.myPid());
                            finish();
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            if (mDialog != null) {
                                mDialog.dismiss();
                            }
                        }
                    })
                    .setCancelable(false)
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static class IncomingHandler extends Handler {
        private final WeakReference<DetailActivity> mActivity;

        public IncomingHandler(DetailActivity activity) {
            mActivity = new WeakReference<DetailActivity>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            DetailActivity activity = mActivity.get();
            if (activity != null) {
                switch (msg.what) {
                    case BleService.MSG_STATE_CHANGED:
                        activity.stateChanged(BleService.State.values()[msg.arg1]);
                        break;

                    case NOT_CONNECTED_STATE:
                        if (!activity.isFinishing()) {
                            activity.showDeviceNotSupported();
                        }
                        break;

                    case NOT_RECEIVING_DATA:
                        if (!activity.isFinishing()) {
                            activity.showDeviceIdleDialog();
                        }
                        break;

                    case Constants.TIMER_TRIGGER:
                        activity.uploadDatas();
                        activity.mIncomingHandler.sendEmptyMessageDelayed(Constants.TIMER_TRIGGER, activity.mPrefs.getTimeDelay());
                        break;
                }
            }
            super.handleMessage(msg);
        }
    }

    private void showErrorDialog(String errorString) {
        AlertDialog d = new AlertDialog.Builder(DetailActivity.this,R.style.AlertDialogTheme)
                .setMessage(errorString)
                .setTitle(R.string.message_from_car)
                .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setCancelable(false)
                .show();

        int textViewId = d.getContext().getResources().getIdentifier("android:id/alertTitle", null, null);
        TextView tv = (TextView) d.findViewById(textViewId);
        if(tv != null) {
            tv.setTextColor(Color.BLACK);
        }
    }

    private final class ServiceHandler extends Handler {

        public ServiceHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            Log.d(TAG, "!msg received by service handler: " + msg.what);
            switch (msg.what) {
                case RPM_COMMAND:
                    sendCommand(Constants.RPM);
                    break;

                case RUNNING_TIME:
                    sendCommand(Constants.RUNNING_TIME);
                    break;

                case SPEED:
                    sendCommand(Constants.SPEED);
                    break;

                case DISTANCE_TRAVELLED:
                    sendCommand(Constants.DISTANCE_TRAVELLED);
                    break;

                case TROUBLE_CODES:
                    sendCommand(Constants.TROUBLE_CODES);
                    break;

                case COOLANT_TEMPERATURE:
                    sendCommand(Constants.COOLANT_TEMPERATURE);
                    break;

                case AIR_INTAKE:
                    sendCommand(Constants.INTAKE_AIR_TEMPERATURE);
                    break;

                case DUMMY_TEXT:
                    sendCommand(Constants.DUMMY_TEXT);
                    break;
            }
        }
    }
}