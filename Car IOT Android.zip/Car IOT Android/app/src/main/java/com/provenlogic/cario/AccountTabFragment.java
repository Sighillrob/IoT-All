package com.provenlogic.cario;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.provenlogic.cario.model.AccountDetailsResponse;
import com.provenlogic.cario.rest.ApiService;
import com.provenlogic.cario.utils.MySharedPreference;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by mathan on 3/9/15.
 */
public class AccountTabFragment extends Fragment {

    @Bind(R.id.email)
    EditText mEmail;
    @Bind(R.id.phone)
    EditText mPhone;
    @Bind(R.id.password)
    EditText mPassword;
    @Bind(R.id.retype_password)
    EditText mRetypePassword;
    @Bind(R.id.submit)
    TextView mSubmit;
    private ProgressDialog mDialog;
    private ApiService mApiService;
    private MySharedPreference mPrefs;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.account_fragment_layout, container, false);
        ButterKnife.bind(this, view);
        mApiService = ((MainApplication) getActivity().getApplication()).getApiClientInterface();
        mPrefs = new MySharedPreference(getActivity().getApplicationContext());
        getAccountDetails();
        updateUi(false);
        return view;
    }

    private void showDialog() {
        if (mDialog == null) {
            mDialog = new ProgressDialog(getActivity(), R.style.MyProgressDialogTheme);
        }
        mDialog.setMessage(getString(R.string.please_wait));
        mDialog.show();
    }

    private void getAccountDetails() {
        showDialog();
        mApiService.getAccountDetails(mPrefs.getUserId(), new Callback<AccountDetailsResponse>() {
            @Override
            public void success(AccountDetailsResponse accountDetailsResponse, Response response) {
                if (accountDetailsResponse == null) {
                    return;
                }
                if (mDialog != null) {
                    mDialog.dismiss();
                }
                if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                    mEmail.setText(accountDetailsResponse.getEmail());
                    mPhone.setText(accountDetailsResponse.getPhone());
                }
            }

            @Override
            public void failure(RetrofitError error) {

            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    @OnClick(R.id.submit)
    public void saveDetails() {
        if (mSubmit.isSelected()) {
            showDialog();
            updateUi(false);
            mSubmit.setText(R.string.edit);
            mSubmit.setSelected(false);
            updateAccountDetails();
        } else {
            updateUi(true);
            mSubmit.setText(R.string.save);
            mSubmit.setSelected(true);
        }
    }

    private void updateAccountDetails() {
        mApiService.editAccountDetails(mPrefs.getUserId(), mPhone.getText().toString(),
                mEmail.getText().toString(), mPassword.getText().toString(),
                mRetypePassword.getText().toString(), new Callback<JsonObject>() {
                    @Override
                    public void success(JsonObject jsonObject, Response response) {
                        if (mDialog != null) {
                            mDialog.dismiss();
                        }

                        if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                            boolean value = jsonObject.get("success").getAsBoolean();
                            if (value) {
                                Toast.makeText(getActivity(), getActivity().getString(R.string
                                        .account_details_updated_successfully), Toast.LENGTH_SHORT)
                                        .show();
                            }
                        }
                    }

                    @Override
                    public void failure(RetrofitError error) {
                        if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                            if (error == null) {
                                return;
                            }
                            if (RetrofitError.Kind.NETWORK.equals(error.getKind())) {
                                Toast.makeText(getActivity(), R.string.please_check_internet_connection, Toast
                                        .LENGTH_SHORT).show();
                            }
                            if (error.getResponse() != null &&
                                    error.getResponse().getStatus() == 403) {

                            }
                        }
                    }
                });
    }

    private void updateUi(boolean value) {
        mPhone.setSelected(value);
        mEmail.setSelected(value);
        mPassword.setSelected(value);
        mRetypePassword.setSelected(value);
        mPhone.setEnabled(value);
        mEmail.setEnabled(value);
        mPassword.setEnabled(value);
        mRetypePassword.setEnabled(value);
    }

}
