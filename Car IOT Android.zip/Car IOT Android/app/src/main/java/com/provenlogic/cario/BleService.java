package com.provenlogic.cario;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.text.TextUtils;
import android.util.Log;

import com.provenlogic.cario.utils.Bluebit;
import com.provenlogic.cario.utils.Constants;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.UUID;

public class
        BleService extends Service implements BluetoothAdapter.LeScanCallback {
    public static final String TAG = "BleService";
    static final int MSG_REGISTER = 1;
    static final int MSG_UNREGISTER = 2;
    static final int MSG_START_SCAN = 3;
    static final int MSG_STATE_CHANGED = 4;
    static final int MSG_DEVICE_FOUND = 5;
    static final int MSG_DEVICE_CONNECT = 6;
    static final int MSG_DEVICE_DISCONNECT = 7;
    static final int MSG_SERVICES_DISCOVERED = 8;
    static final int MSG_DEVICE_DATA = 9;
    private static final long SCAN_PERIOD = 4000;
    private static final String DEVICE_NAME = "SensorTag";
    private static final UUID UUID_HUMIDITY_SERVICE = UUID.fromString("f000aa20-0451-4000-b000-000000000000");
    private static final UUID UUID_HUMIDITY_DATA = UUID.fromString("f000aa21-0451-4000-b000-000000000000");
    private static final UUID UUID_HUMIDITY_CONF = UUID.fromString("f000aa22-0451-4000-b000-000000000000");
    private static final UUID UUID_CCC = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final byte[] ENABLE_SENSOR = {0x01};

    private static final LinkedList<Object> sWriteQueue = new LinkedList<Object>();
    private final IncomingHandler mHandler;
    private final List<Messenger> mClients = new LinkedList<Messenger>();
    private final IBinder binder = new LocalBinder();
    private StringBuffer mResponseBuffer = new StringBuffer();
    private boolean mWriting = false;
    private BluetoothGatt mGatt = null;
    private String mBluetoothDeviceAddress;
    private BluetoothAdapter mBluetooth = null;
    private State mState = State.UNKNOWN;
    private Handler handler = new Handler();
    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBtAdapter;
    private int mErrorCount = 20;

    private BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            mGatt = gatt;
            Log.d(TAG, "!Connection State Changed: " +
                    (newState == BluetoothProfile.STATE_CONNECTED ? "Connected" : "Disconnected") +
                    " , status: " + status);
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                setState(State.CONNECTED);
                gatt.discoverServices();
                handler.removeCallbacks(connectDevice);
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                setState(State.DISCONNECTED);
            } else {
                setState(State.IDLE);
                gatt.close();
                gatt.disconnect();
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            setState(State.SERVICES_DISCOVERED);
            int servicesCount = 0;
            List<BluetoothGattService> gattServices = gatt.getServices();
            if (gattServices != null) {
                servicesCount = gattServices.size();
                for (int i = 0; i < servicesCount; i++) {
                    Log.d(TAG, "!uuid: " + gattServices.get(i).getUuid().toString());
                }
            }
            Log.v(TAG, "!onServicesDiscovered, status: " + status + " , services size: " + servicesCount);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            String text = new String(characteristic.getValue());
            String data = text.replaceAll("\\r", " ");
            Log.v(TAG, "!onCharacteristicWrite: " + status + " , uuid: " + characteristic.getUuid() +
                    " , value: " + data);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            Log.d(TAG, "\n\n\n!inside onDescriptorWrite, uuid: " + descriptor.getUuid().toString() +
                    " , status: " + status + " , value: " + descriptor.getValue() + "\n\n\n");
            Log.v(TAG, "!onDescriptorWrite: " + status);

            if (status == BluetoothGatt.GATT_SUCCESS) {
                byte[] value = descriptor.getValue();
                if (Arrays.equals(value, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)) {
                    setState(State.NOTIFICATION_ENABLED);
                }
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            String text = new String(characteristic.getValue());
            String data = text.replaceAll("\\r", " ")
                    .replaceAll("SEARCHING...", "")
                    .replaceAll("  ", "");

            mResponseBuffer.append(data);

            Log.d(TAG, "!inside onCharacteristicChanged, uuid: " + characteristic.getUuid().toString() +
                    " , value: " + data + " , response buffer: " + mResponseBuffer +
                    " , is writing: " + mWriting);

            if(mResponseBuffer.length() == 0) {
                return;
            }

            Log.d(TAG, "!last char in buffer: " + mResponseBuffer.charAt(mResponseBuffer.length() - 1) +
                    " , is writing: " + mWriting);

            if (mResponseBuffer.charAt(mResponseBuffer.length() - 1)== '>') {
                Message msg = new Message();
                msg.what = MSG_DEVICE_DATA;
                msg.obj = mResponseBuffer.toString();
                parseResponse(mResponseBuffer.toString());

                mWriting = false;
                mResponseBuffer = new StringBuffer();
                Log.d(TAG, "!do next write");
                nextWrite();
            }
        }
    };
    private Runnable connectDevice = new Runnable() {

        @Override
        public void run() {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            mBtAdapter = mBluetoothManager.getAdapter();
            if (!TextUtils.isEmpty(mBluetoothDeviceAddress) && mBluetoothManager != null &&
                    mBtAdapter != null && mBtAdapter.isEnabled()) {
                final BluetoothDevice device = mBtAdapter.getRemoteDevice(mBluetoothDeviceAddress);
                if (device != null) {
                    int connectionState = mBluetoothManager.getConnectionState(device, BluetoothProfile.GATT);

                    if (connectionState != BluetoothProfile.STATE_CONNECTED &&
                            connectionState != BluetoothProfile.STATE_CONNECTING) {
                        Log.d(TAG, "BluetoothLeService Create a new GATT connection.");
                        device.connectGatt(BleService.this, false, mGattCallback);
                    }
                }
                handler.postDelayed(connectDevice, 2000);
            }
        }
    };

    public BleService() {
        mHandler = new IncomingHandler(this);
    }

    private void parseResponse(String response) {
        response = response.replaceAll("> >",">");
        /*if(response.toLowerCase().contains(Constants.RPM.toLowerCase())) {
            response = "010c  UNABLE TO CONNECT >";
        }
        mErrorCount++;
        if(response.toLowerCase().contains(Constants.SPEED.toLowerCase())) {
            if(mErrorCount / 20 % 2  == 1) {
                response = "010d  NO DATA >";
            }
        }
        if(response.toLowerCase().contains(Constants.DISTANCE_TRAVELLED.toLowerCase())) {
            if(mErrorCount / 20 % 2  == 1) {
                response = "0131  NO DATA >";
            }
        }
        if(response.toLowerCase().contains(Constants.RUNNING_TIME.toLowerCase())) {
            if(mErrorCount / 20 % 2  == 1) {
                response = "011f  NO DATA >";
            }
        }
        if(response.toLowerCase().contains(Constants.COOLANT_TEMPERATURE.toLowerCase())) {
            if(mErrorCount / 20 % 2  == 1) {
                response = "0105  NO DATA >";
            }
        }
        if(response.toLowerCase().contains(Constants.INTAKE_AIR_TEMPERATURE.toLowerCase())) {
            if(mErrorCount / 20 % 2  == 1) {
                response = "010f  NO DATA >";
            }
        }*/


        StringTokenizer st = new StringTokenizer(response);
        Log.d("IMPORTANT_LOG", "FIRST_ENTRY" + response);
        ArrayList<String> items = new ArrayList<>();
        while (st.hasMoreElements()) {
            items.add(st.nextElement().toString());
        }

        if (items.size() > 0) {
            if(response.toLowerCase().contains(Constants.NO_DATA.toLowerCase())) {
                String msg = items.get(0) + "|" + Constants.IS_ERROR + "|" + Constants.NO_DATA;
                sendBroadcastMessage(msg);
                return;
            }
            if(response.toLowerCase().contains(Constants.UNABLE_TO_CONNECT.toLowerCase())) {
                String msg = items.get(0) + "|" + Constants.IS_ERROR + "|" + Constants.UNABLE_TO_CONNECT;
                sendBroadcastMessage(msg);
                return;
            }
            if (Constants.RPM.equalsIgnoreCase(items.get(0).toLowerCase())) {
                String byte1 = items.get(items.size() - 3);
                String byte2 = items.get(items.size() - 2);

                int digit1 = Integer.parseInt(byte1, 16);
                int digit2 = Integer.parseInt(byte2, 16);

                Log.e("IMPORTANT_LOG", "Byte 1 : " + byte1 + " Byte 2 : " + byte2 + " digit1 : " +
                        digit1 + " digit2 : " + digit2);

                int value = ((digit1 * 256) + digit2) / 4;
                String msg = Constants.RPM + "|" + value;
                sendBroadcastMessage(msg);
            } else if (Constants.ENGINE_LOAD.equalsIgnoreCase(items.get(0).toLowerCase())) {
                String byte1 = items.get(items.size() - 2);
                int digit1 = Integer.parseInt(byte1, 16);

                int value = digit1 * 100 / 255;
                String msg = Constants.ENGINE_LOAD + "|" + value;
                sendBroadcastMessage(msg);
            } else if (Constants.SPEED.equalsIgnoreCase(items.get(0).toLowerCase())) {
                String byte1 = items.get(items.size() - 2);
                int digit1 = Integer.parseInt(byte1, 16);

                String msg = Constants.SPEED + "|" + digit1;
                sendBroadcastMessage(msg);
            } else if (Constants.RUNNING_TIME.equalsIgnoreCase(items.get(0).toLowerCase())) {
                String byte1 = items.get(items.size() - 3);
                String byte2 = items.get(items.size() - 2);

                int digit1 = Integer.parseInt(byte1, 16);
                int digit2 = Integer.parseInt(byte2, 16);

                int value = (digit1 * 256) + digit2;
                String msg = Constants.RUNNING_TIME + "|" + value;
                sendBroadcastMessage(msg);
            } else if (Constants.DISTANCE_TRAVELLED.equalsIgnoreCase(items.get(0).toLowerCase())) {
                String byte1 = items.get(items.size() - 3);
                String byte2 = items.get(items.size() - 2);

                int digit1 = Integer.parseInt(byte1, 16);
                int digit2 = Integer.parseInt(byte2, 16);

                int value = (digit1 * 256) + digit2;
                String msg = Constants.DISTANCE_TRAVELLED + "|" + value;
                sendBroadcastMessage(msg);
            } else if (Constants.TROUBLE_CODES.equalsIgnoreCase(items.get(0).toLowerCase())) {
                Log.d("IMPORTANT_LOG", response);
                response = response
                        .replaceFirst(Constants.TROUBLE_CODES, "")
                        .replaceAll("SEARCHING...", "")
                        .replaceAll(" ", "")
                        .replaceAll("\\r\\r", "")
                        .replaceAll("\\r", "")
                        .replaceAll(".:", "")
                        .replaceAll(">", "");
                int index = response.indexOf(Constants.CODE_STARTING_INDEX);
                response = response.substring(index + Constants.CODE_STARTING_INDEX.length(), response.length());
                Log.d("IMPORTANT_LOG", "After Parsed   " + response);
                List<String> mCodesList = new ArrayList<>();
                for (int i = 0; i < response.length(); i += 4) {
                    String subString = response.substring(i, i + 4);

                    subString = subString.replaceFirst("^0", "p0")
                            .replaceFirst("^(A|a)", "b2")
                            .replaceFirst("^(B|b)", "b3")
                            .replaceFirst("^(C|c)", "u0")
                            .replaceFirst("^(D|d)", "u1")
                            .replaceFirst("^(E|e)", "u2")
                            .replaceFirst("^(F|f)", "u3")
                            .replaceFirst("^1", "p1")
                            .replaceFirst("^2", "p2")
                            .replaceFirst("^3", "p3")
                            .replaceFirst("^4", "c0")
                            .replaceFirst("^5", "c1")
                            .replaceFirst("^6", "c2")
                            .replaceFirst("^7", "c3")
                            .replaceFirst("^8", "b0")
                            .replaceFirst("^9", "b1");

                    if (!subString.equalsIgnoreCase(Constants.CODE_ENGINE_OK)) {
                        mCodesList.add(subString);
                        Log.d("IMPORTANT_LOG", "position : " + mCodesList.size() + " : " + subString);
                    }
                }

                String messageValue = Constants.TROUBLE_CODES;
                for (int i = 0; i < mCodesList.size(); i++) {
                    messageValue = messageValue + "|" + mCodesList.get(i);
                }
                Log.d("IMPORTANT_LOG", "SENDING VALUE : " + messageValue);
                sendBroadcastMessage(messageValue);
            } else if (Constants.COOLANT_TEMPERATURE.equalsIgnoreCase(items.get(0).toLowerCase())) {
                String byte1 = items.get(items.size() - 2);

                int digit1 = Integer.parseInt(byte1, 16);

                int value = digit1 - 40;
                String msg = Constants.COOLANT_TEMPERATURE + "|" + value;
                Log.d("IMPORTANT_LOG", "COOLANT SENDING VALUE : " + msg);
                sendBroadcastMessage(msg);
            } else if (Constants.INTAKE_AIR_TEMPERATURE.equalsIgnoreCase(items.get(0).toLowerCase())) {
                String byte1 = items.get(items.size() - 2);

                int digit1 = Integer.parseInt(byte1, 16);

                int value = digit1 - 40;
                String msg = Constants.INTAKE_AIR_TEMPERATURE + "|" + value;
                Log.d("IMPORTANT_LOG", "AIRINTAKE SENDING VALUE : " + msg);
                sendBroadcastMessage(msg);
            }
        }
    }

    /*public class BluetoothReceiveReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

        }
    }*/

    public void sendBroadcastMessage(String message) {
        Intent intent = new Intent();
        intent.setAction(Constants.BLUETOOTH_MESSAGE_INTENT);
        intent.putExtra(Constants.BLUETOOTH_MESSAGE, message);
        sendBroadcast(intent);
    }

    public BluetoothGatt getGatt() {
        return mGatt;
    }

    public void setGattNull() {
        mGatt = null;
    }

    @Override
    public void onRebind(Intent intent) {
        super.onRebind(intent);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "BluetoothLeService inside onUnbind");
        return true;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public void register(Messenger replyTo) {
        mClients.add(replyTo);
        Log.d(TAG, "!Client Registered");
    }

    public void unregister(Messenger replyTo) {
        mClients.remove(replyTo);
        if (mState == State.CONNECTED && mGatt != null) {
            mGatt.disconnect();
        }
        Log.d(TAG, "!Client Unegistered");
    }

    public void startScan() {
        Log.d(TAG, "!Start Scan");
//        setState(State.SCANNING);
        if (mBluetooth == null) {
            BluetoothManager bluetoothMgr = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            mBluetooth = bluetoothMgr.getAdapter();
        }
        if (mBluetooth == null || !mBluetooth.isEnabled()) {
            setState(State.BLUETOOTH_OFF);
        } else {
            Log.d(TAG, "!scan started");
            mBluetooth.startLeScan(this);
        }
    }

    public void stopScan() {
        Log.d(TAG, "!Stop Scan");
        setState(State.IDLE);
        if (mBluetooth == null) {
            BluetoothManager bluetoothMgr = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            mBluetooth = bluetoothMgr.getAdapter();
        }
        if (mBluetooth == null || !mBluetooth.isEnabled()) {
            setState(State.BLUETOOTH_OFF);
        } else {
            Log.d(TAG, "!scan stopped");
            mBluetooth.stopLeScan(this);
        }
    }

    @Override
    public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
        if (device.getName() != null) {
            Log.d(TAG, "!Added " + device.getName() + " : " + device.getAddress());
            sendDeviceBroadcast(device);
        }
    }

    private void sendDeviceBroadcast(BluetoothDevice device) {
        Intent intent = new Intent();
        intent.setAction(Constants.DEVICES_INTENT);
        intent.putExtra(Constants.DEVICE_BUNDLE_NAME, device);
        sendBroadcast(intent);
    }

    public void connect(String macAddress) {
        mBluetoothDeviceAddress = macAddress;
        handler.postDelayed(connectDevice, 1000);
        /*BluetoothDevice device = mDevices.get(macAddress);
        if (device != null) {
            mGatt = device.connectGatt(this, true, mGattCallback);
        }*/
    }

    public synchronized void write(Object o) {
        String data = o.toString().replaceAll("\\r", " ");
        Log.d(TAG, "!inside write, queue size: " + sWriteQueue.size() + " , buffer: " +
                mResponseBuffer + " , is writing: " + mWriting + " , received data: " + data);
        if (sWriteQueue.isEmpty() && !mWriting) {
            Log.d(TAG,"!writing data immediate - mResponseBuffer size " + mResponseBuffer.length() + " " +
                    "isWriting " + mWriting + " sWriteQueue size " + sWriteQueue.size());
            doWrite(o);
        } else {
            sWriteQueue.addLast(o);
        }
    }

    private synchronized void nextWrite() {
        Log.d(TAG, "!inside nextWrite, queue size: " + sWriteQueue.size() + " , buffer: " +
                mResponseBuffer + " , is writing: " + mWriting);
        if (!sWriteQueue.isEmpty() && !mWriting) {
            Log.d(TAG,"!writing data immediate - mResponseBuffer size " + mResponseBuffer.length() + " " +
                    "isWriting " + mWriting + " sWriteQueue size " + sWriteQueue.size());
            doWrite(sWriteQueue.getFirst());
            sWriteQueue.remove(0);
        }
    }

    private synchronized void doWrite(final Object o) {
        if(mGatt == null) {
            return;
        }
        mWriting = true;
        Log.d(TAG, "!inside doWrite, queue size: " + sWriteQueue.size() + " , buffer: " +
                mResponseBuffer + " , is writing: " + mWriting + " , value: " + o.toString());
        String command = o.toString() + "\r";
        BluetoothGattService proprietary = mGatt.getService(Bluebit.SERVICE_ISSC_PROPRIETARY);
        BluetoothGattCharacteristic mTransRx = proprietary.getCharacteristic(Bluebit.CHR_ISSC_TRANS_RX);
        mTransRx.setValue(command.getBytes());
        mTransRx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        mGatt.writeCharacteristic(mTransRx);
        /*if (o instanceof BluetoothGattCharacteristic) {
            BluetoothGattCharacteristic gattChar = (BluetoothGattCharacteristic) o;
            Log.d(TAG, "!writing value: " + (new String(gattChar.getValue())).replaceAll("\\r", " ") +
                    " , uuid: " + gattChar.getUuid().toString());
            mGatt.writeCharacteristic(gattChar);
        } else if (o instanceof BluetoothGattDescriptor) {
            mGatt.writeDescriptor((BluetoothGattDescriptor) o);
        } else {
            nextWrite();
        }*/
    }

    private void setState(State newState) {
        if (mState != newState) {
            mState = newState;
            int stateMessage = getStateMessage();
            sendStatesBroadcast(stateMessage);
        }
    }

    private void sendStatesBroadcast(int state) {
        Intent intent = new Intent();
        intent.setAction(Constants.STATES_INTENT);
        intent.putExtra(Constants.STATES_FIELD, state);
        sendBroadcast(intent);
    }

    private int getStateMessage() {
        return mState.ordinal();
    }

    private void sendMessage(Message msg) {
        if (msg != null && msg.obj != null) {
            Log.d("IMPORTANT_SEND", msg.obj.toString());
        }
        for (int i = mClients.size() - 1; i >= 0; i--) {
            Messenger messenger = mClients.get(i);
            if (!sendMessage(messenger, msg)) {
                mClients.remove(messenger);
            }
        }
    }

    private boolean sendMessage(Messenger messenger, Message msg) {
        boolean success = true;
        try {
            messenger.send(msg);
        } catch (Exception e) {
            e.printStackTrace();
            Log.w(TAG, "Lost connection to client", e);
            success = false;
        }
        return success;
    }

    private void subscribe(BluetoothGatt gatt) {
        BluetoothGattService humidityService = gatt.getService(UUID_HUMIDITY_SERVICE);
        if (humidityService != null) {
            BluetoothGattCharacteristic humidityCharacteristic = humidityService.getCharacteristic(UUID_HUMIDITY_DATA);
            BluetoothGattCharacteristic humidityConf = humidityService.getCharacteristic(UUID_HUMIDITY_CONF);
            if (humidityCharacteristic != null && humidityConf != null) {
                BluetoothGattDescriptor config = humidityCharacteristic.getDescriptor(UUID_CCC);
                if (config != null) {
                    gatt.setCharacteristicNotification(humidityCharacteristic, true);
                    humidityConf.setValue(ENABLE_SENSOR);
                    write(humidityConf);
                    config.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    write(config);
                }
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mGatt != null) {
            mGatt.disconnect();
            mGatt.close();
        }
    }

    public enum State {
        UNKNOWN,
        IDLE,
        SCANNING,
        BLUETOOTH_OFF,
        CONNECTING,
        CONNECTED,
        DISCONNECTING,
        DISCONNECTED,
        SERVICES_DISCOVERED,
        NOTIFICATION_ENABLED
    }

    private static class IncomingHandler extends Handler {
        private final WeakReference<BleService> mService;

        public IncomingHandler(BleService service) {
            mService = new WeakReference<BleService>(service);
        }

        @Override
        public void handleMessage(Message msg) {
            BleService service = mService.get();
            if (service != null) {
                switch (msg.what) {
                    case MSG_REGISTER:
                        service.mClients.add(msg.replyTo);
                        Log.d(TAG, "Registered");
                        break;
                    case MSG_UNREGISTER:
                        service.mClients.remove(msg.replyTo);
                        if (service.mState == State.CONNECTED && service.mGatt != null) {
                            service.mGatt.disconnect();
                        }
                        Log.d(TAG, "Unegistered");
                        break;
                    case MSG_START_SCAN:
                        service.startScan();
                        Log.d(TAG, "Start Scan");
                        break;
                    case MSG_DEVICE_CONNECT:
                        service.connect((String) msg.obj);
                        break;
                    case MSG_DEVICE_DISCONNECT:
                        if (service.mState == State.CONNECTED && service.mGatt != null) {
                            service.mGatt.disconnect();
                        }
                        break;
                    default:
                        super.handleMessage(msg);
                }
            }
        }
    }

    public class LocalBinder extends Binder {
        public BleService getService() {
            return BleService.this;
        }
    }
}