package com.provenlogic.cario.rest;

/**
 * Created by mathan on 9/9/15.
 */

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit.RestAdapter;
import retrofit.client.OkClient;
import retrofit.converter.GsonConverter;

/**
 * Created by sony on 3/4/2015.
 */
public class RestClient {
    public static final String BASE_URL = "http://engine-codes.herokuapp.com/api/";
    public static final String API_URL = "http://50.112.149.198/api/";
    private ApiService apiService;
    private ApiService restService;

    public RestClient() {
        Gson gson = new GsonBuilder()
                .setDateFormat("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'SSS'Z'")
                .create();

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .setEndpoint(BASE_URL)
                .setClient(new OkClient())
                .setConverter(new GsonConverter(gson))
                .build();

        RestAdapter apiAdapter = new RestAdapter.Builder()
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .setEndpoint(API_URL)
                .setClient(new OkClient())
                .setConverter(new GsonConverter(gson))
                .build();

        apiService = restAdapter.create(ApiService.class);

        restService = apiAdapter.create(ApiService.class);
    }

    public ApiService getRestService() {
        return restService;
    }

    public ApiService getApiService() {
        return apiService;
    }

}
