package com.provenlogic.cario;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.provenlogic.cario.utils.Constants;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by mathan on 7/9/15.
 */
public class TemperatureFragment extends Fragment {

    @Bind(R.id.filter_root_Layout)
    RelativeLayout mFilterRootLayout;
    @Bind(R.id.coolant_temperature)
    TextView mCoolantTemperature;
    @Bind(R.id.air_intake)
    TextView mAirIntake;
    @Bind(R.id.coolant_meter)
    ImageView mCoolantMeter;
    @Bind(R.id.air_intake_meter)
    ImageView mAirIntakeMeter;
    @Bind(R.id.value_header)
    LinearLayout mValueHeader;
    @Bind(R.id.air_intake_title)
    TextView mAirIntakeTitle;
    @Bind(R.id.coolant_title)
    TextView mCoolantTitle;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.temperature_layout, container, false);
        ButterKnife.bind(this, view);
        updateAirIntakeTemperature("" + 0);
        updateCoolantTemperature("" + 0);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    public void updateCoolantTemperature(String value) {
        if (value.equalsIgnoreCase(Constants.IS_ERROR)) {
            mCoolantTemperature.setText("-");
            mCoolantTitle.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.alert, 0, 0);
        } else {
            mCoolantTemperature.setText(value + " " + (char) 0x00B0 + " C");
            int temp = Integer.parseInt(value);
            temp += 40;
            mCoolantMeter.setImageLevel(temp);
            mCoolantTitle.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        }
    }

    @OnClick(R.id.coolant_title)
    public void showCoolantErrorDialog() {
        HomeScreenActivity activity = (HomeScreenActivity) getActivity();
        activity.showErrorDialog(Constants.COOLANT_TEMPERATURE);
    }

    @OnClick(R.id.air_intake_title)
    public void showAirIntakeErrorDialog() {
        HomeScreenActivity activity = (HomeScreenActivity) getActivity();
        activity.showErrorDialog(Constants.INTAKE_AIR_TEMPERATURE);
    }

    public void updateAirIntakeTemperature(String value) {
        if (value.equalsIgnoreCase(Constants.IS_ERROR)) {
            mAirIntake.setText("-");
            mAirIntakeTitle.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.alert, 0, 0);
        } else {
            mAirIntake.setText(value + " " + (char) 0x00B0 + " C");
            int temp = Integer.parseInt(value);
            temp += 40;
            mAirIntakeMeter.setImageLevel(temp);
            mAirIntakeTitle.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }
}
