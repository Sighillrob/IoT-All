package com.provenlogic.cario;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.ConfirmPassword;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Order;
import com.mobsandgeeks.saripaar.annotation.Password;
import com.provenlogic.cario.model.SignUpResponse;
import com.provenlogic.cario.rest.ApiService;
import com.provenlogic.cario.utils.MySharedPreference;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class RegistrationActivity extends AppCompatActivity implements Validator.ValidationListener {

    @NotEmpty(message = "Please enter First name")
    @Order(1)
    @Bind(R.id.first_name)
    EditText mFirstName;
    @NotEmpty(message = "Please enter Last name")
    @Order(2)
    @Bind(R.id.last_name)
    EditText mLastName;
    @NotEmpty(sequence = 1, message = "Please enter Email Id")
    @Email(sequence = 2, message = "Please enter valid Email Id")
    @Order(3)
    @Bind(R.id.email)
    EditText mEmail;
    @NotEmpty(sequence = 1, message = "Please enter Password")
    @Password(sequence = 2, min = 2, message = "Please enter valid Password")
    @Order(4)
    @Bind(R.id.password)
    EditText mPassword;
    @NotEmpty(sequence = 1, message = "Please enter Confirm Password")
    @ConfirmPassword(sequence = 2, message = "Password does not match")
    @Order(5)
    @Bind(R.id.retype_password)
    EditText mRetypePassword;
    @NotEmpty(message = "Please enter Phone number")
    @Order(6)
    @Bind(R.id.phone)
    EditText mPhone;
    @Order(6)
    @NotEmpty
    @Bind(R.id.submit)
    Button mSubmit;
    @Bind(R.id.back_icon)
    ImageView mBackIcon;
    private Validator mValidator;
    private ApiService mApiService;
    private MySharedPreference mPrefs;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        ButterKnife.bind(this);
        mValidator = new Validator(this);
        mValidator.setValidationMode(Validator.Mode.IMMEDIATE);
        mValidator.setValidationListener(this);
        mApiService = ((MainApplication) getApplication()).getApiClientInterface();
        mPrefs = new MySharedPreference(getApplicationContext());
    }

    @Override
    public void onBackPressed() {
        gotoPreviousActivity();
    }

    @OnClick(R.id.back_icon)
    public void gotoPreviousActivity() {
        Intent intent = new Intent(getApplicationContext(),CredentialChoosingActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    @OnClick(R.id.submit)
    public void submit() {
        mValidator.validate();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void showToast(int messageId) {
        Toast.makeText(this, messageId, Toast.LENGTH_LONG).show();
    }


    private void showProgressDialog() {
        if (mDialog == null) {
            mDialog = new ProgressDialog(this);
        }
        mDialog.setCancelable(false);
        mDialog.setMessage("Please wait...");
        mDialog.show();
    }

    @Override
    public void onValidationSucceeded() {
        showProgressDialog();
        mApiService.registerUser(mEmail.getText().toString(), mPassword.getText().toString(),
                mFirstName.getText().toString(), mLastName.getText().toString(),
                mPhone.getText().toString(), "asdasdasdasd", "ios", "manual", new
                        Callback<SignUpResponse>() {
                            @Override
                            public void success(SignUpResponse signUpResponse, Response response) {
                                if (mDialog != null) {
                                    mDialog.dismiss();
                                }
                                if (signUpResponse.getSuccess()) {
                                    mPrefs.setUserId("" + signUpResponse.getId());
                                    mPrefs.setEmailId(mEmail.getText().toString());
                                    mPrefs.setFirstName(mFirstName.getText().toString());
                                    mPrefs.setToken(signUpResponse.getToken());
                                    mPrefs.setClkValue(signUpResponse.getCik());
                                    mPrefs.setDashboardUrl(signUpResponse.getDashBoardLink());
                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Toast.makeText(getApplicationContext(), signUpResponse
                                            .getError(), Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void failure(RetrofitError error) {
                                if (mDialog != null) {
                                    mDialog.dismiss();
                                }
                                Log.e("IMPORTANT_LOG", "Error" + error.getLocalizedMessage());
                                Toast.makeText(getApplicationContext(), R.string.please_check_internet_connection, Toast
                                        .LENGTH_SHORT)
                                        .show();
                            }
                        });
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        switch (errors.get(0).getView().getId()) {
            case R.id.first_name:
                showToast(R.string.please_enter_first_name);
                break;
            case R.id.last_name:
                showToast(R.string.please_enter_second_name);
                break;
            case R.id.email:
                showToast(R.string.please_enter_email_id);
                break;
            case R.id.password:
                showToast(R.string.please_enter_password);
                break;
            case R.id.retype_password:
                showToast(R.string.please_enter_confirm_password);
                break;
            case R.id.phone:
                showToast(R.string.please_enter_phone);
                break;
        }
    }
}
