package com.provenlogic.cario;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DetailSampleActivity extends AppCompatActivity {

    @Bind(R.id.start_icon)
    ImageView mStartIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_sample);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.start_icon)
    public void gotoHomeScreen() {
        startActivity(new Intent(getApplicationContext(), HomeScreenActivity.class));
    }

}
