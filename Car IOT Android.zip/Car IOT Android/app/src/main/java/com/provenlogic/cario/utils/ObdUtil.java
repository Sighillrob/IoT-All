package com.provenlogic.cario.utils;

import android.content.Context;

public class ObdUtil {

    private Context mContext;

    public void register(Context context) {
        mContext = context;
    }

    public void unregister() {

    }
}