package com.provenlogic.cario;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.provenlogic.cario.model.TroubleCodesResponse;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by mathan on 9/9/15.
 */
public class TroubleCodesAdapter extends BaseAdapter {

    private Context mContext;
    private List<TroubleCodesResponse> mTroubleCodesResponseList;

    public TroubleCodesAdapter(Context context) {
        mContext = context;
    }

    public void updateTroubleCodes(List<TroubleCodesResponse> troubleCodesResponses) {
        mTroubleCodesResponseList = troubleCodesResponses;
    }

    @Override
    public int getCount() {
        return mTroubleCodesResponseList == null ? 0 : mTroubleCodesResponseList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        TroubleCodesResponse troubleCodesResponse = mTroubleCodesResponseList.get(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.trouble_codes_list_item,
                    parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.mTroubleCode.setText(troubleCodesResponse.getCode());
        holder.mReason.setText(troubleCodesResponse.getTitle());
        holder.mSolutions.setText(troubleCodesResponse.getNotes());
        return convertView;
    }

    /**
     * This class contains all butterknife-injected Views & Layouts from layout file 'trouble_codes_list_item.xml'
     * for easy to all layout elements.
     *
     * @author ButterKnifeZelezny, plugin for Android Studio by Avast Developers (http://github.com/avast)
     */
    static class ViewHolder {
        @Bind(R.id.trouble_code)
        TextView mTroubleCode;
        @Bind(R.id.reason)
        TextView mReason;
        @Bind(R.id.solutions)
        TextView mSolutions;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
