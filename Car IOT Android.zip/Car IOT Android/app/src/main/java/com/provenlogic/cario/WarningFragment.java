package com.provenlogic.cario;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.provenlogic.cario.model.TroubleCodesResponse;
import com.provenlogic.cario.rest.ApiService;
import com.provenlogic.cario.utils.Constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by mathan on 7/9/15.
 */
public class WarningFragment extends Fragment {

    @Bind(R.id.root_layout)
    LinearLayout mRootLayout;
    @Bind(R.id.trouble_codes_list)
    ListView mTroubleCodesList;
    @Bind(R.id.trouble_code)
    TextView mTroubleCode;
    @Bind(R.id.trouble_code_error)
    ImageView mTroubleCodeError;
    private ApiService mApiClient;
    private HashMap<String, String> mTroubleHashMap = new HashMap<>();
    private List<String> mCodesList = new ArrayList<>();
    private List<TroubleCodesResponse> mTroubleCodesResponses = new ArrayList<>();
    private TroubleCodesAdapter mAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.warning_layout, container, false);
        ButterKnife.bind(this, view);
        mApiClient = ((MainApplication) getActivity().getApplication()).getClientInterface();
        mAdapter = new TroubleCodesAdapter(getActivity());
        mTroubleCodesList.setAdapter(mAdapter);
        return view;
    }

    public void setTroubleCodeError() {
        mTroubleCodeError.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.trouble_code_error)
    public void showTroubleCodeErrorDialog() {
        HomeScreenActivity activity = (HomeScreenActivity) getActivity();
        activity.showErrorDialog(Constants.TROUBLE_CODES);
    }

    public void updateTroubleCodes(List<String> codesList) {
        mTroubleCodeError.setVisibility(View.GONE);
        if (mCodesList.equals(codesList)) {
            return;
        }
        mCodesList = codesList;
        mTroubleCodesResponses.clear();
        mAdapter.updateTroubleCodes(null);
        mAdapter.notifyDataSetChanged();
        mTroubleHashMap.clear();
        if (mCodesList.size() == 0) {
            mTroubleCode.setVisibility(View.VISIBLE);
            mTroubleCodesList.setVisibility(View.GONE);
        } else {
            mTroubleCode.setVisibility(View.GONE);
            mTroubleCodesList.setVisibility(View.VISIBLE);
        }
        for (int i = 0; i < mCodesList.size(); i++) {
            mApiClient.getTroubleCodeInformation(mCodesList.get(i), new
                    Callback<List<TroubleCodesResponse>>() {
                        @Override
                        public void success(List<TroubleCodesResponse> troubleCodesResponseList, Response response) {
                            if (!isAdded() && isRemoving() && isDetached() && !isVisible()) {
                                return;
                            }
                            if (troubleCodesResponseList != null && troubleCodesResponseList.size() > 0) {
                                if (!mTroubleHashMap
                                        .containsKey(troubleCodesResponseList.get(0).getCode())) {
                                    mTroubleHashMap.put(troubleCodesResponseList.get(0).getCode()
                                            , "yes");
                                    mTroubleCodesResponses.add(troubleCodesResponseList.get(0));
                                    mAdapter.updateTroubleCodes(mTroubleCodesResponses);
                                    mAdapter.notifyDataSetChanged();
                                }
                            }
                        }

                        @Override
                        public void failure(RetrofitError error) {
                            if (!isAdded() && isRemoving() && isDetached() && !isVisible()) {
                                return;
                            }
                            Log.d("IMPORTANT_LOG", "Error  -   " + error.getMessage() + "\n" + error.getLocalizedMessage());
                            if (error.getKind() == RetrofitError.Kind.NETWORK) {
                                HomeScreenActivity activity = ((HomeScreenActivity) getActivity());
                                if (activity.isViewPagerOnTroubleFragment()) {
                                    Toast.makeText(getActivity(), "Please check your internet connection.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    });
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }
}
