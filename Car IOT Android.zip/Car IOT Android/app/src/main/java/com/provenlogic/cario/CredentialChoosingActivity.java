package com.provenlogic.cario;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class CredentialChoosingActivity extends AppCompatActivity {

    @Bind(R.id.login)
    TextView mLogin;
    @Bind(R.id.signup)
    TextView mSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credential_choosing);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.login)
    public void gotoLoginScreen() {
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
    }

    @OnClick(R.id.signup)
    public void gotoSignupScreen() {
        startActivity(new Intent(getApplicationContext(), RegistrationActivity.class));
    }

}
