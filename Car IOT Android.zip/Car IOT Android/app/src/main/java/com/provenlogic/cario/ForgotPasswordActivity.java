package com.provenlogic.cario;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.provenlogic.cario.rest.ApiService;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class ForgotPasswordActivity extends AppCompatActivity {

    @Bind(R.id.email)
    EditText mEmail;
    @Bind(R.id.reset)
    TextView mReset;
    private ApiService mApiService;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        ButterKnife.bind(this);
        mApiService = ((MainApplication) getApplication()).getApiClientInterface();
    }

    private void showProgressDialog() {
        if(mDialog == null) {
            mDialog = new ProgressDialog(ForgotPasswordActivity.this);
        }
        mDialog.setMessage("Please wait...");
        mDialog.show();
    }

    private void showAlertDialog() {
        new AlertDialog.Builder(ForgotPasswordActivity.this)
                .setMessage("We've sent an e-mail to your e-mail address consisting a link to " +
                "reset your password")
                .setTitle("Password Reset Successfully")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .show();

    }

    @OnClick(R.id.reset)
    public void resetEmailId() {
        showProgressDialog();
        if (TextUtils.isEmpty(mEmail.getText().toString())) {
            Toast.makeText(getApplicationContext(), "Please enter valid email Id", Toast
                    .LENGTH_SHORT).show();
            return;
        }
        mApiService.forgotPassword(mEmail.getText().toString(), new Callback<JsonObject>() {
            @Override
            public void success(JsonObject jsonObject, Response response) {
                if (mDialog != null) {
                    mDialog.dismiss();
                }
                boolean value = jsonObject.get("success").getAsBoolean();
                if (value) {
                    showAlertDialog();
                    /*Toast.makeText(getApplicationContext(), jsonObject.get("message").getAsString(),
                            Toast.LENGTH_SHORT).show();*/
                } else {
                    Toast.makeText(getApplicationContext(), jsonObject.get("message").getAsString(),
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void failure(RetrofitError error) {
                if (error == null) {
                    return;
                }
                if (RetrofitError.Kind.NETWORK.equals(error.getKind())) {
                    Toast.makeText(getApplicationContext(), R.string.please_check_internet_connection, Toast
                            .LENGTH_SHORT).show();
                }
                if (error.getResponse() != null &&
                        error.getResponse().getStatus() == 403) {

                }

                if (mDialog != null) {
                    mDialog.dismiss();
                }
            }
        });
    }

}
