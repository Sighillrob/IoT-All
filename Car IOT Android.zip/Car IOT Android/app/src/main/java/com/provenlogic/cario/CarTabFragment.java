package com.provenlogic.cario;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.provenlogic.cario.model.CarDetailsResponse;
import com.provenlogic.cario.rest.ApiService;
import com.provenlogic.cario.utils.MySharedPreference;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by mathan on 3/9/15.
 */
public class CarTabFragment extends Fragment {

    @Bind(R.id.car_make)
    EditText mCarMake;
    @Bind(R.id.model)
    EditText mModel;
    @Bind(R.id.year)
    EditText mYear;
    @Bind(R.id.engine_no)
    EditText mEngineNo;
    @Bind(R.id.submit)
    TextView mSubmit;
    private ProgressDialog mDialog;
    private ApiService mApiService;
    private MySharedPreference mPrefs;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.car_fragment_layout, container, false);
        ButterKnife.bind(this, view);
        mApiService = ((MainApplication) getActivity().getApplication()).getApiClientInterface();
        mPrefs = new MySharedPreference(getActivity().getApplicationContext());
        getCarDetails();
        updateUi(false);
        return view;
    }

    private void showDialog() {
        if (mDialog == null) {
            mDialog = new ProgressDialog(getActivity(), R.style.MyProgressDialogTheme);
        }
        mDialog.setMessage(getString(R.string.please_wait));
        mDialog.show();
    }

    private void getCarDetails() {
        showDialog();
        mApiService.getCarDetails(mPrefs.getUserId(), new Callback<CarDetailsResponse>() {
            @Override
            public void success(CarDetailsResponse carDetailsResponse, Response response) {
                if (carDetailsResponse == null) {
                    return;
                }
                if (mDialog != null) {
                    mDialog.dismiss();
                }
                if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                    mCarMake.setText(carDetailsResponse.getCarMake());
                    mModel.setText(carDetailsResponse.getCarModel());
                    mYear.setText(carDetailsResponse.getCarYear());
                    mEngineNo.setText(carDetailsResponse.getCarEngineNo());
                }
            }

            @Override
            public void failure(RetrofitError error) {
                if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                    if (error == null) {
                        return;
                    }
                    if (RetrofitError.Kind.NETWORK.equals(error.getKind())) {
                        Toast.makeText(getActivity(), R.string.please_check_internet_connection, Toast
                                .LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    @OnClick(R.id.submit)
    public void saveDetails() {
        if (mSubmit.isSelected()) {
            showDialog();
            updateUi(false);
            mSubmit.setText(R.string.edit);
            mSubmit.setSelected(false);
            if(mPrefs.isCarUpdated()) {
                updateCarDetails();
            } else {
                addCarDetails();
            }

        } else {
            updateUi(true);
            mSubmit.setText(R.string.save);
            mSubmit.setSelected(true);
        }
    }

    private void addCarDetails() {
        mApiService.addCarDetails(mPrefs.getUserId(), mCarMake.getText().toString(),
                mModel.getText().toString(), mYear.getText().toString(), mEngineNo.getText().toString(),
                new Callback<JsonObject>() {
                    @Override
                    public void success(JsonObject jsonObject, Response response) {
                        if (mDialog != null) {
                            mDialog.dismiss();
                        }
                        mPrefs.setCarUpdated(true);
                        if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                            boolean value = jsonObject.get("success").getAsBoolean();
                            if (value) {
                                Toast.makeText(getActivity(), getActivity().getString(R.string
                                        .car_details_updated), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void failure(RetrofitError error) {
                        if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                            if (error == null) {
                                return;
                            }
                            if (RetrofitError.Kind.NETWORK.equals(error.getKind())) {
                                Toast.makeText(getActivity(), R.string.please_check_internet_connection, Toast
                                        .LENGTH_SHORT).show();
                            }
                            if (error.getResponse() != null &&
                                    error.getResponse().getStatus() == 403) {

                            }
                        }
                        if (mDialog != null) {
                            mDialog.dismiss();
                        }
                    }
                });
    }

    private void updateCarDetails() {
        mApiService.editCarDetails(mPrefs.getUserId(), mCarMake.getText().toString(),
                mModel.getText().toString(), mYear.getText().toString(), mEngineNo.getText().toString(),
                new Callback<JsonObject>() {
                    @Override
                    public void success(JsonObject jsonObject, Response response) {
                        if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                            if (mDialog != null) {
                                mDialog.dismiss();
                            }
                            boolean value = jsonObject.get("success").getAsBoolean();
                            if (value) {
                                Toast.makeText(getActivity(), getActivity().getString(R.string
                                        .car_details_updated), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void failure(RetrofitError error) {
                        if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                            if (mDialog != null) {
                                mDialog.dismiss();
                            }
                            if (error == null) {
                                return;
                            }
                            if (RetrofitError.Kind.NETWORK.equals(error.getKind())) {
                                Toast.makeText(getActivity(), R.string.please_check_internet_connection, Toast
                                        .LENGTH_SHORT).show();
                            }
                            if (error.getResponse() != null &&
                                    error.getResponse().getStatus() == 403) {

                            }
                        }
                    }
                });
    }

    private void updateUi(boolean value) {
        mCarMake.setSelected(value);
        mModel.setSelected(value);
        mEngineNo.setSelected(value);
        mYear.setSelected(value);
        mCarMake.setEnabled(value);
        mModel.setEnabled(value);
        mEngineNo.setEnabled(value);
        mYear.setEnabled(value);
    }
}
