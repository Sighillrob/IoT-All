package com.provenlogic.cario;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.provenlogic.cario.model.PersonalSettingsResponse;
import com.provenlogic.cario.rest.ApiService;
import com.provenlogic.cario.utils.MySharedPreference;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class GeneralTabFragment extends Fragment {

    @Bind(R.id.first_name)
    EditText mFirstName;
    @Bind(R.id.last_name)
    EditText mLastName;
    @Bind(R.id.country)
    EditText mCountry;
    @Bind(R.id.address)
    EditText mAddress;
    @Bind(R.id.male)
    TextView mMale;
    @Bind(R.id.female)
    TextView mFemale;
    @Bind(R.id.age)
    EditText mAge;
    @Bind(R.id.submit)
    TextView mSubmit;
    private ApiService mApiService;
    private MySharedPreference mPrefs;
    private ProgressDialog mDialog;

    public GeneralTabFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.general_item_layout, container, false);
        ButterKnife.bind(this, view);
        mMale.setSelected(true);
        mApiService = ((MainApplication) getActivity().getApplication()).getApiClientInterface();
        mPrefs = new MySharedPreference(getActivity().getApplicationContext());
        return view;
    }

    private void showDialog() {
        if (mDialog == null) {
            mDialog = new ProgressDialog(getActivity(), R.style.MyProgressDialogTheme);
        }
        mDialog.setMessage(getString(R.string.please_wait));
        mDialog.show();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getPersonalDetails();
        updateUI(false);
    }

    private void getPersonalDetails() {
        showDialog();
        mApiService.getProfileDetails(mPrefs.getUserId(), new Callback<PersonalSettingsResponse>() {
            @Override
            public void success(PersonalSettingsResponse personalSettingsResponse, Response response) {
                if (personalSettingsResponse == null) {
                    return;
                }

                if (mDialog != null) {
                    mDialog.dismiss();
                }

                if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                    mFirstName.setText(personalSettingsResponse.getFirstName());
                    mLastName.setText(personalSettingsResponse.getLastName());
                    mCountry.setText(personalSettingsResponse.getCountry());
                    mAge.setText(personalSettingsResponse.getDob());
                    mAddress.setText(personalSettingsResponse.getAddress());
                    if (personalSettingsResponse.getGender().equalsIgnoreCase("male")) {
                        mMale.setSelected(true);
                        mFemale.setSelected(false);
                    } else if (personalSettingsResponse.getGender().equalsIgnoreCase("female")) {
                        mMale.setSelected(false);
                        mFemale.setSelected(true);
                    } else {
                        mMale.setSelected(true);
                        mFemale.setSelected(false);
                    }
                }

            }

            @Override
            public void failure(RetrofitError error) {
                if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                    if (error == null) {
                        return;
                    }
                    if (RetrofitError.Kind.NETWORK.equals(error.getKind())) {
                        Toast.makeText(getActivity(), R.string.please_check_internet_connection, Toast
                                .LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @OnClick(R.id.submit)
    public void updateProfileDetails() {
        if (mSubmit.isSelected()) {
            showDialog();
            updateUI(false);
            String gender = "";
            if (mMale.isSelected()) {
                gender = "Male";
            } else {
                gender = "Female";
            }
            mApiService.editProfileDetails(mPrefs.getUserId(), mFirstName.getText().toString(),
                    mLastName.getText().toString(), mCountry.getText().toString(),
                    mAddress.getText().toString(), gender, "12-06-1993", new Callback<JsonObject>() {
                        @Override
                        public void success(JsonObject jsonObject, Response response) {

                            if (mDialog != null) {
                                mDialog.dismiss();
                            }

                            if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                                boolean value = jsonObject.get("success").getAsBoolean();
                                if (value) {
                                    Toast.makeText(getActivity(), getActivity().getString(R.string
                                            .profile_updated_successfully), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }

                        @Override
                        public void failure(RetrofitError error) {
                            if (isAdded() && isVisible() && !isDetached() && !isRemoving()) {
                                if (error == null) {
                                    return;
                                }
                                if (RetrofitError.Kind.NETWORK.equals(error.getKind())) {
                                    Toast.makeText(getActivity(), R.string.please_check_internet_connection, Toast
                                            .LENGTH_SHORT).show();
                                }
                                if (error.getResponse() != null &&
                                        error.getResponse().getStatus() == 403) {

                                }
                            }
                        }
                    });
            mSubmit.setText(R.string.edit);
            mSubmit.setSelected(false);
        } else {
            updateUI(true);
            mSubmit.setText(R.string.save);
            mSubmit.setSelected(true);
        }
    }

    private void updateUI(boolean value) {
        mFirstName.setSelected(value);
        mLastName.setSelected(value);
        mAddress.setSelected(value);
        mCountry.setSelected(value);
        mAge.setSelected(value);
        mFirstName.setEnabled(value);
        mLastName.setEnabled(value);
        mAddress.setEnabled(value);
        mCountry.setEnabled(value);
        mAge.setEnabled(value);
    }

    @OnClick(R.id.male)
    public void setMale() {
        if(mSubmit.isSelected()) {
            mMale.setSelected(true);
            mFemale.setSelected(false);
        }
    }

    @OnClick(R.id.female)
    public void setFemale() {
        if(mSubmit.isSelected()) {
            mFemale.setSelected(true);
            mMale.setSelected(false);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

}
