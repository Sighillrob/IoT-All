package com.provenlogic.cario.utils;

/**
 * Created by mathan on 5/9/15.
 */
public class Constants {
    public static final String DUMMY_TEXT ="0000";
    public static final String RPM = "010c";
    public static final String SPEED = "010d";
    public static final String ENGINE_LOAD = "0104";
    public static final String RUNNING_TIME = "011f";
    public static final String DISTANCE_TRAVELLED = "0131";
    public static final String COOLANT_TEMPERATURE = "0105";
    public static final String INTAKE_AIR_TEMPERATURE = "010f";
    public static final String TROUBLE_CODES = "03";
    public static final String CODE_STARTING_INDEX = "43";
    public static final String CODE_ENGINE_OK = "p0000";
    public static final String USER_ID = "user_id";
    public static final String FIRST_NAME = "first_name";
    public static final String LAST_NAME = "last_name";
    public static final String EMAIL_ID = "email_id";
    public static final String TOKEN = "token";
    public static final String EMPTY_STRING = "";
    public static final int TIMER_TRIGGER = 10;
    public static final String TIME_DELAY = "time_delay";
    public static final long DEFAULT_TIME_DELAY = 5000;
    public static final String CLK_VALUE = "clk_value";
    public static final String DEFAULT_CLK = "6c1fe13ca228d6f91502f862bf78138260acd4bf";
    public static final String RPC_DISTANCE = "dis";
    public static final String RPC_SPEED = "speed";
    public static final String RPC_RPM = "rpm";
    public static final String RPC_LOCATION = "location";
    public static final String RPC_CRITICAL_ALERTS = "critical";
    public static final String RPC_COOLANT = "coolant";
    public static final String RPC_AIRINTAKE = "airintake";
    public static final String RPC_ENGINE_RUNNING_TIME = "engrunningtime";
    public static final int RUNNING_TILE_FRAGMENT = 1;
    public static final int TEMPERATURE_FRAGMENT = 2;
    public static final int DISTANCE_TRAVELLED_FRAGMENT = 3;
    public static final int LOCATION_FRAGMENT = 4;
    public static final int TROUBLE_CODE_FRAGMENT = 5;
    public static final String FRAGMENT_POSITION = "fragment_position";
    public static final String BLUETOOTH_MESSAGE_INTENT = "com.provenlogic.tripland.message";
    public static final String STATES_INTENT = "com.provenlogic.tripland.states";
    public static final String DEVICES_INTENT = "com.provenlogic.tripland,devices";
    public static final String BLUETOOTH_MESSAGE = "message";
    public static final String DEVICE_BUNDLE_NAME = "devices_bundle";
    public static final String STATES_FIELD = "states";
    public static final String IS_CAR_UPDATED = "is_car_updated";
    public static final String DASHBOARD_URL = "dashboard_url";
    public static final String NO_DATA = "NO DATA >";
    public static final String UNABLE_TO_CONNECT = "UNABLE TO CONNECT >";
    public static final String IS_ERROR = "ERROR";
    public static final String IS_UNABLE_TO_CONNECT = "IS_UNABLE_TO_CONNECT";
    public static final String ERROR_PREFIX = "This car does not allow ";
    public static final String ERROR_SUFFIX = " information to be read through the OBD. Please " +
            "contact the authorised car dealer to hardwire information to the On-Board Diagnostics Channel.";
    public static final String UNABLE_TO_CONNECT_ERROR = "Message from the car OBD : UNALBE TO " +
            "CONNECT";
    public static final String NO_DATA_ERROR = "Message from the car OBD : NO DATA";
}
