package com.provenlogic.cario;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.github.glomadrian.dashedcircularprogress.DashedCircularProgress;
import com.provenlogic.cario.utils.Constants;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RpmFragment extends Fragment {

    @Bind(R.id.simple)
    DashedCircularProgress mRpmCircle;
    @Bind(R.id.rpm)
    TextView mRpm;
    @Bind(R.id.speed_status)
    TextView mSpeedStatus;
    @Bind(R.id.running_time)
    TextView mRunningTime;
    @Bind(R.id.engine_running_time)
    TextView mEngineRunningTime;
    private int mRpmValue = 0;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.rpm_fragment, container, false);
        ButterKnife.bind(this, view);
        initializingRPM();

        return view;
    }

    public void setRpmError() {
        mRpm.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, R.drawable.alert);
        mSpeedStatus.setText("-");
    }

    @OnClick(R.id.rpm)
    public void showRpmErrorDialog() {
        HomeScreenActivity activity = (HomeScreenActivity) getActivity();
        activity.showErrorDialog(Constants.RPM);
    }

    @OnClick(R.id.engine_running_time)
    public void showRunningTimeErrorDialog() {
        HomeScreenActivity activity = (HomeScreenActivity) getActivity();
        activity.showErrorDialog(Constants.RUNNING_TIME);
    }

    public void setRunningTimeError() {
        mRunningTime.setText("-");
        mEngineRunningTime.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.alert, 0);
    }

    public void setRpm(int rpmValue) {
        mRpmValue = rpmValue;
        if (isAdded() && !isRemoving() && !isDetached() && isVisible()) {
            mSpeedStatus.setText(""+mRpmValue);
            mRpmCircle.setValue(mRpmValue);
            mRpm.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        }
    }

    public void setRunningTime(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        seconds = seconds % 60;

        String hoursString = "" + hours;
        String minutesString = "" + minutes;
        String hrString = "Hr";
        minutesString = " : " + minutesString;

        SpannableStringBuilder spanTxt = new SpannableStringBuilder(hoursString);
        spanTxt.append(hrString)
                .append(minutesString)
                .append("Min");
        spanTxt.setSpan(new AbsoluteSizeSpan(25, true), 0, hoursString.length(), Spanned
                .SPAN_INCLUSIVE_INCLUSIVE);
        spanTxt.setSpan(new AbsoluteSizeSpan(25, true), spanTxt.toString().indexOf(minutesString),
                spanTxt.toString().indexOf(minutesString) + minutesString.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);

        String timeString = String.format("%02dHr : %02dMin", hours, minutes);
        Log.d("IMPORTANT_LOG", timeString);
        if (isAdded() && !isRemoving() && !isDetached() && isVisible()) {
            mRunningTime.setText(spanTxt);
            mEngineRunningTime.setCompoundDrawablesWithIntrinsicBounds(0, 0,0,0);
        }
    }

    private void initializingRPM() {
        mRpmCircle.setExternalColor(getResources().getColor(R.color.rpm_outer_color));
        mRpmCircle.setProgressColor(Color.WHITE);
        mRpmCircle.setInternalBaseColor(getResources().getColor(R.color.rpm_base_color));
        mRpmCircle.setDashWidth(50);
        mRpmCircle.setDashSpace(4);
        mRpmCircle.setInternalAngles(280, 338.4f);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRpmCircle.setValue(mRpmValue);
        setRunningTime(0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);

    }


}