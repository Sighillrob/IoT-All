package com.provenlogic.cario;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;

import com.provenlogic.cario.utils.MySharedPreference;

public class SplashActivity extends AppCompatActivity {

    private BleService mService;
    private MySharedPreference mPrefs;
    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mService = ((BleService.LocalBinder) service).getService();
            if (mService != null && mService.getGatt() != null && mService.getGatt()
                    .getConnectedDevices() != null) {
                int size = mService.getGatt().getConnectedDevices().size();
                if (size == 0) {
                    if (!TextUtils.isEmpty(mPrefs.getUserId())) {
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Intent intent = new Intent(getApplicationContext(), CredentialChoosingActivity.class);
                        startActivity(intent);
                        finish();
                    }
                } else {
                    if (!TextUtils.isEmpty(mPrefs.getUserId())) {
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Intent intent = new Intent(getApplicationContext(), CredentialChoosingActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            } else {
                if (!TextUtils.isEmpty(mPrefs.getUserId())) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(getApplicationContext(), CredentialChoosingActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService = null;
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mService != null) {
            unbindService(mConnection);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        mPrefs = new MySharedPreference(getApplicationContext());
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent serviceIntent = new Intent(getApplicationContext(), BleService.class);
                bindService(serviceIntent, mConnection, BIND_AUTO_CREATE);
            }
        }, 3000);
    }
}
