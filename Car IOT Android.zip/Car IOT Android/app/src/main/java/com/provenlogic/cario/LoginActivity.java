package com.provenlogic.cario;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Order;
import com.mobsandgeeks.saripaar.annotation.Password;
import com.provenlogic.cario.model.SignInResponse;
import com.provenlogic.cario.rest.ApiService;
import com.provenlogic.cario.utils.MySharedPreference;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class LoginActivity extends AppCompatActivity implements Validator.ValidationListener {

    @NotEmpty(sequence = 1, message = "Please enter Email Id")
    @Email(sequence = 2, message = "Please enter valid Email Id")
    @Order(1)
    @Bind(R.id.email)
    EditText mEmail;
    @NotEmpty(sequence = 1, message = "Please enter Password")
    @Password(sequence = 2, min = 2, message = "Please enter valid Password")
    @Order(2)
    @Bind(R.id.password)
    EditText mPassword;
    @Bind(R.id.login)
    Button mLogin;
    @Bind(R.id.forgot_password)
    TextView mForgotPassword;
    @Bind(R.id.back_icon)
    ImageView mBackIcon;
    private Validator mValidator;
    private ApiService mApiService;
    private MySharedPreference mPrefs;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        mValidator = new Validator(this);
        mValidator.setValidationMode(Validator.Mode.IMMEDIATE);
        mValidator.setValidationListener(this);
        mPrefs = new MySharedPreference(getApplicationContext());
        mApiService = ((MainApplication) getApplication()).getApiClientInterface();
    }

    @OnClick(R.id.back_icon)
    public void gotoPreviousActivity() {
        Intent intent = new Intent(getApplicationContext(),CredentialChoosingActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        gotoPreviousActivity();
    }

    @OnClick(R.id.forgot_password)
    public void gotoForgotPassword() {
        startActivity(new Intent(getApplicationContext(), ForgotPasswordActivity.class));
    }

    @OnClick(R.id.login)
    public void login() {
        mValidator.validate();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void showToast(int messageId) {
        Toast.makeText(this, messageId, Toast.LENGTH_LONG).show();
    }

    private void showProgressDialog() {
        if (mDialog == null) {
            mDialog = new ProgressDialog(this);
        }
        mDialog.setCancelable(false);
        mDialog.setMessage("Please wait...");
        mDialog.show();
    }

    @Override
    public void onValidationSucceeded() {
        showProgressDialog();
        mApiService.signInUser(mEmail.getText().toString(), mPassword.getText().toString(),
                "asdasdasdasd", "ios", "manual", new Callback<SignInResponse>() {
                    @Override
                    public void success(SignInResponse signInResponse, Response response) {
                        if (mDialog != null) {
                            mDialog.dismiss();
                        }
                        if (signInResponse.getSuccess()) {
                            mPrefs.setUserId(signInResponse.getId());
                            mPrefs.setFirstName(signInResponse.getFirstName());
                            mPrefs.setEmailId(mEmail.getText().toString());
                            mPrefs.setToken(signInResponse.getDeviceToken());
                            mPrefs.setClkValue(signInResponse.getCik());
                            mPrefs.setDashboardUrl(signInResponse.getDashBoardLink());
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(), signInResponse.getError(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void failure(RetrofitError error) {
                        if (mDialog != null) {
                            mDialog.dismiss();
                        }
                        Toast.makeText(getApplicationContext(), R.string
                                .please_check_internet_connection, Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        switch (errors.get(0).getView().getId()) {
            case R.id.email:
                showToast(R.string.enter_your_email_id);
                break;
            case R.id.password:
                showToast(R.string.enter_your_password);
                break;
        }
    }
}
