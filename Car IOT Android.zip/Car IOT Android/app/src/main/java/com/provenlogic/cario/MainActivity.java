package com.provenlogic.cario;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.os.SystemClock;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.provenlogic.cario.utils.Constants;
import com.provenlogic.cario.utils.DisconnectReceiver;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private static final String KEY_MAC_ADDRESS = "KEY_MAC_ADDRESS";
    private static final String KEY_NAME = "NAME";
    private static final String[] KEYS = {"NAME", "KEY_MAC_ADDRESS"};
    private static final int[] IDS = {R.id.device_name, R.id.device_id};
    private static final int ENABLE_BT = 0;
    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int NO_DEVICES_FOUND = 10;
    private static final int START_ACTIVITY_TIME = 1 * 1000;

    private final Messenger mMessenger;
    private static final int CLEAR_ALL_LOGIN = 11;
    @Bind(R.id.toolbar)
    Toolbar mToolbar;
    @Bind(android.R.id.list)
    ListView mList;
    @Bind(R.id.start_icon)
    ImageView mStartIcon;
    private BleService mService;
    private Intent mServiceIntent;
    private MenuItem mRefreshItem;
    private SimpleAdapter mAdapter;
    private BleService.State mState;
    BroadcastReceiver mStatesReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && Constants.STATES_INTENT.equalsIgnoreCase(intent.getAction())) {
                int message = intent.getIntExtra(Constants.STATES_FIELD, 0);
                stateChanged(BleService.State.values()[message]);
            }
        }
    };
    private HashMap<String, BluetoothDevice> mDevicesMap = new HashMap<>();
    private ListView mListView;
    private ProgressDialog mDialog;
    private IncomingHandler mIncomingHandler = new IncomingHandler(this);
    BroadcastReceiver mDevicesReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && Constants.DEVICES_INTENT.equalsIgnoreCase(intent.getAction())) {
                BluetoothDevice device = intent.getParcelableExtra(Constants.DEVICE_BUNDLE_NAME);
                if (!TextUtils.isEmpty(device.getAddress()) && !mDevicesMap.containsKey(device.getAddress())) {
                    if (mDialog != null) {
                        mDialog.dismiss();
                    }
                    mDevicesMap.put(device.getAddress(), device);
                    setDevices();
                }
            }
        }
    };
    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mService = ((BleService.LocalBinder) service).getService();
            //mService.register(mMessenger);
            if (mService != null) {
                startScan();
                showScanDialog();
            }
            mIncomingHandler.sendEmptyMessageDelayed(NO_DEVICES_FOUND, 30000);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService = null;
        }
    };
    private PendingIntent mPendingIntent;

    public MainActivity() {
        super();
        mMessenger = new Messenger(mIncomingHandler);
    }

    private void setDevices() {
        List<Map<String, String>> items = new ArrayList<Map<String, String>>();
        for (BluetoothDevice device : mDevicesMap.values()) {
            Map<String, String> item = new HashMap<String, String>();
            item.put(KEY_MAC_ADDRESS, device.getAddress());
            item.put(KEY_NAME, "" + device.getName());
            items.add(item);
        }
        if (items.size() > 0) {
            mIncomingHandler.removeMessages(NO_DEVICES_FOUND);
        }
        mAdapter = new SimpleAdapter(this, items, R.layout.device_list_item, KEYS, IDS);
        mListView.setAdapter(mAdapter);
    }

    @OnClick(R.id.user_icon)
    public void gotoSettingsScreen() {
        startActivityForResult(new Intent(getApplicationContext(), SettingsActivity.class), CLEAR_ALL_LOGIN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == CLEAR_ALL_LOGIN) {
            startAlarm(START_ACTIVITY_TIME);
            finish();
            Process.killProcess(Process.myPid());
        }
    }

    public void startAlarm(int time) {
        Intent alarmIntent = new Intent(getApplicationContext(), DisconnectReceiver.class);
        mPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, alarmIntent, 0);
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        manager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + time, mPendingIntent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        mListView = (ListView) findViewById(android.R.id.list);
        mListView.setOnItemClickListener(this);

        mState = BleService.State.UNKNOWN;

        IntentFilter filter = new IntentFilter();
        filter.addAction(Constants.STATES_INTENT);
        registerReceiver(mStatesReceiver, filter);
        IntentFilter devicesFilter = new IntentFilter();
        devicesFilter.addAction(Constants.DEVICES_INTENT);
        registerReceiver(mDevicesReceiver, devicesFilter);

        mServiceIntent = new Intent(this, BleService.class);
        bindService(mServiceIntent, mConnection, BIND_AUTO_CREATE);
    }

    @OnClick(R.id.start_icon)
    public void gotoDetailScreen() {
        /*startActivity(new Intent(getApplicationContext(), DetailSampleActivity.class));
        finish();*/
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mService != null) {
            mService.unregister(mMessenger);
            unbindService(mConnection);
            unregisterReceiver(mDevicesReceiver);
            unregisterReceiver(mStatesReceiver);
        }
/*
        RefWatcher refWatcher = MainApplication.getRefWatcher(this);
        refWatcher.watch(this);*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        mRefreshItem = menu.findItem(R.id.action_refresh);
        //mDeviceListFragment = DeviceListFragment.newInstance(null);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_refresh) {
            if (mService != null) {
                mService.stopScan();
                mDevicesMap.clear();
                setDevices();
                startScan();
                showScanDialog();
                mIncomingHandler.removeMessages(NO_DEVICES_FOUND);
                mIncomingHandler.sendEmptyMessageDelayed(NO_DEVICES_FOUND, 30000);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void startScan() {
        setDevices();
        mService.startScan();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        /*if (mRefreshItem != null) {
            mRefreshItem.setEnabled(mState == BleService.State.IDLE || mState == BleService.State.UNKNOWN);
        }*/
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent intent = new Intent(this, DetailActivity.class);
        Map<String, String> item = (Map<String, String>) mListView.getAdapter().getItem(i);
        intent.putExtra("device", (String) item.get(KEY_MAC_ADDRESS));
        startActivity(intent);
        finish();
    }

    private void stateChanged(BleService.State newState) {
        mState = newState;
        switch (mState) {
            case SCANNING:
//                mRefreshItem.setEnabled(true);
                break;

            case BLUETOOTH_OFF:
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, ENABLE_BT);
                break;

            case IDLE:
//                mRefreshItem.setEnabled(true);
                break;
        }
    }

    private void showScanDialog() {
        mDialog = new ProgressDialog(this, R.style.Dialog);
        mDialog.setMessage("Scanning for devices...");
        mDialog.setIndeterminate(true);
        mDialog.setCancelable(false);
        mDialog.setButton(DialogInterface.BUTTON_POSITIVE, getString(android.R.string.cancel), new
                DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (mService != null) {
                            mService.stopScan();
                        }
                    }
                });
        mDialog.show();
    }

    private void showNoDevicesFoundDialog() {
        try {
            new AlertDialog.Builder(this)
                    .setMessage("No devices found. Please restart your bluetooth.")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .setNegativeButton("Quit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            stopService(new Intent(getApplicationContext(), BleService.class));
                            finish();
                            android.os.Process.killProcess(Process.myPid());
                        }
                    })
                    .setCancelable(false)
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static class IncomingHandler extends Handler {
        private final WeakReference<MainActivity> mActivity;

        public IncomingHandler(MainActivity activity) {
            mActivity = new WeakReference<MainActivity>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            MainActivity activity = mActivity.get();
            if (activity != null) {
                switch (msg.what) {
                    case BleService.MSG_STATE_CHANGED:
                        activity.stateChanged(BleService.State.values()[msg.arg1]);
                        break;

                    case BleService.MSG_DEVICE_FOUND:
                        Bundle data = msg.getData();

                        break;
                    case NO_DEVICES_FOUND:
                        if (activity.mDialog != null) {
                            activity.mDialog.dismiss();
                        }
                        activity.showNoDevicesFoundDialog();
                }
            }
            super.handleMessage(msg);
        }
    }
}