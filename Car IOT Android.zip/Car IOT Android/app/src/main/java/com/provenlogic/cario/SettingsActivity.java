package com.provenlogic.cario;

import android.bluetooth.BluetoothGatt;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.provenlogic.cario.utils.MySharedPreference;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SettingsActivity extends AppCompatActivity {

    @Bind(R.id.general_tab)
    TextView mGeneralTab;
    @Bind(R.id.car_tab)
    TextView mCarTab;
    @Bind(R.id.account_tab)
    TextView mAccountTab;
    @Bind(R.id.container)
    FrameLayout mContainer;
    @Bind(R.id.settings)
    TextView mSettings;
    @Bind(R.id.logout)
    TextView mLogout;
    @Bind(R.id.tab_section)
    LinearLayout mTabSection;
    @Bind(R.id.open_dashboard)
    TextView mOpenDashboard;
    @Bind(R.id.back_button)
    ImageView mBackButton;
    private FragmentManager mFragmentManager;
    private MySharedPreference mPrefs;
    private Intent mServiceIntent;
    private static final int CLEAR_ALL_LOGIN = 11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        ButterKnife.bind(this);
        mPrefs = new MySharedPreference(getApplicationContext());
        mFragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        resetViews();
        mGeneralTab.setBackgroundColor(Color.WHITE);
        mGeneralTab.setTextColor(getResources().getColor(R.color.colorPrimary));
        fragmentTransaction.add(R.id.container, new GeneralTabFragment());
        fragmentTransaction.commit();
        mServiceIntent = new Intent(this, BleService.class);
        bindService(mServiceIntent, mConnection, BIND_AUTO_CREATE);
    }

    private BleService mService;
    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mService = ((BleService.LocalBinder) service).getService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService = null;
        }
    };

    @OnClick(R.id.back_button)
    public void finishActivity() {
        finish();
    }

    @OnClick(R.id.general_tab)
    public void showGeneralTab() {
        resetViews();
        mGeneralTab.setBackgroundColor(Color.WHITE);
        mGeneralTab.setTextColor(getResources().getColor(R.color.colorPrimary));
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, new GeneralTabFragment());
        fragmentTransaction.commit();
    }

    @OnClick(R.id.car_tab)
    public void showCarTab() {
        resetViews();
        mCarTab.setBackgroundColor(Color.WHITE);
        mCarTab.setTextColor(getResources().getColor(R.color.colorPrimary));
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, new CarTabFragment());
        fragmentTransaction.commit();
    }

    @OnClick(R.id.account_tab)
    public void showAccountTab() {
        resetViews();
        mAccountTab.setBackgroundColor(Color.WHITE);
        mAccountTab.setTextColor(getResources().getColor(R.color.colorPrimary));
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, new AccountTabFragment());
        fragmentTransaction.commit();
    }

    @OnClick(R.id.logout)
    public void logout() {
        mPrefs.clearAllData();
        if(mService != null) {
            BluetoothGatt gatt = mService.getGatt();
            if(gatt != null) {
                gatt.disconnect();
                gatt.close();
                mService.setGattNull();
            }
        }
        stopService(new Intent(getApplicationContext(), BleService.class));
        setResult(CLEAR_ALL_LOGIN);
        Toast.makeText(getApplicationContext(), "Logged out", Toast.LENGTH_SHORT).show();
        finish();
    }

    @OnClick(R.id.open_dashboard)
    public void gotoDashBoard() {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(mPrefs.getDashboardUrl()));
        startActivity(browserIntent);
    }

    private void resetViews() {
        mGeneralTab.setBackground(getResources().getDrawable(R.drawable.border));
        mCarTab.setBackground(getResources().getDrawable(R.drawable.border));
        mAccountTab.setBackgroundResource(R.drawable.border);
        mGeneralTab.setTextColor(Color.WHITE);
        mCarTab.setTextColor(Color.WHITE);
        mAccountTab.setTextColor(Color.WHITE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mConnection);
    }
}
