package com.provenlogic.cario;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothGatt;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.drawable.LevelListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.provenlogic.cario.utils.Constants;
import com.provenlogic.cario.utils.MySharedPreference;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class HomeScreenActivity extends AppCompatActivity implements TabLayout
        .OnTabSelectedListener {

    private static final String TAG = "!IMPORTANT";
    private static final int RPM_COMMAND = 0;
    private static final int RUNNING_TIME = 1;
    private static final int SPEED = 2;
    private static final int DISTANCE_TRAVELLED = 3;
    private static final int TROUBLE_CODES = 4;
    private static final int COOLANT_TEMPERATURE = 5;
    private static final int AIR_INTAKE = 6;
    private static final int DUMMY_TEXT = 7;
    private static final int NOT_RECEIVING_DATA = 1000;
    private static final int CLEAR_ALL = 10;
    private static final int TIMER_TIME = 200;
    @Bind(R.id.back_button)
    ImageView mBackButton;
    @Bind(R.id.toolbar)
    Toolbar mToolbar;
    @Bind(R.id.pager)
    ViewPager mPager;
    @Bind(R.id.tabLayout)
    TabLayout mTabLayout;
    @Bind(R.id.root_layout)
    LinearLayout mRootLayout;
    @Bind(R.id.more_button)
    ImageView mMoreButton;
    @Bind(R.id.toolbar_title)
    TextView mToolbarTitle;
    private TabLayout tabLayout;
    private HashMap<String, Boolean> mErrorMap = new HashMap<>();
    private HashMap<String, String> mErrorTextMap = new HashMap<>();
    private HashMap<String,String> mErrorTitleMap = new HashMap<>();
    private Intent mServiceIntent;
    private String[] mTitle = new String[]{"Engine Info", "Temperature", "Vehicle Info",
            "Location Info", "Critical Alert Info"};
    private int[] mInfoDetails = new int[]{R.string.info_1, R.string.info_2, R.string.info_3};

    private BleService mService;
    private BleService.State mState;
    BroadcastReceiver mStatesReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && Constants.STATES_INTENT.equalsIgnoreCase(intent.getAction())) {
                int message = intent.getIntExtra(Constants.STATES_FIELD, 0);
                stateChanged(BleService.State.values()[message]);
            }
        }
    };
    private ViewPager mViewPager;
    private ServiceHandler mServiceHandler;
    private HandlerThread mThread;
    private List<String> mCodesList = new ArrayList<>();
    private IncomingHandler mIncomingHandler;
    private String mCriticalAlerts = "";
    private MySharedPreference mPrefs;
    private ProgressDialog mDialog;

    BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && Constants.BLUETOOTH_MESSAGE_INTENT.equalsIgnoreCase(intent.getAction())) {
                final String message = intent.getStringExtra(Constants.BLUETOOTH_MESSAGE);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        parseAndGenerate(message);
                    }
                });
            }
        }
    };

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mService = ((BleService.LocalBinder) service).getService();
            sendOBDCommandDependsOnPosition();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService = null;
        }
    };

    private ViewPager.OnPageChangeListener mOnPageChangeListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            updateUI(position);
            mToolbarTitle.setText(mTitle[position]);
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

    private static String makeFragmentName(int viewId, int index) {
        return "android:switcher:" + viewId + ":" + index;
    }

    @OnClick(R.id.more_button)
    public void showInfoDetails() {
        String message = getString(mInfoDetails[mViewPager.getCurrentItem()]);
        new AlertDialog.Builder(this, R.style.AlertDialogTheme)
                .setTitle(getString(R.string.info))
                .setMessage(message)
                .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .show();
    }

    public void showErrorDialog(String errorCode) {
        String errorText = mErrorTextMap.get(errorCode);
        String errorTitle = mErrorTitleMap.get(errorCode);
        if(TextUtils.isEmpty(errorText) || TextUtils.isEmpty(errorTitle)) {
           return;
        }

        new AlertDialog.Builder(this, R.style.AlertDialogTheme)
                .setTitle(errorTitle)
                .setMessage(errorText)
                .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .show();
    }

    private void sendOBDCommandDependsOnPosition() {
        mServiceHandler.obtainMessage(DUMMY_TEXT).sendToTarget();
        mServiceHandler.obtainMessage(RPM_COMMAND).sendToTarget();
        mServiceHandler.obtainMessage(RUNNING_TIME, TIMER_TIME).sendToTarget();
        mServiceHandler.obtainMessage(COOLANT_TEMPERATURE, TIMER_TIME).sendToTarget();
        mServiceHandler.obtainMessage(AIR_INTAKE, TIMER_TIME).sendToTarget();
        mServiceHandler.obtainMessage(SPEED, TIMER_TIME).sendToTarget();
        mServiceHandler.obtainMessage(DISTANCE_TRAVELLED, TIMER_TIME).sendToTarget();
        mServiceHandler.obtainMessage(TROUBLE_CODES, TIMER_TIME).sendToTarget();
    }

    private void updateUI(int position) {
        switch (position) {
            case 0:
                mRootLayout.setBackgroundColor(getColor(R.color.rpm_color));
                changeStatusBarColor(R.color.rpm_color);
                mToolbar.setBackgroundColor(getColor(R.color.rpm_color));
                mMoreButton.setVisibility(View.VISIBLE);
                break;

            case 1:
                mRootLayout.setBackgroundColor(getColor(R.color.filter_color));
                changeStatusBarColor(R.color.filter_color);
                mToolbar.setBackgroundColor(getColor(R.color.filter_color));
                mMoreButton.setVisibility(View.VISIBLE);
                break;

            case 2:
                mRootLayout.setBackgroundColor(getColor(R.color.travel_info_color));
                changeStatusBarColor(R.color.travel_info_color);
                mToolbar.setBackgroundColor(getColor(R.color.travel_info_color));
                mMoreButton.setVisibility(View.VISIBLE);
                break;

            case 3:
                mRootLayout.setBackgroundColor(getColor(R.color.navigation_color));
                changeStatusBarColor(R.color.navigation_color);
                mToolbar.setBackgroundColor(getColor(R.color.navigation_color));
                mMoreButton.setVisibility(View.GONE);
                break;

            case 4:
                mRootLayout.setBackgroundColor(getColor(R.color.warining_color));
                changeStatusBarColor(R.color.warining_color);
                mToolbar.setBackgroundColor(getColor(R.color.warining_color));
                mMoreButton.setVisibility(View.GONE);
                WarningFragment fragment = (WarningFragment) getActiveFragment(mPager, 4);
                if (fragment != null) {
                    fragment.updateTroubleCodes(mCodesList);
                }
        }
    }

    private void createBackgroundHandler() {
        mThread = new HandlerThread(TAG, android.os.Process.THREAD_PRIORITY_BACKGROUND);
        mThread.start();
        mServiceHandler = new ServiceHandler(mThread.getLooper());
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void changeStatusBarColor(int res) {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(getResources().getColor(res));
        }
    }

    private int getColor(int res) {
        return getResources().getColor(res);
    }

    public Fragment getActiveFragment(ViewPager container, int position) {
        String name = makeFragmentName(container.getId(), position);
        return getSupportFragmentManager().findFragmentByTag(name);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_screen);
        ButterKnife.bind(this);
        mIncomingHandler = new IncomingHandler(this);
        mPrefs = new MySharedPreference(getApplicationContext());

        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.tab_engine_info));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.tab_temperature));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.tab_speedo));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.tab_navigation));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.tab_alert));

        mViewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter
                (getSupportFragmentManager(), tabLayout.getTabCount());
        mViewPager.setAdapter(adapter);
        mViewPager.addOnPageChangeListener(mOnPageChangeListener);
        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(this);
        mViewPager.setOffscreenPageLimit(5);

        mRootLayout.setBackgroundColor(getColor(R.color.rpm_color));
        changeStatusBarColor(R.color.rpm_color);
        mToolbar.setBackgroundColor(getColor(R.color.rpm_color));
        showLoadingDialog();

        int pagerPosition = getIntent().getIntExtra(Constants.FRAGMENT_POSITION, 0);
        if (pagerPosition > 0) {
            mViewPager.setCurrentItem(pagerPosition - 1, false);
            updateUI(pagerPosition - 1);
        }
        createBackgroundHandler();
        mServiceIntent = new Intent(this, BleService.class);
        bindService(mServiceIntent, mConnection, BIND_AUTO_CREATE);
        mIncomingHandler.sendEmptyMessageDelayed(Constants.TIMER_TRIGGER, mPrefs.getTimeDelay());

        Log.d("!IMPORTANT", "Registered");

        IntentFilter statesFilter = new IntentFilter();
        statesFilter.addAction(Constants.STATES_INTENT);
        registerReceiver(mStatesReceiver, statesFilter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mIncomingHandler.sendEmptyMessageDelayed(NOT_RECEIVING_DATA, 30000);
        IntentFilter messageFilter = new IntentFilter();
        messageFilter.addAction(Constants.BLUETOOTH_MESSAGE_INTENT);
        registerReceiver(mBroadcastReceiver, messageFilter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "Un registering");
        mIncomingHandler.removeMessages(NOT_RECEIVING_DATA);
        unregisterReceiver(mBroadcastReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mConnection);
        if (mThread != null) {
            mThread.quit();
        }
        unregisterReceiver(mStatesReceiver);
    }

    @OnClick(R.id.back_button)
    public void gotoMainActivity() {
        finish();
    }

    private void sendCommand(String text) {
        if (mService != null) {
            mService.write(text.replaceAll("\\s+", ""));
        }
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        mViewPager.setCurrentItem(tab.getPosition());

        ((LevelListDrawable) tabLayout.getTabAt(0).getIcon()).setLevel(tab.getPosition());
        ((LevelListDrawable) tabLayout.getTabAt(1).getIcon()).setLevel(tab.getPosition());
        ((LevelListDrawable) tabLayout.getTabAt(2).getIcon()).setLevel(tab.getPosition());
        ((LevelListDrawable) tabLayout.getTabAt(3).getIcon()).setLevel(tab.getPosition());
        ((LevelListDrawable) tabLayout.getTabAt(4).getIcon()).setLevel(tab.getPosition());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    private void stateChanged(BleService.State newState) {
        mState = newState;
        switch (mState) {
            case DISCONNECTED:
                showDisconnectedDialog();
                break;
        }
    }

    private void parseAndGenerate(final String message) {
        if (TextUtils.isEmpty(message)) {
            return;
        }

        final String[] messageValue = message.split("\\|");
        if (messageValue.length > 1) {
            Log.d("IMPORTANT LOG", "0 - " + messageValue[0] + " 1 - " + messageValue[1] + " size : "
                    + messageValue.length + " Message : " + message);
            mIncomingHandler.removeMessages(NOT_RECEIVING_DATA);
            mIncomingHandler.sendEmptyMessageDelayed(NOT_RECEIVING_DATA, 30000);
            switch (messageValue[0]) {
                case Constants.RPM:
                    if (mDialog != null && mDialog.isShowing()) {
                        mDialog.dismiss();
                    }
                    final Fragment fragment = getActiveFragment(mPager, 0);
                    if (message.contains(Constants.IS_ERROR)) {
                        mErrorMap.put(Constants.RPM, true);
                        mErrorTextMap.put(Constants.RPM, getErrorString("RPM"));
                        if(message.contains(Constants.NO_DATA)) {
                            mErrorTitleMap.put(Constants.RPM,Constants.NO_DATA_ERROR);
                        } else {
                            mErrorTitleMap.put(Constants.RPM,Constants.UNABLE_TO_CONNECT_ERROR);
                        }
                        if (fragment != null && fragment instanceof RpmFragment) {
                            ((RpmFragment) fragment).setRpmError();
                        }
                    } else {
                        if (fragment != null && fragment instanceof RpmFragment) {
                            ((RpmFragment) fragment).setRpm(Integer.parseInt(messageValue[1]));
                        }
                    }
                    break;
                case Constants.RUNNING_TIME:
                    if (mDialog != null && mDialog.isShowing()) {
                        mDialog.dismiss();
                    }
                    final Fragment rpmfragment = getActiveFragment(mPager, 0);
                    if (message.contains(Constants.IS_ERROR)) {
                        mErrorMap.put(Constants.RUNNING_TIME, true);
                        mErrorTextMap.put(Constants.RUNNING_TIME, getErrorString("Engine Running " +
                                "Time"));
                        if(message.contains(Constants.NO_DATA)) {
                            mErrorTitleMap.put(Constants.RUNNING_TIME,Constants.NO_DATA_ERROR);
                        } else {
                            mErrorTitleMap.put(Constants.RUNNING_TIME,Constants.UNABLE_TO_CONNECT_ERROR);
                        }
                        if (rpmfragment != null && rpmfragment instanceof RpmFragment) {
                            ((RpmFragment) rpmfragment).setRunningTimeError();
                        }
                    } else {
                        if (rpmfragment != null && rpmfragment instanceof RpmFragment) {
                            ((RpmFragment) rpmfragment).setRunningTime(Long.parseLong(messageValue[1]));
                        }
                    }
                    break;
                case Constants.SPEED:
                    if (mDialog != null && mDialog.isShowing()) {
                        mDialog.dismiss();
                    }
                    final Fragment speedFragment = getActiveFragment(mPager, 2);
                    if (message.contains(Constants.IS_ERROR)) {
                        mErrorMap.put(Constants.SPEED, true);
                        mErrorTextMap.put(Constants.SPEED, getErrorString("Speed"));
                        if(message.contains(Constants.NO_DATA)) {
                            mErrorTitleMap.put(Constants.SPEED,Constants.NO_DATA_ERROR);
                        } else {
                            mErrorTitleMap.put(Constants.SPEED,Constants.UNABLE_TO_CONNECT_ERROR);
                        }
                        if (speedFragment != null && speedFragment instanceof TravelInfoFragment) {
                            ((TravelInfoFragment) speedFragment).updateSpeedInKms(Constants.IS_ERROR);
                        }
                    } else {
                        if (speedFragment != null && speedFragment instanceof TravelInfoFragment) {
                            ((TravelInfoFragment) speedFragment).updateSpeedInKms(messageValue[1]);
                        }
                    }

                    break;
                case Constants.DISTANCE_TRAVELLED:
                    if (mDialog != null && mDialog.isShowing()) {
                        mDialog.dismiss();
                    }
                    final Fragment distanceFragment = getActiveFragment(mPager, 2);
                    if (message.contains(Constants.IS_ERROR)) {
                        mErrorMap.put(Constants.DISTANCE_TRAVELLED, true);
                        mErrorTextMap.put(Constants.DISTANCE_TRAVELLED, getErrorString("Distance Travelled"));
                        if(message.contains(Constants.NO_DATA)) {
                            mErrorTitleMap.put(Constants.DISTANCE_TRAVELLED,Constants.NO_DATA_ERROR);
                        } else {
                            mErrorTitleMap.put(Constants.DISTANCE_TRAVELLED,Constants.UNABLE_TO_CONNECT_ERROR);
                        }
                        if (distanceFragment != null && distanceFragment instanceof TravelInfoFragment) {
                            ((TravelInfoFragment) distanceFragment).updateTotalKms(Constants.IS_ERROR);
                        }
                    } else {
                        if (distanceFragment != null && distanceFragment instanceof TravelInfoFragment) {
                            ((TravelInfoFragment) distanceFragment).updateTotalKms(messageValue[1]);
                        }
                    }
                    break;
                case Constants.TROUBLE_CODES:
                    if (mDialog != null && mDialog.isShowing()) {
                        mDialog.dismiss();
                    }
                    final Fragment warningFragment = getActiveFragment(mPager, 4);
                    if (message.contains(Constants.IS_ERROR)) {
                        mErrorMap.put(Constants.TROUBLE_CODES, true);
                        mErrorTextMap.put(Constants.TROUBLE_CODES, getErrorString("Trouble Codes"));
                        if(message.contains(Constants.NO_DATA)) {
                            mErrorTitleMap.put(Constants.TROUBLE_CODES,Constants.NO_DATA_ERROR);
                        } else {
                            mErrorTitleMap.put(Constants.TROUBLE_CODES,Constants.UNABLE_TO_CONNECT_ERROR);
                        }
                        if (warningFragment != null && warningFragment instanceof WarningFragment) {
                            ((WarningFragment) warningFragment).setTroubleCodeError();
                        }
                    } else {
                        ArrayList<String> messageList = new ArrayList<>(Arrays.asList(messageValue));
                        messageList.remove(0);
                        mCodesList = messageList;
                        for (int i = 0; i < mCodesList.size(); i++) {
                            mCriticalAlerts = mCriticalAlerts + mCodesList.get(i);
                        }
                        if (warningFragment != null && warningFragment instanceof WarningFragment) {
                            ((WarningFragment) warningFragment).updateTroubleCodes(mCodesList);
                        }
                    }
                    break;
                case Constants.COOLANT_TEMPERATURE:
                    if (mDialog != null && mDialog.isShowing()) {
                        mDialog.dismiss();
                    }
                    final Fragment temperatureFragment = getActiveFragment(mPager, 1);

                    if (message.contains(Constants.IS_ERROR)) {
                        mErrorMap.put(Constants.COOLANT_TEMPERATURE, true);
                        mErrorTextMap.put(Constants.COOLANT_TEMPERATURE, getErrorString("Coolant Temperature"));
                        if(message.contains(Constants.NO_DATA)) {
                            mErrorTitleMap.put(Constants.COOLANT_TEMPERATURE,Constants.NO_DATA_ERROR);
                        } else {
                            mErrorTitleMap.put(Constants.COOLANT_TEMPERATURE,Constants.UNABLE_TO_CONNECT_ERROR);
                        }
                        if (temperatureFragment != null && temperatureFragment instanceof TemperatureFragment) {
                            ((TemperatureFragment) temperatureFragment).updateCoolantTemperature
                                    (Constants.IS_ERROR);
                        }
                    } else {
                        if (temperatureFragment != null && temperatureFragment instanceof TemperatureFragment) {
                            ((TemperatureFragment) temperatureFragment).updateCoolantTemperature(messageValue[1]);
                        }
                    }
                    break;
                case Constants.INTAKE_AIR_TEMPERATURE:
                    if (mDialog != null && mDialog.isShowing()) {
                        mDialog.dismiss();
                    }
                    final Fragment airIntakeFragment = getActiveFragment(mPager, 1);
                    if (message.contains(Constants.IS_ERROR)) {
                        mErrorMap.put(Constants.INTAKE_AIR_TEMPERATURE, true);
                        mErrorTextMap.put(Constants.INTAKE_AIR_TEMPERATURE, getErrorString("Air Intake Temperature"));
                        if(message.contains(Constants.NO_DATA)) {
                            mErrorTitleMap.put(Constants.INTAKE_AIR_TEMPERATURE,Constants.NO_DATA_ERROR);
                        } else {
                            mErrorTitleMap.put(Constants.INTAKE_AIR_TEMPERATURE,Constants.UNABLE_TO_CONNECT_ERROR);
                        }
                        if (airIntakeFragment != null && airIntakeFragment instanceof TemperatureFragment) {
                            ((TemperatureFragment) airIntakeFragment).updateAirIntakeTemperature(Constants.IS_ERROR);
                        }
                    } else {
                        if (airIntakeFragment != null && airIntakeFragment instanceof TemperatureFragment) {
                            ((TemperatureFragment) airIntakeFragment).updateAirIntakeTemperature(messageValue[1]);
                        }
                    }
                    break;
            }
        } else {
            Log.d("IMPORTANT_LOG", "Message size not 2");
        }
    }

    private String getErrorString(String errorMessage) {
        return Constants.ERROR_PREFIX + errorMessage + Constants.ERROR_SUFFIX;
    }

    private void showLoadingDialog() {
        if (mDialog == null) {
            mDialog = new ProgressDialog(HomeScreenActivity.this);
        }
        mDialog.setMessage("Loading");
        mDialog.show();
    }

    public boolean isViewPagerOnTroubleFragment() {
        if (mViewPager.getCurrentItem() == 4) {
            return true;
        }
        return false;
    }

    private void showDisconnectedDialog() {
        new AlertDialog.Builder(HomeScreenActivity.this)
                .setMessage("Device disconnected. Restart the app?")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Restarting", Toast.LENGTH_SHORT).show();
                        setResult(CLEAR_ALL);
                        finish();
                    }
                })
                .setCancelable(false)
                .show();
    }

    private void showDeviceIdleDialog() {
        try {
            new AlertDialog.Builder(this)
                    .setMessage("Connection broken, Please restart the app.")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            BluetoothGatt gatt = mService.getGatt();
                            if (gatt != null) {
                                gatt.close();
                                gatt.disconnect();
                            }
                            setResult(CLEAR_ALL);
                            finish();
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            if (mDialog != null) {
                                mDialog.dismiss();
                            }
                        }
                    })
                    .setCancelable(false)
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static class IncomingHandler extends Handler {
        private final WeakReference<HomeScreenActivity> mActivity;

        public IncomingHandler(HomeScreenActivity activity) {
            mActivity = new WeakReference<HomeScreenActivity>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            final HomeScreenActivity activity = mActivity.get();
            if (activity != null) {
                switch (msg.what) {

                    case NOT_RECEIVING_DATA:
                        activity.showDeviceIdleDialog();
                        break;
                }
            }
            super.handleMessage(msg);
        }
    }

    private final class ServiceHandler extends Handler {

        public ServiceHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            Log.d(TAG, "!msg received by serivce handler: " + msg.what);
            switch (msg.what) {
                case RPM_COMMAND:
                    Log.d(TAG, "!sending RPM command");
                    sendCommand(Constants.RPM);
                    break;

                case RUNNING_TIME:
                    Log.d(TAG, "!sending Engine runtime command");
                    sendCommand(Constants.RUNNING_TIME);
                    break;

                case SPEED:
                    Log.d(TAG, "!sending Speed command");
                    sendCommand(Constants.SPEED);
                    break;

                case DISTANCE_TRAVELLED:
                    Log.d(TAG, "!sending Distance travelled command");
                    sendCommand(Constants.DISTANCE_TRAVELLED);
                    break;

                case TROUBLE_CODES:
                    Log.d(TAG, "!sending trouble codes command");
                    sendCommand(Constants.TROUBLE_CODES);
                    break;

                case COOLANT_TEMPERATURE:
                    Log.d(TAG, "!sending coolant command");
                    sendCommand(Constants.COOLANT_TEMPERATURE);
                    break;

                case AIR_INTAKE:
                    Log.d(TAG, "!sending air intake command");
                    sendCommand(Constants.INTAKE_AIR_TEMPERATURE);
                    break;

                case DUMMY_TEXT:
                    Log.d(TAG, "!sending dummy text");
                    sendCommand(Constants.DUMMY_TEXT);
                    break;
            }
        }
    }

    public class PagerAdapter extends FragmentPagerAdapter {
        int mNumOfTabs;

        public PagerAdapter(FragmentManager fm, int NumOfTabs) {
            super(fm);
            this.mNumOfTabs = NumOfTabs;
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    RpmFragment tab1 = new RpmFragment();
                    return tab1;

                case 1:
                    TemperatureFragment tab2 = new TemperatureFragment();
                    return tab2;

                case 2:
                    TravelInfoFragment tab3 = new TravelInfoFragment();
                    return tab3;

                case 3:
                    NavigationFragment tab4 = new NavigationFragment();
                    return tab4;

                case 4:
                    WarningFragment tab5 = new WarningFragment();
                    return tab5;

                default:
                    return null;
            }
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            return super.instantiateItem(container, position);
        }

        @Override
        public void destroyItem(ViewGroup viewPager, int position, Object object) {
            viewPager.removeView((View) object);
        }

        @Override
        public int getCount() {
            return mNumOfTabs;
        }
    }
}