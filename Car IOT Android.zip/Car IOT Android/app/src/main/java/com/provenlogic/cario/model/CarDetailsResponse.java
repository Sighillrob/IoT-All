package com.provenlogic.cario.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by mathan on 29/9/15.
 */
public class CarDetailsResponse {

    @SerializedName("success")
    @Expose
    private Boolean success;
    @SerializedName("car_make")
    @Expose
    private String carMake;
    @SerializedName("car_model")
    @Expose
    private String carModel;
    @SerializedName("car_year")
    @Expose
    private String carYear;
    @SerializedName("car_engine_no")
    @Expose
    private String carEngineNo;

    /**
     *
     * @return
     * The success
     */
    public Boolean getSuccess() {
        return success;
    }

    /**
     *
     * @param success
     * The success
     */
    public void setSuccess(Boolean success) {
        this.success = success;
    }

    /**
     *
     * @return
     * The carMake
     */
    public String getCarMake() {
        return carMake;
    }

    /**
     *
     * @param carMake
     * The car_make
     */
    public void setCarMake(String carMake) {
        this.carMake = carMake;
    }

    /**
     *
     * @return
     * The carModel
     */
    public String getCarModel() {
        return carModel;
    }

    /**
     *
     * @param carModel
     * The car_model
     */
    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    /**
     *
     * @return
     * The carYear
     */
    public String getCarYear() {
        return carYear;
    }

    /**
     *
     * @param carYear
     * The car_year
     */
    public void setCarYear(String carYear) {
        this.carYear = carYear;
    }

    /**
     *
     * @return
     * The carEngineNo
     */
    public String getCarEngineNo() {
        return carEngineNo;
    }

    /**
     *
     * @param carEngineNo
     * The car_engine_no
     */
    public void setCarEngineNo(String carEngineNo) {
        this.carEngineNo = carEngineNo;
    }

}
