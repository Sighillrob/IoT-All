package com.provenlogic.cario;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.SpannableStringBuilder;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.github.glomadrian.dashedcircularprogress.DashedCircularProgress;
import com.provenlogic.cario.utils.Constants;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by mathan on 4/9/15.
 */
public class TravelInfoFragment extends Fragment {

    @Bind(R.id.simple)
    DashedCircularProgress mTravelInfo;
    @Bind(R.id.km_speed)
    TextView mKmSpeed;
    @Bind(R.id.speed_status)
    ImageView mSpeedStatus;
    @Bind(R.id.total_km)
    TextView mTotalKm;
    @Bind(R.id.running_distance)
    TextView mRunningDistance;
    @Bind(R.id.speed_title)
    TextView mSpeedTitle;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.travel_info_fragment_layout, container, false);
        ButterKnife.bind(this, view);
        updateSpeedInKms("0");
        updateTotalKms("0");
        return view;
    }

    public void updateTotalKms(String actualKm) {
        if (actualKm.equalsIgnoreCase(Constants.IS_ERROR)) {
            mTotalKm.setText("-");
            mTotalKm.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, R.drawable.alert);
        } else {
            SpannableStringBuilder spanTxt = new SpannableStringBuilder(actualKm);
            spanTxt.append("\n Kms");
            spanTxt.setSpan(new RelativeSizeSpan(3f), 0, actualKm.length(), 0);
            if (isAdded() && !isRemoving() && !isDetached() && isVisible()) {
                mTotalKm.setText(spanTxt);
            }
            mTotalKm.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        }
    }

    @OnClick(R.id.total_km)
    public void showDistanceTravelledErrorDialog() {
        HomeScreenActivity activity = (HomeScreenActivity) getActivity();
        activity.showErrorDialog(Constants.DISTANCE_TRAVELLED);
    }

    @OnClick(R.id.speed_title)
    public void showSpeedErrorDialog() {
        HomeScreenActivity activity = (HomeScreenActivity) getActivity();
        activity.showErrorDialog(Constants.SPEED);
    }

    public void updateSpeedInKms(String actualSpeed) {
        if(actualSpeed.equalsIgnoreCase(Constants.IS_ERROR)) {
            mKmSpeed.setText("-");
            mSpeedTitle.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, R.drawable.alert);
        } else {
            SpannableStringBuilder spanTxt = new SpannableStringBuilder(actualSpeed);
            spanTxt.append("\n Km/h");
            spanTxt.setSpan(new RelativeSizeSpan(3f), 0, actualSpeed.length(), 0);
            if (isAdded() && !isRemoving() && !isDetached() && isVisible()) {
                mKmSpeed.setText(spanTxt);
                animate(Integer.parseInt(actualSpeed));
            }
            mSpeedTitle.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0,0);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void animate(int value) {
        mTravelInfo.setValue(value);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }
}
