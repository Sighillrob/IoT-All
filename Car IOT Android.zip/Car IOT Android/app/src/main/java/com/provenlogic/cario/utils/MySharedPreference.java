package com.provenlogic.cario.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Created by mathan on 10/9/15.
 */
public class MySharedPreference {

    private Context mContext;
    private SharedPreferences mPrefs;

    public MySharedPreference(Context context) {
        mContext = context;
        mPrefs = PreferenceManager.getDefaultSharedPreferences(mContext);
    }

    public String getUserId() {
        return mPrefs.getString(Constants.USER_ID, Constants.EMPTY_STRING);
    }

    public void setUserId(String value) {
        storeText(Constants.USER_ID, value);
    }

    public String getFirstName() {
        return mPrefs.getString(Constants.FIRST_NAME, Constants.EMPTY_STRING);
    }

    public void setFirstName(String value) {
        storeText(Constants.FIRST_NAME, value);
    }

    public String getEmailId() {
        return mPrefs.getString(Constants.EMAIL_ID, Constants.EMPTY_STRING);
    }

    public void setEmailId(String value) {
        storeText(Constants.EMAIL_ID, value);
    }

    public String getToken() {
        return mPrefs.getString(Constants.TOKEN, Constants.EMPTY_STRING);
    }

    public void setToken(String value) {
        storeText(Constants.TOKEN, value);
    }

    public long getTimeDelay() {
        return mPrefs.getLong(Constants.TIME_DELAY, Constants.DEFAULT_TIME_DELAY);
    }

    public void setTimeDelay(long timeDelay) {
        SharedPreferences.Editor editor = mPrefs.edit();
        editor.putLong(Constants.TIME_DELAY, timeDelay);
        editor.apply();
    }

    public boolean isCarUpdated() {
        return mPrefs.getBoolean(Constants.IS_CAR_UPDATED,false);
    }

    public void setCarUpdated(boolean value) {
        SharedPreferences.Editor editor = mPrefs.edit();
        editor.putBoolean(Constants.IS_CAR_UPDATED,value);
        editor.apply();
    }

    public void setDashboardUrl(String url) {
        storeText(Constants.DASHBOARD_URL, url);
    }

    public String getDashboardUrl() {
        return mPrefs.getString(Constants.DASHBOARD_URL,"");
    }

    public String getClkValue() {
        return mPrefs.getString(Constants.CLK_VALUE, Constants.DEFAULT_CLK);
    }

    public void setClkValue(String value) {
        storeText(Constants.CLK_VALUE, value);
    }

    private void storeText(String type, String value) {
        SharedPreferences.Editor editor = mPrefs.edit();
        editor.putString(type, value);
        editor.apply();
    }

    public void clearAllData() {
        SharedPreferences.Editor editor = mPrefs.edit();
        editor.clear();
        editor.apply();
    }

}
