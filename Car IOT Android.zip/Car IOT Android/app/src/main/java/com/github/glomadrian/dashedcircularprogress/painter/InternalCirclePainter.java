package com.github.glomadrian.dashedcircularprogress.painter;

/**
 * @author Adrián García Lomas
 */
public interface InternalCirclePainter extends Painter {
}
