package com.github.glomadrian.dashedcircularprogress.painter;

/**
 * @author Adrián García Lomas
 */
public interface ExternalCirclePainter extends Painter {

}
