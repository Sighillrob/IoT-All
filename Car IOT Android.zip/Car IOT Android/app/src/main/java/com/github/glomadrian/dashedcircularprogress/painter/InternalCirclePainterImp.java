package com.github.glomadrian.dashedcircularprogress.painter;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;

/**
 * @author Adrián García Lomas
 */
public class InternalCirclePainterImp implements InternalCirclePainter {

    private RectF internalCircle;
    private Paint internalCirclePaint;
    private int color;
    private float startAngle = 270;
    private float finishAngle = 359.8f;
    private int width;
    private int height;
    private int internalStrokeWidth = 30;
    private int mDashWidth = 3;
    private int mDashSpace = 5;
    private float marginTop = 45;

    public InternalCirclePainterImp(int color) {
        this.color = color;
        init();
    }

    public void setInternalDashSpace(int dashSpace) {
        mDashSpace = dashSpace;
        init();
    }

    private void init() {
        initExternalCirclePainter();
    }

    private void initExternalCirclePainter() {
        internalCirclePaint = new Paint();
        internalCirclePaint.setAntiAlias(true);
        internalCirclePaint.setStrokeWidth(internalStrokeWidth);
        internalCirclePaint.setColor(color);
        internalCirclePaint.setStyle(Paint.Style.STROKE);
        internalCirclePaint.setPathEffect(new DashPathEffect(new float[]{mDashWidth, mDashSpace},
                mDashSpace));
    }

    private void initExternalCircle() {
        internalCircle = new RectF();
        float padding = internalStrokeWidth * 1.5f;
        internalCircle.set(padding, padding + marginTop, width - padding, height - padding);
    }

    @Override
    public void draw(Canvas canvas) {
        canvas.drawArc(internalCircle, startAngle, finishAngle, false, internalCirclePaint);
    }

    @Override
    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
        internalCirclePaint.setColor(color);
    }

    @Override
    public void onSizeChanged(int height, int width) {
        this.width = width;
        this.height = height;
        initExternalCircle();
    }

    public void setInternalDashWidth(int dashWidth) {
        mDashWidth = dashWidth;
        init();
    }

    public void setAngles(float startingAngle, float endingAngle) {
        startAngle = startingAngle;
        finishAngle = endingAngle;
        initExternalCirclePainter();
    }
}
