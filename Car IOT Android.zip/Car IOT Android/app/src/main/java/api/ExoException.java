package api;

public class ExoException extends Exception {
    public ExoException(final String message) {
        super(message);
    }
}
