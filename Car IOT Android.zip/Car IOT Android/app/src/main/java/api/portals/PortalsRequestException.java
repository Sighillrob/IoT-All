package api.portals;


import api.ExoException;

public class PortalsRequestException extends ExoException {

    public PortalsRequestException(final String message) {
        super(message);
    }
}
